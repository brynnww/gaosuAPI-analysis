import asyncio
import json
import logging
import base64
import io
from datetime import datetime, timedelta
from typing import Dict, List, Any, Tuple
import httpx
from dataclasses import dataclass
import matplotlib.pyplot as plt
import matplotlib
matplotlib.use('Agg')  # 使用非交互式后端
import pandas as pd
import numpy as np
from matplotlib.font_manager import FontProperties
import matplotlib.patches as patches
from matplotlib import rcParams

# 配置中文字体
import platform
if platform.system() == 'Windows':
    # Windows系统字体配置
    plt.rcParams['font.sans-serif'] = ['Microsoft YaHei', 'SimHei', 'Arial Unicode MS', 'DejaVu Sans']
else:
    # Linux/Mac系统字体配置
    plt.rcParams['font.sans-serif'] = ['DejaVu Sans', 'Arial Unicode MS', 'SimHei']

plt.rcParams['axes.unicode_minus'] = False
plt.rcParams['figure.figsize'] = (12, 8)  # 设置默认图形大小

# 配置日志
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger("report-generator")

# API配置
API_BASE_URL = "http://116.182.4.67:8088/gssfApi2/v1/api"
API_HEADERS = {
    "Content-Type": "application/json",
    "Authorization": "Basic anRnc3RBZG1pbjpwWXMzWGdBJjVObXM="
}

@dataclass
class ChartImage:
    """图表图片数据"""
    chart_id: str
    title: str
    image_base64: str
    filename: str

@dataclass
class ReportData:
    """报告数据结构"""
    current_period_data: Dict[str, Any]
    previous_period_data: Dict[str, Any]
    year_ago_data: Dict[str, Any]
    charts_data: List[ChartImage]
    analysis_text: str

class ReportGenerator:
    def __init__(self):
        self.api_client = httpx.AsyncClient(headers=API_HEADERS, timeout=60.0)
    
    async def __aenter__(self):
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.api_client.aclose()
    
    async def _make_request(self, endpoint: str, method: str = "GET", data: Dict = None) -> Dict[str, Any]:
        """发送API请求，带重试机制"""
        url = f"{API_BASE_URL}/{endpoint}"
        max_retries = 3
        
        for attempt in range(max_retries):
            try:
                logger.info(f"API请求 {endpoint} (尝试 {attempt + 1}/{max_retries})")
                
                if method.upper() == "GET":
                    response = await self.api_client.get(url)
                else:
                    response = await self.api_client.post(url, json=data)
                
                response.raise_for_status()
                result = response.json()
                logger.info(f"API请求 {endpoint} 成功")
                return result
                
            except httpx.ConnectError as e:
                logger.error(f"连接错误 {endpoint} (尝试 {attempt + 1}/{max_retries}): {e}")
                if attempt == max_retries - 1:
                    return {"error": f"连接失败: {str(e)}"}
                await asyncio.sleep(2 ** attempt)  # 指数退避
                
            except httpx.TimeoutException as e:
                logger.error(f"超时错误 {endpoint} (尝试 {attempt + 1}/{max_retries}): {e}")
                if attempt == max_retries - 1:
                    return {"error": f"请求超时: {str(e)}"}
                await asyncio.sleep(2 ** attempt)  # 指数退避
                
            except httpx.HTTPStatusError as e:
                logger.error(f"HTTP错误 {endpoint} (尝试 {attempt + 1}/{max_retries}): {e.response.status_code} - {e.response.text}")
                if attempt == max_retries - 1:
                    return {"error": f"HTTP错误 {e.response.status_code}: {e.response.text}"}
                await asyncio.sleep(2 ** attempt)  # 指数退避
                
            except Exception as e:
                logger.error(f"未知错误 {endpoint} (尝试 {attempt + 1}/{max_retries}): {e}")
                if attempt == max_retries - 1:
                    return {"error": f"请求失败: {str(e)}"}
                await asyncio.sleep(2 ** attempt)  # 指数退避
    
    def _calculate_date_ranges(self, start_date: str, end_date: str) -> Tuple[str, str, str, str]:
        """计算对比日期范围"""
        start_dt = datetime.strptime(start_date, "%Y-%m-%d")
        end_dt = datetime.strptime(end_date, "%Y-%m-%d")
        
        # 计算周期天数
        period_days = (end_dt - start_dt).days + 1
        
        # 上一周期
        prev_start = start_dt - timedelta(days=period_days)
        prev_end = start_dt - timedelta(days=1)
        
        # 去年同期
        year_ago_start = start_dt - timedelta(days=365)
        year_ago_end = end_dt - timedelta(days=365)
        
        return (
            prev_start.strftime("%Y-%m-%d"),
            prev_end.strftime("%Y-%m-%d"),
            year_ago_start.strftime("%Y-%m-%d"),
            year_ago_end.strftime("%Y-%m-%d")
        )
    
    def _calculate_growth_rate(self, current: float, previous: float) -> float:
        """计算增长率"""
        if previous == 0:
            return 0.0 if current == 0 else 100.0
        return ((current - previous) / previous) * 100
    
    def _generate_chart_image(self, fig, chart_id: str, title: str) -> ChartImage:
        """生成图表图片并转换为base64"""
        buf = io.BytesIO()
        fig.savefig(buf, format='png', dpi=150, bbox_inches='tight')
        buf.seek(0)
        image_base64 = base64.b64encode(buf.read()).decode('utf-8')
        buf.close()
        plt.close(fig)  # 关闭图表释放内存

        filename = f"{chart_id}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.png"

        return ChartImage(
            chart_id=chart_id,
            title=title,
            image_base64=image_base64,
            filename=filename
        )

    def _generate_charts_data(self, current_data: Dict, previous_data: Dict, year_ago_data: Dict, traffic_data: Dict) -> List[ChartImage]:
        """生成所有图表数据"""
        charts = []

        try:
            # 1. 车流量、交易额分公司收费站topn
            charts.append(self._generate_turnover_trend_chart(current_data, previous_data, year_ago_data))
            charts.append(self._generate_traffic_flow_chart(traffic_data, previous_data, year_ago_data))

            # 2. 各分公司收费车流量同比分析
            charts.append(self._generate_traffic_yoy_chart(current_data, previous_data, year_ago_data))

            # 3. 各分公司高速ETC车流量与通行费百分比折线图
            charts.append(self._generate_traffic_turnover_ratio_chart(current_data, traffic_data))

            # 4. 各分公司实收通行费分支付类型占比
            charts.append(self._generate_payment_type_chart(current_data))

            # 5. 各分公司实收通行费同比分析
            charts.append(self._generate_turnover_yoy_chart(current_data, previous_data, year_ago_data))

            logger.info(f"成功生成 {len(charts)} 个图表")

        except Exception as e:
            logger.error(f"生成图表时出错: {e}")

        return charts

    def _generate_turnover_trend_chart(self, current_data: Dict, previous_data: Dict, year_ago_data: Dict) -> ChartImage:
        """生成交易额趋势图"""
        fig, ax = plt.subplots(figsize=(12, 8))

        if 'data' in current_data and 'payTypeTurnoverList' in current_data['data']:
            companies = current_data['data']['payTypeTurnoverList']
            company_names = [comp['unitName'] for comp in companies]
            current_turnover = [comp['turnover'] / 10000 for comp in companies]  # 转换为万元

            # 排序，取前10
            sorted_indices = np.argsort(current_turnover)[-10:]
            company_names = [company_names[i] for i in sorted_indices]
            current_turnover = [current_turnover[i] for i in sorted_indices]

            bars = ax.barh(company_names, current_turnover, color='#3b82f6', alpha=0.8)

            # 添加数值标签
            for bar in bars:
                width = bar.get_width()
                ax.text(width + max(current_turnover) * 0.01, bar.get_y() + bar.get_height()/2,
                       f'{width:.1f}', ha='left', va='center', fontsize=10, fontweight='bold')

            ax.set_xlabel('交易额 (万元)', fontsize=12)
            ax.set_title('分公司交易额TOP10', fontsize=16, fontweight='bold', pad=20)
            ax.grid(True, alpha=0.3)

            # 设置x轴范围
            ax.set_xlim(0, max(current_turnover) * 1.1)

        return self._generate_chart_image(fig, 'turnover_trend', '分公司交易额TOP10')

    def _generate_traffic_flow_chart(self, current_data: Dict, previous_data: Dict, year_ago_data: Dict) -> ChartImage:
        """生成车流量趋势图"""
        fig, ax = plt.subplots(figsize=(12, 8))

        if 'data' in current_data and 'payTypeTrafficFlowList' in current_data['data']:
            companies = current_data['data']['payTypeTrafficFlowList']
            company_names = [comp['unitName'] for comp in companies]
            current_traffic = [comp['trafficFlow'] for comp in companies]

            # 排序，取前10
            sorted_indices = np.argsort(current_traffic)[-10:]
            company_names = [company_names[i] for i in sorted_indices]
            current_traffic = [current_traffic[i] for i in sorted_indices]

            bars = ax.barh(company_names, current_traffic, color='#10b981', alpha=0.8)

            # 添加数值标签
            for bar in bars:
                width = bar.get_width()
                ax.text(width + max(current_traffic) * 0.01, bar.get_y() + bar.get_height()/2,
                       f'{int(width):,}', ha='left', va='center', fontsize=10, fontweight='bold')

            ax.set_xlabel('车流量 (辆)', fontsize=12)
            ax.set_title('分公司车流量TOP10', fontsize=16, fontweight='bold', pad=20)
            ax.grid(True, alpha=0.3)

            # 设置x轴范围
            ax.set_xlim(0, max(current_traffic) * 1.1)

        return self._generate_chart_image(fig, 'traffic_flow', '分公司车流量TOP10')

    def _generate_traffic_turnover_ratio_chart(self, current_data: Dict, traffic_data: Dict) -> ChartImage:
        """生成ETC车流量与通行费百分比折线图"""
        fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(12, 10))

        if ('data' in current_data and 'payTypeTurnoverList' in current_data['data'] and
            'data' in traffic_data and 'payTypeTrafficFlowList' in traffic_data['data']):

            # 合并数据
            turnover_companies = {comp['unitName']: comp for comp in current_data['data']['payTypeTurnoverList']}
            traffic_companies = {comp['unitName']: comp for comp in traffic_data['data']['payTypeTrafficFlowList']}

            common_companies = set(turnover_companies.keys()) & set(traffic_companies.keys())

            if common_companies:
                company_names = list(common_companies)
                etc_ratios = []
                turnover_ratios = []

                for company in company_names:
                    turnover_comp = turnover_companies[company]
                    traffic_comp = traffic_companies[company]

                    total_turnover = turnover_comp['turnover']
                    etc_turnover = turnover_comp['etcTurnover']
                    total_traffic = traffic_comp['trafficFlow']
                    etc_traffic = traffic_comp['etcTrafficFlow']

                    etc_ratio = (etc_traffic / total_traffic * 100) if total_traffic > 0 else 0
                    turnover_etc_ratio = (etc_turnover / total_turnover * 100) if total_turnover > 0 else 0

                    etc_ratios.append(etc_ratio)
                    turnover_ratios.append(turnover_etc_ratio)

                # 按ETC车流量比例排序，取前10
                sorted_indices = np.argsort(etc_ratios)[-10:]
                company_names = [company_names[i] for i in sorted_indices]
                etc_ratios = [etc_ratios[i] for i in sorted_indices]
                turnover_ratios = [turnover_ratios[i] for i in sorted_indices]

                # ETC车流量占比
                bars1 = ax1.barh(company_names, etc_ratios, color='#f59e0b', alpha=0.8)
                ax1.set_xlabel('ETC车流量占比 (%)', fontsize=12)
                ax1.set_title('ETC车流量占比TOP10', fontsize=14, fontweight='bold')
                ax1.grid(True, alpha=0.3)
                ax1.set_xlim(0, max(etc_ratios) * 1.1)

                # 添加数值标签
                for bar in bars1:
                    width = bar.get_width()
                    ax1.text(width + max(etc_ratios) * 0.01, bar.get_y() + bar.get_height()/2,
                            f'{width:.1f}%', ha='left', va='center', fontsize=9, fontweight='bold')

                # 通行费ETC占比
                bars2 = ax2.barh(company_names, turnover_ratios, color='#ef4444', alpha=0.8)
                ax2.set_xlabel('ETC通行费占比 (%)', fontsize=12)
                ax2.set_title('ETC通行费占比TOP10', fontsize=14, fontweight='bold')
                ax2.grid(True, alpha=0.3)
                ax2.set_xlim(0, max(turnover_ratios) * 1.1)

                # 添加数值标签
                for bar in bars2:
                    width = bar.get_width()
                    ax2.text(width + max(turnover_ratios) * 0.01, bar.get_y() + bar.get_height()/2,
                            f'{width:.1f}%', ha='left', va='center', fontsize=9, fontweight='bold')

        plt.tight_layout()
        return self._generate_chart_image(fig, 'etc_ratio', 'ETC车流量与通行费占比分析')

    def _generate_payment_method_chart(self, current_data: Dict) -> ChartImage:
        """生成支付方式占比饼图"""
        fig, ax = plt.subplots(figsize=(10, 8))

        if 'data' in current_data and 'payTypeTurnoverList' in current_data['data']:
            total_etc = sum(comp['etcTurnover'] for comp in current_data['data']['payTypeTurnoverList'])
            total_cash = sum(comp['cashTurnover'] for comp in current_data['data']['payTypeTurnoverList'])
            total_mobile = sum(comp['mobileTurnover'] for comp in current_data['data']['payTypeTurnoverList'])

            sizes = [total_etc, total_cash, total_mobile]
            labels = ['ETC支付', '现金支付', '移动支付']
            colors = ['#ff6b6b', '#4ecdc4', '#45b7d1']

            # 只显示非零的值
            non_zero_sizes = []
            non_zero_labels = []
            non_zero_colors = []

            for size, label, color in zip(sizes, labels, colors):
                if size > 0:
                    non_zero_sizes.append(size)
                    non_zero_labels.append(label)
                    non_zero_colors.append(color)

            if non_zero_sizes:
                wedges, texts, autotexts = ax.pie(non_zero_sizes, labels=non_zero_labels, colors=non_zero_colors,
                                               autopct='%1.1f%%', startangle=90, pctdistance=0.85)

                # 设置百分比文字样式
                for autotext in autotexts:
                    autotext.set_fontsize(12)
                    autotext.set_fontweight('bold')

                ax.set_title('支付方式分布', fontsize=16, fontweight='bold', pad=20)
                ax.axis('equal')

        return self._generate_chart_image(fig, 'payment_methods', '支付方式占比分布')

    def _generate_turnover_yoy_chart(self, current_data: Dict, previous_data: Dict, year_ago_data: Dict) -> ChartImage:
        """生成实收通行费同比分析图"""
        fig, ax = plt.subplots(figsize=(12, 8))

        if ('data' in current_data and 'payTypeTurnoverList' in current_data['data'] and
            'data' in previous_data and 'payTypeTurnoverList' in previous_data['data'] and
            'data' in year_ago_data and 'payTypeTurnoverList' in year_ago_data['data']):

            # 合并数据
            current_companies = {comp['unitName']: comp for comp in current_data['data']['payTypeTurnoverList']}
            previous_companies = {comp['unitName']: comp for comp in previous_data['data']['payTypeTurnoverList']}
            year_ago_companies = {comp['unitName']: comp for comp in year_ago_data['data']['payTypeTurnoverList']}

            common_companies = set(current_companies.keys()) & set(previous_companies.keys()) & set(year_ago_companies.keys())

            if common_companies:
                company_names = list(common_companies)
                growth_rates = []

                for company in company_names:
                    current_turnover = current_companies[company]['turnover']
                    year_ago_turnover = year_ago_companies[company]['turnover']

                    if year_ago_turnover > 0:
                        growth_rate = ((current_turnover - year_ago_turnover) / year_ago_turnover) * 100
                        growth_rates.append(growth_rate)
                    else:
                        growth_rates.append(0)

                # 按增长率排序，取前10
                sorted_indices = np.argsort(growth_rates)[-10:]
                company_names = [company_names[i] for i in sorted_indices]
                growth_rates = [growth_rates[i] for i in sorted_indices]

                colors = ['#10b981' if rate >= 0 else '#ef4444' for rate in growth_rates]
                bars = ax.barh(company_names, growth_rates, color=colors, alpha=0.8)

                # 添加数值标签
                for bar in bars:
                    width = bar.get_width()
                    ax.text(width + (1 if width >= 0 else -1) * max(abs(r) for r in growth_rates) * 0.01,
                           bar.get_y() + bar.get_height()/2,
                           f'{width:+.1f}%', ha='left' if width >= 0 else 'right', va='center',
                           fontsize=10, fontweight='bold')

                ax.set_xlabel('同比增长率 (%)', fontsize=12)
                ax.set_title('实收通行费同比增长率TOP10', fontsize=16, fontweight='bold', pad=20)
                ax.grid(True, alpha=0.3)
                ax.axvline(x=0, color='black', linestyle='-', alpha=0.5)

        return self._generate_chart_image(fig, 'turnover_yoy', '实收通行费同比增长分析')

    def _generate_traffic_yoy_chart(self, current_data: Dict, previous_data: Dict, year_ago_data: Dict) -> ChartImage:
        """生成车流量同比分析图"""
        fig, ax = plt.subplots(figsize=(12, 8))

        # 车流量数据存储在trafficFlow字段中
        if ('trafficFlow' in current_data and 'data' in current_data['trafficFlow'] and 
            'payTypeTrafficFlowList' in current_data['trafficFlow']['data'] and
            'trafficFlow' in year_ago_data and 'data' in year_ago_data['trafficFlow'] and
            'payTypeTrafficFlowList' in year_ago_data['trafficFlow']['data']):

            # 从正确的位置获取数据
            current_companies = {comp['unitName']: comp for comp in current_data['trafficFlow']['data']['payTypeTrafficFlowList']}
            year_ago_companies = {comp['unitName']: comp for comp in year_ago_data['trafficFlow']['data']['payTypeTrafficFlowList']}

            # 找出当前期间和去年同期都有的分公司
            common_companies = set(current_companies.keys()) & set(year_ago_companies.keys())

            if common_companies:
                company_names = list(common_companies)
                growth_rates = []

                for company in company_names:
                    current_traffic = current_companies[company]['trafficFlow']
                    year_ago_traffic = year_ago_companies[company]['trafficFlow']

                    if year_ago_traffic > 0:
                        growth_rate = ((current_traffic - year_ago_traffic) / year_ago_traffic) * 100
                        growth_rates.append(growth_rate)
                    else:
                        growth_rates.append(0)

                # 按增长率排序，取前10
                sorted_indices = np.argsort(growth_rates)[-10:]
                company_names = [company_names[i] for i in sorted_indices]
                growth_rates = [growth_rates[i] for i in sorted_indices]

                colors = ['#10b981' if rate >= 0 else '#ef4444' for rate in growth_rates]
                bars = ax.barh(company_names, growth_rates, color=colors, alpha=0.8)

                # 添加数值标签
                for bar in bars:
                    width = bar.get_width()
                    ax.text(width + (1 if width >= 0 else -1) * max(abs(r) for r in growth_rates) * 0.01,
                           bar.get_y() + bar.get_height()/2,
                           f'{width:+.1f}%', ha='left' if width >= 0 else 'right', va='center',
                           fontsize=10, fontweight='bold')

                ax.set_xlabel('同比增长率 (%)', fontsize=12)
                ax.set_title('车流量同比增长率TOP10', fontsize=16, fontweight='bold', pad=20)
                ax.grid(True, alpha=0.3)
                ax.axvline(x=0, color='black', linestyle='-', alpha=0.5)

        return self._generate_chart_image(fig, 'traffic_yoy', '车流量同比增长分析')

    def _generate_payment_type_chart(self, current_data: Dict) -> ChartImage:
        """生成各分公司实收通行费分支付类型占比"""
        fig, ax = plt.subplots(figsize=(14, 10))

        if 'data' in current_data and 'payTypeTurnoverList' in current_data['data']:
            companies = current_data['data']['payTypeTurnoverList']

            # 取前8个分公司
            companies = companies[:8] if len(companies) > 8 else companies

            company_names = [comp['unitName'] for comp in companies]

            etc_turnover = [comp['etcTurnover'] / 10000 for comp in companies]  # 万元
            cash_turnover = [comp['cashTurnover'] / 10000 for comp in companies]
            mobile_turnover = [comp['mobileTurnover'] / 10000 for comp in companies]

            # 创建堆叠条形图
            bar_width = 0.8
            index = np.arange(len(company_names))

            bars1 = ax.bar(index, etc_turnover, bar_width, label='ETC支付', color='#ff6b6b', alpha=0.8)
            bars2 = ax.bar(index, cash_turnover, bar_width, bottom=etc_turnover, label='现金支付', color='#4ecdc4', alpha=0.8)
            bars3 = ax.bar(index, mobile_turnover, bar_width, bottom=[etc + cash for etc, cash in zip(etc_turnover, cash_turnover)],
                          label='移动支付', color='#45b7d1', alpha=0.8)

            ax.set_xlabel('分公司', fontsize=12)
            ax.set_ylabel('交易额 (万元)', fontsize=12)
            ax.set_title('各分公司实收通行费分支付类型占比', fontsize=16, fontweight='bold', pad=20)
            ax.set_xticks(index)
            ax.set_xticklabels(company_names, rotation=45, ha='right')
            ax.legend()
            ax.grid(True, alpha=0.3)

        return self._generate_chart_image(fig, 'payment_type', '各分公司实收通行费分支付类型占比')
    
    def _generate_detailed_analysis(self, current_data: Dict, previous_data: Dict, year_ago_data: Dict) -> Dict[str, Any]:
        """生成详细的结构化分析报告"""
        
        # 检查是否有错误
        if "error" in current_data:
            return {
                "executive_summary": "数据获取异常，无法生成完整分析报告",
                "error_info": current_data['error'],
                "recommendations": ["检查网络连接", "验证API服务状态", "联系技术支持团队"]
            }
        
        report = {
            "executive_summary": "",
            "key_metrics": {},
            "performance_analysis": {},
            "trend_analysis": {},
            "payment_analysis": {},
            "company_rankings": {},
            "insights": [],
            "recommendations": [],
            "risk_alerts": []
        }
        
        # 提取基础数据
        if 'data' not in current_data:
            return self._generate_empty_report()
            
        data = current_data['data']
        companies = data.get('payTypeTurnoverList', [])
        total_turnover = data.get('totalTurnover', 0)
        etc_total = data.get('etcTotalTurnover', 0)
        cash_total = data.get('cashTotalTurnover', 0)
        mobile_total = data.get('mobileTotalTurnover', 0)
        
        # 交通流量数据
        traffic_data = current_data.get('trafficFlow', {}).get('data', {})
        traffic_companies = traffic_data.get('payTypeTrafficFlowList', [])
        total_traffic = traffic_data.get('trafficTotalFlow', 0)
        
        # 生成执行摘要
        report["executive_summary"] = self._generate_executive_summary(
            total_turnover, len(companies), etc_total, mobile_total, cash_total
        )
        
        # 关键指标
        report["key_metrics"] = self._generate_key_metrics(
            total_turnover, total_traffic, companies, traffic_companies
        )
        
        # 绩效分析
        report["performance_analysis"] = self._generate_performance_analysis(
            companies, traffic_companies, previous_data, year_ago_data
        )
        
        # 趋势分析
        report["trend_analysis"] = self._generate_trend_analysis(
            current_data, previous_data, year_ago_data
        )
        
        # 支付方式分析
        report["payment_analysis"] = self._generate_payment_analysis(
            etc_total, cash_total, mobile_total, total_turnover, companies
        )
        
        # 分公司排名
        report["company_rankings"] = self._generate_company_rankings(companies, traffic_companies)
        
        # 洞察和建议
        report["insights"] = self._generate_insights(report)
        report["recommendations"] = self._generate_recommendations(report)
        report["risk_alerts"] = self._generate_risk_alerts(report)
        
        return report

    def _generate_executive_summary(self, total_turnover, company_count, etc_total, mobile_total, cash_total):
        """生成执行摘要 - 增强版，提供更全面的业务洞察"""
        if total_turnover == 0:
            return """【数据异常提醒】本期收费数据显示无有效交易记录，这可能由以下原因造成：
            1. 系统维护或技术故障导致数据采集中断
            2. 选择的时间范围内确实无业务发生
            3. 数据传输或存储环节出现问题
            建议：立即核实数据来源、检查系统状态，并联系技术团队进行排查。"""
        
        # 计算核心指标
        total_amount_wan = total_turnover / 10000
        etc_ratio = (etc_total / total_turnover * 100) if total_turnover > 0 else 0
        mobile_ratio = (mobile_total / total_turnover * 100) if total_turnover > 0 else 0
        cash_ratio = (cash_total / total_turnover * 100) if total_turnover > 0 else 0
        avg_company_revenue = total_turnover / company_count if company_count > 0 else 0
        
        summary = f"""【核心业务表现】
        本期收费系统整体运营稳定，{company_count}家分公司协同运营，累计实现通行费收入{total_amount_wan:.2f}万元，
        平均每家分公司贡献收入{avg_company_revenue/10000:.2f}万元。
        
        【支付生态分析】
        支付结构呈现"""
        
        if etc_ratio > 70:
            summary += f"高度数字化特征，ETC支付占绝对主导地位({etc_ratio:.1f}%)，表明智慧交通基础设施建设成效卓著，"
            summary += "用户接受度高，系统运行效率优良。"
        elif etc_ratio > 50:
            summary += f"数字化转型成效显著，ETC支付占主要份额({etc_ratio:.1f}%)，但仍有进一步提升空间。"
        else:
            summary += f"传统与现代支付方式并存的格局，ETC支付占比{etc_ratio:.1f}%，数字化转型仍需加速推进。"
            
        if mobile_ratio > 25:
            summary += f"移动支付表现亮眼({mobile_ratio:.1f}%)，反映出用户对便民支付方式的强烈需求和良好适应性。"
        elif mobile_ratio > 10:
            summary += f"移动支付稳步发展({mobile_ratio:.1f}%)，显示出良好的增长潜力。"
            
        if cash_ratio > 30:
            summary += f"现金支付占比仍然较高({cash_ratio:.1f}%)，提示需要加强电子支付推广和用户教育工作。"
            
        # 添加运营效率评估
        summary += f"""
        
        【运营效率评估】
        从收入分布来看，平均单家分公司收入水平为{avg_company_revenue/10000:.2f}万元，"""
        
        if avg_company_revenue > 500000:  # 50万元
            summary += "各分公司运营效率较高，收入贡献均衡。"
        elif avg_company_revenue > 200000:  # 20万元
            summary += "整体运营水平良好，但存在进一步优化空间。"
        else:
            summary += "部分分公司运营效率有待提升，建议加强业务指导和资源配置优化。"
            
        return summary
    
    def _generate_analysis_text(self, current_data: Dict, previous_data: Dict, year_ago_data: Dict) -> str:
        """生成分析文字 - 保持向后兼容"""
        detailed_report = self._generate_detailed_analysis(current_data, previous_data, year_ago_data)
        
        # 将结构化报告转换为文本格式
        analysis_parts = []
        
        # 执行摘要
        if detailed_report.get("executive_summary"):
            analysis_parts.append("【执行摘要】")
            analysis_parts.append(detailed_report["executive_summary"])
            analysis_parts.append("")
        
        # 关键指标
        key_metrics = detailed_report.get("key_metrics", {})
        if key_metrics:
            analysis_parts.append("【关键绩效指标】")
            for metric, value in key_metrics.items():
                analysis_parts.append(f"• {metric}: {value}")
            analysis_parts.append("")
        
        # 绩效分析
        performance = detailed_report.get("performance_analysis", {})
        if performance:
            analysis_parts.append("【绩效表现分析】")
            for key, value in performance.items():
                if isinstance(value, str):
                    analysis_parts.append(f"• {key}: {value}")
            analysis_parts.append("")
        
        # 支付分析
        payment = detailed_report.get("payment_analysis", {})
        if payment:
            analysis_parts.append("【支付方式分析】")
            for key, value in payment.items():
                if isinstance(value, str):
                    analysis_parts.append(f"• {key}: {value}")
            analysis_parts.append("")
        
        # 洞察和建议
        insights = detailed_report.get("insights", [])
        if insights:
            analysis_parts.append("【关键洞察】")
            for insight in insights:
                analysis_parts.append(f"• {insight}")
            analysis_parts.append("")
        
        recommendations = detailed_report.get("recommendations", [])
        if recommendations:
            analysis_parts.append("【改进建议】")
            for rec in recommendations:
                analysis_parts.append(f"• {rec}")
        
        return "\n".join(analysis_parts) if analysis_parts else self._generate_fallback_analysis()

    def _generate_fallback_analysis(self):
        """生成默认分析内容"""
        return """【报告说明】
本期收费数据分析报告已生成完成，但由于数据源连接异常，无法获取详细的业务数据进行深度分析。

【可能原因】
• 外部API服务暂时不可用
• 网络连接存在问题  
• 选择的时间范围内无有效数据

【建议措施】
• 检查网络连接状态
• 验证API服务可用性
• 尝试选择其他时间范围
• 联系技术支持团队协助排查"""

    def _generate_empty_report(self):
        """生成空报告"""
        return {
            "executive_summary": "暂无有效数据，无法生成分析报告",
            "key_metrics": {},
            "performance_analysis": {},
            "trend_analysis": {},
            "payment_analysis": {},
            "company_rankings": {},
            "insights": ["数据获取异常"],
            "recommendations": ["检查数据源连接"],
            "risk_alerts": []
        }

    def _generate_key_metrics(self, total_turnover, total_traffic, companies, traffic_companies):
        """生成关键指标 - 增强版多维度指标体系"""
        metrics = {}
        
        # === 核心财务指标 ===
        if total_turnover > 0:
            metrics["总收入"] = f"{total_turnover/10000:.2f}万元"
            metrics["平均单车收入"] = f"{total_turnover/max(total_traffic, 1):.2f}元" if total_traffic > 0 else "N/A"
            
            # 收入质量指标
            if companies:
                revenues = [comp.get('turnover', 0) for comp in companies]
                max_revenue = max(revenues) if revenues else 0
                min_revenue = min(revenues) if revenues else 0
                revenue_std = (sum([(r - total_turnover/len(companies))**2 for r in revenues]) / len(revenues))**0.5 if len(companies) > 1 else 0
                
                metrics["收入集中度"] = f"{(max_revenue/total_turnover*100):.1f}%" if total_turnover > 0 else "N/A"
                metrics["收入均衡度"] = "优秀" if revenue_std < total_turnover/len(companies)*0.3 else ("良好" if revenue_std < total_turnover/len(companies)*0.6 else "待改善")
                metrics["收入差异系数"] = f"{(revenue_std/(total_turnover/len(companies))):.2f}" if total_turnover > 0 else "N/A"
        
        # === 运营效率指标 ===
        if total_traffic > 0:
            metrics["总车流量"] = f"{total_traffic:,}辆"
            
            # 车流效率分析
            if traffic_companies:
                traffic_flows = [comp.get('trafficFlow', 0) for comp in traffic_companies]
                max_traffic = max(traffic_flows) if traffic_flows else 0
                avg_traffic = sum(traffic_flows) / len(traffic_flows) if traffic_flows else 0
                
                metrics["最高单点车流"] = f"{max_traffic:,}辆"
                metrics["平均单点车流"] = f"{avg_traffic:,.0f}辆"
                
                # 车流分布均衡度
                if len(traffic_flows) > 1:
                    traffic_std = (sum([(t - avg_traffic)**2 for t in traffic_flows]) / len(traffic_flows))**0.5
                    cv = traffic_std / avg_traffic if avg_traffic > 0 else 0
                    metrics["车流分布均衡度"] = "优秀" if cv < 0.3 else ("良好" if cv < 0.6 else "待优化")
        
        # === 组织效率指标 ===
        if companies:
            metrics["参与分公司"] = f"{len(companies)}家"
            avg_revenue = total_turnover / len(companies) if len(companies) > 0 else 0
            metrics["平均分公司收入"] = f"{avg_revenue/10000:.2f}万元"
            
            # 分公司效率评级
            high_performers = len([c for c in companies if c.get('turnover', 0) > avg_revenue * 1.2])
            low_performers = len([c for c in companies if c.get('turnover', 0) < avg_revenue * 0.8])
            
            metrics["高效分公司占比"] = f"{(high_performers/len(companies)*100):.1f}%"
            metrics["待提升分公司占比"] = f"{(low_performers/len(companies)*100):.1f}%"
            
            # 组织健康度评估
            if high_performers > len(companies) * 0.3:
                metrics["组织健康度"] = "优秀"
            elif high_performers > len(companies) * 0.2:
                metrics["组织健康度"] = "良好" 
            else:
                metrics["组织健康度"] = "需关注"
        
        # === 技术渗透指标 ===
        if total_turnover > 0 and companies:
            # 计算ETC和移动支付渗透情况
            etc_companies = len([c for c in companies if c.get('etcTurnover', 0) > c.get('turnover', 1) * 0.5])
            mobile_companies = len([c for c in companies if c.get('mobileTurnover', 0) > c.get('turnover', 1) * 0.2])
            
            metrics["ETC高渗透分公司"] = f"{etc_companies}家"
            metrics["移动支付活跃分公司"] = f"{mobile_companies}家"
            metrics["数字化转型进度"] = f"{((etc_companies + mobile_companies)/(len(companies)*2)*100):.1f}%"
        
        # === 市场表现指标 ===
        if total_traffic > 0 and total_turnover > 0:
            # 市场效率指标
            market_efficiency = (total_turnover / 10000) / (total_traffic / 10000)  # 万元/万辆
            metrics["市场效率指数"] = f"{market_efficiency:.2f}"
            
            # 服务覆盖度（基于分公司数量）
            if companies:
                service_coverage = len(companies) / 50 * 100  # 假设理论最大50家分公司
                metrics["服务覆盖度"] = f"{min(service_coverage, 100):.1f}%"
        
        return metrics

    def _generate_performance_analysis(self, companies, traffic_companies, previous_data, year_ago_data):
        """生成绩效分析 - 增强版多维度绩效评估"""
        analysis = {}
        
        if not companies:
            return {"状态": "无有效数据"}
        
        # === 基础绩效排名 ===
        revenues = [comp.get('turnover', 0) for comp in companies]
        avg_revenue = sum(revenues) / len(revenues) if revenues else 0
        
        best_company = max(companies, key=lambda x: x.get('turnover', 0))
        worst_company = min(companies, key=lambda x: x.get('turnover', 0))
        
        analysis["绩效冠军"] = f"{best_company['unitName']}以{best_company['turnover']/10000:.2f}万元位居榜首，超出平均水平{((best_company['turnover']-avg_revenue)/avg_revenue*100):.1f}%"
        analysis["提升标杆"] = f"{worst_company['unitName']}收入{worst_company['turnover']/10000:.2f}万元，相比平均水平有{((avg_revenue-worst_company['turnover'])/avg_revenue*100):.1f}%的提升空间"
        
        # === 绩效分层分析 ===
        above_avg = len([r for r in revenues if r > avg_revenue])
        top_tier = len([r for r in revenues if r > avg_revenue * 1.5])  # 优秀层
        bottom_tier = len([r for r in revenues if r < avg_revenue * 0.5])  # 待提升层
        
        analysis["绩效分布"] = f"优秀层{top_tier}家({top_tier/len(companies)*100:.1f}%)，达标层{above_avg-top_tier}家，待提升层{bottom_tier}家({bottom_tier/len(companies)*100:.1f}%)"
        
        # === 同比环比分析 ===
        current_total = sum(revenues)
        
        # 环比分析
        if 'data' in previous_data and 'payTypeTurnoverList' in previous_data['data']:
            prev_companies = previous_data['data']['payTypeTurnoverList']
            prev_total = sum([comp.get('turnover', 0) for comp in prev_companies])
            if prev_total > 0:
                mom_growth = ((current_total - prev_total) / prev_total) * 100
                analysis["环比表现"] = f"相比上期{'增长' if mom_growth > 0 else '下降'}{abs(mom_growth):.1f}%，"
                if mom_growth > 10:
                    analysis["环比表现"] += "表现卓越"
                elif mom_growth > 5:
                    analysis["环比表现"] += "稳步增长"
                elif mom_growth > -5:
                    analysis["环比表现"] += "基本稳定"
                else:
                    analysis["环比表现"] += "需重点关注"
        
        # 同比分析
        if 'data' in year_ago_data and 'payTypeTurnoverList' in year_ago_data['data']:
            year_ago_companies = year_ago_data['data']['payTypeTurnoverList']
            year_ago_total = sum([comp.get('turnover', 0) for comp in year_ago_companies])
            if year_ago_total > 0:
                yoy_growth = ((current_total - year_ago_total) / year_ago_total) * 100
                analysis["同比表现"] = f"相比去年同期{'增长' if yoy_growth > 0 else '下降'}{abs(yoy_growth):.1f}%，"
                if yoy_growth > 15:
                    analysis["同比表现"] += "业务快速发展"
                elif yoy_growth > 8:
                    analysis["同比表现"] += "持续健康增长"
                elif yoy_growth > 0:
                    analysis["同比表现"] += "温和增长态势"
                else:
                    analysis["同比表现"] += "面临增长压力"
        
        # === 效率对标分析 ===
        if traffic_companies:
            # 计算收入效率（收入/车流量）
            efficiency_data = []
            for company in companies:
                traffic_comp = next((tc for tc in traffic_companies if tc['unitName'] == company['unitName']), None)
                if traffic_comp and traffic_comp.get('trafficFlow', 0) > 0:
                    efficiency = company['turnover'] / traffic_comp['trafficFlow']
                    efficiency_data.append({
                        'name': company['unitName'],
                        'efficiency': efficiency,
                        'revenue': company['turnover'],
                        'traffic': traffic_comp['trafficFlow']
                    })
            
            if efficiency_data:
                efficiency_data.sort(key=lambda x: x['efficiency'], reverse=True)
                best_efficiency = efficiency_data[0]
                worst_efficiency = efficiency_data[-1]
                avg_efficiency = sum([e['efficiency'] for e in efficiency_data]) / len(efficiency_data)
                
                analysis["效率标杆"] = f"{best_efficiency['name']}单车收入{best_efficiency['efficiency']:.2f}元，运营效率最高"
                analysis["效率洼地"] = f"{worst_efficiency['name']}单车收入{worst_efficiency['efficiency']:.2f}元，有{((avg_efficiency-worst_efficiency['efficiency'])/avg_efficiency*100):.1f}%提升空间"
                
                # 效率分级
                high_eff = len([e for e in efficiency_data if e['efficiency'] > avg_efficiency * 1.2])
                low_eff = len([e for e in efficiency_data if e['efficiency'] < avg_efficiency * 0.8])
                analysis["效率分级"] = f"高效运营{high_eff}家，标准运营{len(efficiency_data)-high_eff-low_eff}家，待优化{low_eff}家"
        
        # === 区域竞争力分析 ===
        # 按收入规模分组分析
        large_companies = [c for c in companies if c['turnover'] > avg_revenue * 1.5]
        medium_companies = [c for c in companies if avg_revenue * 0.7 <= c['turnover'] <= avg_revenue * 1.5]
        small_companies = [c for c in companies if c['turnover'] < avg_revenue * 0.7]
        
        analysis["规模结构"] = f"大型分公司{len(large_companies)}家(贡献{sum([c['turnover'] for c in large_companies])/current_total*100:.1f}%)，"
        analysis["规模结构"] += f"中型{len(medium_companies)}家，小型{len(small_companies)}家"
        
        # === 增长潜力评估 ===
        growth_potential = []
        if traffic_companies:
            for company in companies:
                traffic_comp = next((tc for tc in traffic_companies if tc['unitName'] == company['unitName']), None)
                if traffic_comp:
                    # 基于车流量和收入的潜力评估
                    traffic_rank = sorted(traffic_companies, key=lambda x: x.get('trafficFlow', 0), reverse=True).index(traffic_comp) + 1
                    revenue_rank = sorted(companies, key=lambda x: x.get('turnover', 0), reverse=True).index(company) + 1
                    
                    if traffic_rank < revenue_rank:  # 车流高但收入排名低，有潜力
                        potential_score = revenue_rank - traffic_rank
                        growth_potential.append({
                            'name': company['unitName'],
                            'potential': potential_score,
                            'reason': f"车流排名第{traffic_rank}位，收入排名第{revenue_rank}位"
                        })
        
        if growth_potential:
            growth_potential.sort(key=lambda x: x['potential'], reverse=True)
            top_potential = growth_potential[0]
            analysis["增长潜力"] = f"{top_potential['name']}具有最大增长潜力，{top_potential['reason']}"
        
        return analysis

    def _generate_trend_analysis(self, current_data, previous_data, year_ago_data):
        """生成趋势分析 - 增强版多层次趋势洞察"""
        analysis = {}
        
        current_total = current_data.get('data', {}).get('totalTurnover', 0)
        current_companies = current_data.get('data', {}).get('payTypeTurnoverList', [])
        
        # === 总体趋势分析 ===
        trend_signals = []
        
        # 环比分析
        if 'data' in previous_data and 'totalTurnover' in previous_data['data']:
            prev_total = previous_data['data']['totalTurnover']
            if prev_total > 0:
                mom_growth = ((current_total - prev_total) / prev_total) * 100
                trend_direction = "增长" if mom_growth > 0 else "下降"
                
                analysis["短期趋势"] = f"环比{trend_direction}{abs(mom_growth):.1f}%，"
                if abs(mom_growth) > 15:
                    analysis["短期趋势"] += "波动较大，需关注异常因素"
                    trend_signals.append("高波动")
                elif abs(mom_growth) > 8:
                    analysis["短期趋势"] += "变化明显，趋势较为显著"
                    trend_signals.append("明显变化")
                elif abs(mom_growth) > 3:
                    analysis["短期趋势"] += "温和调整，运行相对平稳"
                    trend_signals.append("温和调整")
                else:
                    analysis["短期趋势"] += "基本稳定，延续既有态势"
                    trend_signals.append("稳定运行")
        
        # 同比分析
        if 'data' in year_ago_data and 'totalTurnover' in year_ago_data['data']:
            year_ago_total = year_ago_data['data']['totalTurnover']
            if year_ago_total > 0:
                yoy_growth = ((current_total - year_ago_total) / year_ago_total) * 100
                trend_direction = "增长" if yoy_growth > 0 else "下降"
                
                analysis["中长期趋势"] = f"同比{trend_direction}{abs(yoy_growth):.1f}%，"
                if yoy_growth > 20:
                    analysis["中长期趋势"] += "高速增长期，业务扩张迅猛"
                    trend_signals.append("高速增长")
                elif yoy_growth > 10:
                    analysis["中长期趋势"] += "快速增长期，发展势头良好"
                    trend_signals.append("快速增长")
                elif yoy_growth > 5:
                    analysis["中长期趋势"] += "稳健增长期，持续向好发展"
                    trend_signals.append("稳健增长")
                elif yoy_growth > 0:
                    analysis["中长期趋势"] += "缓慢增长期，增长动力有限"
                    trend_signals.append("缓慢增长")
                elif yoy_growth > -5:
                    analysis["中长期趋势"] += "调整期，需要寻找新增长点"
                    trend_signals.append("调整期")
                else:
                    analysis["中长期趋势"] += "下行期，面临较大挑战"
                    trend_signals.append("下行压力")
        
        # === 结构性趋势分析 ===
        if current_companies and 'data' in previous_data and 'payTypeTurnoverList' in previous_data['data']:
            prev_companies = previous_data['data']['payTypeTurnoverList']
            
            # 分析各分公司趋势
            company_trends = []
            for curr_comp in current_companies:
                prev_comp = next((pc for pc in prev_companies if pc['unitName'] == curr_comp['unitName']), None)
                if prev_comp and prev_comp.get('turnover', 0) > 0:
                    growth = ((curr_comp['turnover'] - prev_comp['turnover']) / prev_comp['turnover']) * 100
                    company_trends.append({
                        'name': curr_comp['unitName'],
                        'growth': growth,
                        'current': curr_comp['turnover'],
                        'previous': prev_comp['turnover']
                    })
            
            if company_trends:
                # 增长分化分析
                positive_growth = [ct for ct in company_trends if ct['growth'] > 0]
                negative_growth = [ct for ct in company_trends if ct['growth'] < 0]
                
                analysis["增长分化"] = f"{len(positive_growth)}家分公司实现增长，{len(negative_growth)}家出现下滑，"
                
                if len(positive_growth) > len(company_trends) * 0.7:
                    analysis["增长分化"] += "整体向上趋势明显"
                elif len(positive_growth) > len(company_trends) * 0.5:
                    analysis["增长分化"] += "增长面基本均衡"
                else:
                    analysis["增长分化"] += "下行压力较为突出"
                
                # 找出增长最快和最慢的
                if positive_growth:
                    fastest_growth = max(positive_growth, key=lambda x: x['growth'])
                    analysis["增长领跑者"] = f"{fastest_growth['name']}增长{fastest_growth['growth']:.1f}%，表现最为亮眼"
                
                if negative_growth:
                    slowest_growth = min(negative_growth, key=lambda x: x['growth'])
                    analysis["关注重点"] = f"{slowest_growth['name']}下降{abs(slowest_growth['growth']):.1f}%，需要重点关注"
        
        # === 支付方式趋势分析 ===
        current_etc = current_data.get('data', {}).get('etcTotalTurnover', 0)
        current_mobile = current_data.get('data', {}).get('mobileTotalTurnover', 0)
        current_cash = current_data.get('data', {}).get('cashTotalTurnover', 0)
        
        if 'data' in previous_data:
            prev_etc = previous_data['data'].get('etcTotalTurnover', 0)
            prev_mobile = previous_data['data'].get('mobileTotalTurnover', 0)
            prev_cash = previous_data['data'].get('cashTotalTurnover', 0)
            
            payment_trends = []
            if prev_etc > 0:
                etc_growth = ((current_etc - prev_etc) / prev_etc) * 100
                payment_trends.append(f"ETC支付{'增长' if etc_growth > 0 else '下降'}{abs(etc_growth):.1f}%")
            
            if prev_mobile > 0:
                mobile_growth = ((current_mobile - prev_mobile) / prev_mobile) * 100
                payment_trends.append(f"移动支付{'增长' if mobile_growth > 0 else '下降'}{abs(mobile_growth):.1f}%")
            
            if prev_cash > 0:
                cash_growth = ((current_cash - prev_cash) / prev_cash) * 100
                payment_trends.append(f"现金支付{'增长' if cash_growth > 0 else '下降'}{abs(cash_growth):.1f}%")
            
            if payment_trends:
                analysis["支付趋势"] = "，".join(payment_trends)
        
        # === 趋势预测与预警 ===
        prediction = []
        
        if "高速增长" in trend_signals:
            prediction.append("预计短期内将维持强劲增长态势，需要做好资源配置和服务保障")
        elif "稳健增长" in trend_signals:
            prediction.append("预计将保持稳定增长轨道，可考虑适度扩大业务规模")
        elif "调整期" in trend_signals or "下行压力" in trend_signals:
            prediction.append("预计面临持续调整压力，建议加强市场分析和策略调整")
        
        if "高波动" in trend_signals:
            prediction.append("短期波动较大，需密切监控市场变化和异常因素")
        
        if prediction:
            analysis["趋势预测"] = "；".join(prediction)
        
        # === 周期性分析 ===
        # 这里可以根据历史数据分析季节性特征（需要更多历史数据支持）
        import datetime
        current_month = datetime.datetime.now().month
        
        seasonal_insight = ""
        if current_month in [1, 2]:
            seasonal_insight = "春节期间，车流量通常呈现节前集中、节后回落的特征"
        elif current_month in [7, 8]:
            seasonal_insight = "暑期旺季，旅游出行增多，车流量一般处于年内高峰期" 
        elif current_month in [9, 10]:
            seasonal_insight = "秋季是传统的业务旺季，各项指标通常表现较好"
        elif current_month in [11, 12]:
            seasonal_insight = "年末冲刺期，各分公司通常会加大业务推进力度"
        else:
            seasonal_insight = "当前处于业务常规运营期"
        
        if seasonal_insight:
            analysis["季节特征"] = seasonal_insight
        
        return analysis

    def _generate_payment_analysis(self, etc_total, cash_total, mobile_total, total_turnover, companies):
        """生成支付方式分析 - 增强版用户行为和技术渗透分析"""
        analysis = {}
        
        if total_turnover == 0:
            return {"状态": "无支付数据"}
        
        # === 基础支付结构分析 ===
        etc_ratio = (etc_total / total_turnover) * 100
        cash_ratio = (cash_total / total_turnover) * 100
        mobile_ratio = (mobile_total / total_turnover) * 100
        
        analysis["ETC支付"] = f"{etc_ratio:.1f}%，收入{etc_total/10000:.2f}万元"
        analysis["现金支付"] = f"{cash_ratio:.1f}%，收入{cash_total/10000:.2f}万元"
        analysis["移动支付"] = f"{mobile_ratio:.1f}%，收入{mobile_total/10000:.2f}万元"
        
        # === 支付生态健康度评估 ===
        digital_ratio = etc_ratio + mobile_ratio  # 数字化支付占比
        
        if digital_ratio > 80:
            analysis["数字化水平"] = f"高度数字化({digital_ratio:.1f}%)，支付生态现代化程度优秀"
        elif digital_ratio > 60:
            analysis["数字化水平"] = f"数字化良好({digital_ratio:.1f}%)，电子支付已成为主流"
        elif digital_ratio > 40:
            analysis["数字化水平"] = f"数字化转型中({digital_ratio:.1f}%)，仍有较大提升空间"
        else:
            analysis["数字化水平"] = f"数字化起步阶段({digital_ratio:.1f}%)，亟需加速转型"
        
        # === 用户行为洞察 ===
        user_behavior = []
        
        if etc_ratio > 50:
            user_behavior.append("ETC用户群体庞大，显示高速公路常旅客占主导")
            if etc_ratio > 70:
                user_behavior.append("ETC高渗透率反映用户对便捷通行的强烈需求")
        
        if mobile_ratio > 20:
            user_behavior.append("移动支付活跃，年轻用户群体和临时通行需求显著")
            if mobile_ratio > 35:
                user_behavior.append("移动支付高占比体现了支付习惯的快速迁移")
        
        if cash_ratio > 25:
            user_behavior.append("现金支付仍有一定市场，主要服务传统用户群体")
            if cash_ratio > 40:
                user_behavior.append("现金支付占比较高，提示数字化推广仍需加强")
        
        if user_behavior:
            analysis["用户行为特征"] = "；".join(user_behavior)
        
        # === 技术渗透率分析 ===
        if companies:
            # 分析各分公司的支付方式分布
            etc_leaders = []  # ETC渗透率高的分公司
            mobile_pioneers = []  # 移动支付先锋分公司
            digital_laggards = []  # 数字化滞后分公司
        
            for company in companies:
                comp_total = company.get('turnover', 0)
                if comp_total > 0:
                    comp_etc_ratio = (company.get('etcTurnover', 0) / comp_total) * 100
                    comp_mobile_ratio = (company.get('mobileTurnover', 0) / comp_total) * 100
                    comp_digital_ratio = comp_etc_ratio + comp_mobile_ratio
                    
                    if comp_etc_ratio > 70:
                        etc_leaders.append(company['unitName'])
                    
                    if comp_mobile_ratio > 30:
                        mobile_pioneers.append(company['unitName'])
                    
                    if comp_digital_ratio < 40:
                        digital_laggards.append(company['unitName'])
        
            if etc_leaders:
                analysis["ETC标杆"] = f"{len(etc_leaders)}家分公司ETC渗透率超过70%，包括{', '.join(etc_leaders[:3])}等"
        
            if mobile_pioneers:
                analysis["移动支付先锋"] = f"{len(mobile_pioneers)}家分公司移动支付占比超过30%，数字化创新活跃"
        
            if digital_laggards:
                analysis["数字化提升重点"] = f"{len(digital_laggards)}家分公司数字化率不足40%，需要重点帮扶"
        
        # === 支付效率分析 ===
        # 假设不同支付方式的处理效率不同
        efficiency_score = etc_ratio * 1.0 + mobile_ratio * 0.9 + cash_ratio * 0.6  # 效率权重
        
        if efficiency_score > 85:
            analysis["支付效率"] = f"支付效率优秀(评分{efficiency_score:.1f})，电子支付占主导提升整体通行效率"
        elif efficiency_score > 70:
            analysis["支付效率"] = f"支付效率良好(评分{efficiency_score:.1f})，有进一步优化空间"
        else:
            analysis["支付效率"] = f"支付效率有待提升(评分{efficiency_score:.1f})，建议推广高效支付方式"
        
        # === 市场竞争力分析 ===
        # 基于支付方式多样性评估服务竞争力
        payment_diversity = 0
        if etc_ratio > 10: payment_diversity += 1
        if mobile_ratio > 10: payment_diversity += 1
        if cash_ratio > 10: payment_diversity += 1
        
        if payment_diversity == 3:
            analysis["服务包容性"] = "支付方式全覆盖，服务包容性强，满足不同用户群体需求"
        elif payment_diversity == 2:
            analysis["服务包容性"] = "支付方式较为丰富，基本满足主流用户需求"
        else:
            analysis["服务包容性"] = "支付方式相对单一，建议丰富支付选择"
        
        # === 发展趋势预判 ===
        trend_prediction = []
        
        if mobile_ratio > 25 and mobile_ratio < 50:
            trend_prediction.append("移动支付仍有较大增长潜力，预计将继续快速发展")
        
        if etc_ratio > 60:
            trend_prediction.append("ETC支付已达到较高水平，重点转向服务质量提升")
        elif etc_ratio > 40:
            trend_prediction.append("ETC支付有望进一步提升，建议加大推广力度")
        
        if cash_ratio > 30:
            trend_prediction.append("现金支付占比较高，数字化转型仍有较大空间")
        
        if trend_prediction:
            analysis["发展趋势"] = "；".join(trend_prediction)
        
        return analysis

    def _generate_company_rankings(self, companies, traffic_companies):
        """生成分公司排名"""
        rankings = {}
        
        if companies:
            # 按收入排序
            sorted_by_revenue = sorted(companies, key=lambda x: x['turnover'], reverse=True)
            rankings["收入排名"] = [f"{i+1}. {comp['unitName']}({comp['turnover']/10000:.2f}万元)" 
                                for i, comp in enumerate(sorted_by_revenue[:5])]
        
        if traffic_companies:
            # 按车流量排序
            sorted_by_traffic = sorted(traffic_companies, key=lambda x: x['trafficFlow'], reverse=True)
            rankings["车流量排名"] = [f"{i+1}. {comp['unitName']}({comp['trafficFlow']:,}辆)" 
                                 for i, comp in enumerate(sorted_by_traffic[:5])]
        
        return rankings

    def _generate_insights(self, report):
        """生成关键洞察 - 增强版深度业务洞察"""
        insights = []
        
        key_metrics = report.get("key_metrics", {})
        payment_analysis = report.get("payment_analysis", {})
        performance_analysis = report.get("performance_analysis", {})
        trend_analysis = report.get("trend_analysis", {})
        
        # === 运营效率洞察 ===
        if "组织健康度" in key_metrics:
            health = key_metrics["组织健康度"]
            if health == "优秀":
                insights.append("🎯 组织运营效率优秀，高效分公司占比较高，形成了良好的示范效应和竞争氛围")
            elif health == "需关注":
                insights.append("⚠️ 组织运营效率有待提升，建议加强分公司间的经验交流和业务指导")
        
        if "收入均衡度" in key_metrics:
            balance = key_metrics["收入均衡度"]
            if balance == "优秀":
                insights.append("📊 收入分布均衡，各分公司发展相对协调，区域发展差异较小")
            elif balance == "待改善":
                insights.append("📈 收入分布不均，存在明显的分化现象，需要重点关注落后地区的发展")
        
        # === 数字化转型洞察 ===
        if "数字化转型进度" in key_metrics:
            progress_str = key_metrics["数字化转型进度"]
            if "%" in progress_str:
                try:
                    progress = float(progress_str.split("%")[0])
                    if progress > 70:
                        insights.append("🚀 数字化转型成效卓著，电子支付生态基本建立，为未来智慧交通发展奠定坚实基础")
                    elif progress > 50:
                        insights.append("💡 数字化转型进展良好，但仍需持续推进，特别是在移动支付和ETC普及方面")
                    else:
                        insights.append("🔧 数字化转型仍在起步阶段，建议制定系统性的数字化升级策略")
                except:
                    pass
        
        # === 市场竞争力洞察 ===
        if "市场效率指数" in key_metrics:
            efficiency_str = key_metrics["市场效率指数"]
            try:
                efficiency = float(efficiency_str)
                if efficiency > 5:
                    insights.append("💰 单车收入效率较高，定价策略和收费标准相对合理，市场竞争力强")
                elif efficiency < 2:
                    insights.append("💸 单车收入效率偏低，建议优化收费结构或提升服务价值")
            except:
                pass
        
        # === 增长质量洞察 ===
        if "同比表现" in performance_analysis:
            yoy_info = performance_analysis["同比表现"]
            if "业务快速发展" in yoy_info:
                insights.append("📈 业务呈现高质量快速增长态势，发展动能强劲，前景乐观")
            elif "面临增长压力" in yoy_info:
                insights.append("📉 业务增长面临挑战，需要深入分析下滑原因，制定针对性的应对措施")
        
        if "增长分化" in performance_analysis:
            divergence = performance_analysis["增长分化"]
            if "整体向上趋势明显" in divergence:
                insights.append("🌟 各分公司普遍实现增长，形成了良性的发展格局，整体竞争力提升")
            elif "下行压力较为突出" in divergence:
                insights.append("⚡ 分公司间分化加剧，多数面临下行压力，需要系统性的振兴策略")
        
        # === 用户行为洞察 ===
        if "用户行为特征" in payment_analysis:
            behavior = payment_analysis["用户行为特征"]
            if "年轻用户群体" in behavior:
                insights.append("👥 移动支付活跃反映用户结构年轻化趋势，为数字化服务创新提供了良好基础")
            if "常旅客占主导" in behavior:
                insights.append("🚗 ETC用户占主导显示客户黏性较强，可考虑开发增值服务提升客户价值")
        
        # === 技术创新洞察 ===
        if "移动支付先锋" in payment_analysis:
            pioneers = payment_analysis["移动支付先锋"]
            if "数字化创新活跃" in pioneers:
                insights.append("🔥 部分分公司在移动支付创新方面表现突出，形成了技术创新的示范效应")
        
        # === 风险预警洞察 ===
        if "趋势预测" in trend_analysis:
            prediction = trend_analysis["趋势预测"]
            if "密切监控" in prediction:
                insights.append("⚠️ 市场波动加大，不确定性因素增多，需要建立更加敏感的监控预警机制")
            if "策略调整" in prediction:
                insights.append("🎯 面临调整压力，建议及时评估现有策略的有效性，适时进行战略调整")
        
        # === 季节性业务洞察 ===
        if "季节特征" in trend_analysis:
            seasonal = trend_analysis["季节特征"]
            if "旺季" in seasonal:
                insights.append("🌞 当前处于业务旺季，建议充分利用有利时机，加大市场拓展和服务优化力度")
            elif "冲刺期" in seasonal:
                insights.append("🏃 年末冲刺期，各项指标冲刺目标的关键时期，需要统筹资源确保目标达成")
        
        # === 综合性战略洞察 ===
        # 基于多个维度的综合分析
        digital_signals = 0
        growth_signals = 0
        efficiency_signals = 0
        
        if "数字化水平" in payment_analysis and ("优秀" in payment_analysis["数字化水平"] or "良好" in payment_analysis["数字化水平"]):
            digital_signals += 1
        if "业务快速发展" in str(performance_analysis) or "稳健增长" in str(performance_analysis):
            growth_signals += 1
        if "组织健康度" in key_metrics and key_metrics["组织健康度"] in ["优秀", "良好"]:
            efficiency_signals += 1
        
        if digital_signals + growth_signals + efficiency_signals >= 2:
            insights.append("🏆 综合各项指标表现，当前处于良好的发展阶段，具备了向更高水平跃升的基础条件")
        elif digital_signals + growth_signals + efficiency_signals == 1:
            insights.append("⚖️ 发展态势总体平稳，但在数字化、增长质量、运营效率等方面仍有提升空间")
        else:
            insights.append("🔄 当前面临多重挑战，建议系统性地审视发展策略，寻找新的增长突破点")
        
        return insights or ["📋 数据分析完成，各项指标运行正常，建议持续监控关键业务指标变化"]

    def _generate_recommendations(self, report):
        """生成改进建议 - 增强版系统性改进建议"""
        recommendations = []
        
        key_metrics = report.get("key_metrics", {})
        payment_analysis = report.get("payment_analysis", {})
        performance_analysis = report.get("performance_analysis", {})
        trend_analysis = report.get("trend_analysis", {})
        
        # === 数字化转型建议 ===
        if "数字化水平" in payment_analysis:
            digital_level = payment_analysis["数字化水平"]
            if "起步阶段" in digital_level or "转型中" in digital_level:
                recommendations.extend([
                    "🚀 制定系统性数字化转型规划，设定分阶段目标和关键里程碑",
                    "💳 加大ETC设备投入和推广力度，提升用户办理便利性",
                    "📱 优化移动支付体验，支持多种主流支付平台",
                    "👨‍🏫 开展数字化支付用户教育，特别是针对传统用户群体"
                ])
        
        if "数字化提升重点" in payment_analysis:
            recommendations.append("🎯 针对数字化滞后的分公司，制定专项帮扶计划，提供技术支持和培训")
        
        # === 运营效率提升建议 ===
        if "组织健康度" in key_metrics:
            health = key_metrics["组织健康度"]
            if health in ["需关注", "待改善"]:
                recommendations.extend([
                    "📊 建立分公司绩效评估体系，定期开展运营效率对标分析",
                    "🤝 促进优秀分公司与落后分公司的经验交流和帮扶合作",
                    "📈 制定分公司分类管理策略，实施差异化的考核和激励机制"
                ])
        
        if "收入均衡度" in key_metrics and key_metrics["收入均衡度"] == "待改善":
            recommendations.extend([
                "⚖️ 分析收入差异的根本原因，制定区域均衡发展策略",
                "🎯 加大对落后地区的资源投入和政策倾斜",
                "🌐 推进区域协调发展，促进优势资源共享"
            ])
        
        # === 绩效改进建议 ===
        if "效率洼地" in performance_analysis:
            recommendations.append("🔧 针对运营效率较低的分公司，开展深度诊断，识别改进关键点")
        
        if "增长潜力" in performance_analysis:
            recommendations.append("💎 重点培育具有增长潜力的分公司，提供资源支持和业务指导")
        
        if "同比表现" in performance_analysis:
            yoy_info = performance_analysis["同比表现"]
            if "面临增长压力" in yoy_info or "下降" in yoy_info:
                recommendations.extend([
                    "📉 深入分析业务下滑的内外部因素，制定针对性的应对策略",
                    "🔄 适时调整业务策略和运营模式，寻找新的增长点",
                    "💪 加强市场竞争力建设，提升服务质量和用户体验"
                ])
        
        # === 市场拓展建议 ===
        if "市场效率指数" in key_metrics:
            try:
                efficiency = float(key_metrics["市场效率指数"])
                if efficiency < 3:
                    recommendations.extend([
                        "💰 优化收费结构和定价策略，提升单车收入水平",
                        "🎁 开发增值服务产品，增加客户价值贡献",
                        "📊 加强市场调研，了解用户需求和支付意愿"
                    ])
            except:
                pass
        
        # === 风险管控建议 ===
        if "趋势预测" in trend_analysis:
            prediction = trend_analysis["趋势预测"]
            if "波动" in prediction or "监控" in prediction:
                recommendations.extend([
                    "⚠️ 建立健全风险预警机制，加强对关键指标的实时监控",
                    "📋 制定应急预案，提升应对市场波动的能力",
                    "🔍 加强数据分析能力，提高决策的前瞻性和科学性"
                ])
        
        # === 技术创新建议 ===
        if "移动支付先锋" in payment_analysis:
            recommendations.extend([
                "🏆 总结移动支付创新的成功经验，在全系统推广应用",
                "🔬 设立技术创新基金，鼓励分公司开展支付技术创新试点",
                "🤖 探索新兴技术应用，如人工智能、大数据等在收费领域的应用"
            ])
        
        # === 用户体验提升建议 ===
        if "服务包容性" in payment_analysis and "单一" in payment_analysis["服务包容性"]:
            recommendations.extend([
                "🌈 丰富支付方式选择，满足不同用户群体的支付偏好",
                "♿ 提升服务包容性，特别关注老年人和残障人士的使用需求",
                "📞 完善客户服务体系，提供多渠道的咨询和投诉处理服务"
            ])
        
        # === 数据驱动决策建议 ===
        recommendations.extend([
            "📊 建立完善的数据治理体系，确保数据质量和安全",
            "🎯 推进数据驱动决策，定期开展业务数据深度分析",
            "📈 建立动态的业务监控仪表板，实时掌握运营状况",
            "🔄 建立持续改进机制，定期评估和优化业务流程"
        ])
        
        # === 人才发展建议 ===
        recommendations.extend([
            "👨‍💼 加强人才队伍建设，提升员工的数字化技能和服务意识",
            "📚 建立系统性的培训体系，定期开展业务技能和管理能力培训",
            "🏅 完善激励机制，激发员工的工作积极性和创新活力"
        ])
        
        # === 战略发展建议 ===
        if len(recommendations) > 15:  # 如果建议较多，说明面临多重挑战
            recommendations.insert(0, "🎯 当前面临多维度的发展挑战，建议制定系统性的转型升级战略，统筹推进各项改进措施")
        
        return recommendations[:20]  # 限制建议数量，避免过多

    def _generate_risk_alerts(self, report):
        """生成风险预警 - 增强版多层次风险监控"""
        alerts = []
        
        key_metrics = report.get("key_metrics", {})
        trend_analysis = report.get("trend_analysis", {})
        performance_analysis = report.get("performance_analysis", {})
        payment_analysis = report.get("payment_analysis", {})
        
        # === 收入风险预警 ===
        if "短期趋势" in trend_analysis:
            trend_info = trend_analysis["短期趋势"]
            if "下降" in trend_info:
                try:
                    decline_rate = float(trend_info.split("下降")[1].split("%")[0])
                    if decline_rate > 15:
                        alerts.append(f"🚨 高风险：收入环比下降{decline_rate:.1f}%，跌幅较大，需立即启动应急响应机制")
                    elif decline_rate > 8:
                        alerts.append(f"⚠️ 中风险：收入环比下降{decline_rate:.1f}%，需密切关注并分析下滑原因")
                    elif decline_rate > 3:
                        alerts.append(f"⚡ 低风险：收入环比下降{decline_rate:.1f}%，建议加强监控")
                except:
                    pass
        
        if "中长期趋势" in trend_analysis:
            yoy_info = trend_analysis["中长期趋势"]
            if "下行期" in yoy_info:
                alerts.append("🚨 高风险：同比持续下滑，业务进入下行周期，需要系统性战略调整")
            elif "调整期" in yoy_info:
                alerts.append("⚠️ 中风险：业务处于调整期，增长动力不足，需寻找新的增长点")
        
        # === 运营效率风险 ===
        if "组织健康度" in key_metrics:
            health = key_metrics["组织健康度"]
            if health == "需关注":
                alerts.append("⚠️ 运营风险：组织运营效率偏低，多数分公司表现不佳，存在管理风险")
        
        if "收入均衡度" in key_metrics:
            balance = key_metrics["收入均衡度"]
            if balance == "待改善":
                alerts.append("📊 结构性风险：收入分布严重不均，区域发展失衡，可能影响整体稳定性")
        
        # === 市场竞争风险 ===
        if "市场效率指数" in key_metrics:
            try:
                efficiency = float(key_metrics["市场效率指数"])
                if efficiency < 1.5:
                    alerts.append("💸 竞争力风险：单车收入效率偏低，市场竞争力不足，盈利能力堪忧")
                elif efficiency < 2.5:
                    alerts.append("📉 效率风险：单车收入效率一般，需要优化运营模式提升效率")
            except:
                pass
        
        # === 技术转型风险 ===
        if "数字化水平" in payment_analysis:
            digital_level = payment_analysis["数字化水平"]
            if "起步阶段" in digital_level:
                alerts.append("🔧 技术风险：数字化水平严重滞后，面临被市场淘汰的风险")
            elif "转型中" in digital_level:
                alerts.append("⚡ 转型风险：数字化转型进展缓慢，可能错失发展机遇")
        
        if "数字化提升重点" in payment_analysis:
            laggards_info = payment_analysis["数字化提升重点"]
            if "家分公司" in laggards_info:
                try:
                    count = int(laggards_info.split("家分公司")[0].split()[-1])
                    if count > 3:
                        alerts.append(f"🚨 系统性风险：{count}家分公司数字化严重滞后，存在系统性技术风险")
                except:
                    pass
        
        # === 增长分化风险 ===
        if "增长分化" in performance_analysis:
            divergence = performance_analysis["增长分化"]
            if "下行压力较为突出" in divergence:
                alerts.append("📉 增长风险：多数分公司面临下行压力，整体增长态势堪忧")
        
        if "绩效分布" in performance_analysis:
            distribution = performance_analysis["绩效分布"]
            try:
                # 提取待提升层占比
                if "待提升层" in distribution and "%" in distribution:
                    parts = distribution.split("待提升层")[1]
                    if "%" in parts:
                        ratio_str = parts.split("家(")[1].split("%)")[0]
                        ratio = float(ratio_str)
                        if ratio > 40:
                            alerts.append(f"⚠️ 绩效风险：{ratio:.1f}%的分公司表现不佳，绩效分化严重")
            except:
                pass
        
        # === 支付结构风险 ===
        if "现金支付" in payment_analysis:
            cash_info = payment_analysis["现金支付"]
            if "%" in cash_info:
                try:
                    ratio = float(cash_info.split("%")[0])
                    if ratio > 50:
                        alerts.append("🏧 支付风险：现金支付占比过高，支付结构落后，运营效率低下")
                    elif ratio > 35:
                        alerts.append("💰 结构风险：现金支付占比较高，数字化转型滞后")
                except:
                    pass
        
        # === 波动性风险 ===
        if "趋势预测" in trend_analysis:
            prediction = trend_analysis["趋势预测"]
            if "波动较大" in prediction:
                alerts.append("📊 波动风险：市场波动加剧，不确定性增强，需加强风险管控")
        
        # === 季节性风险 ===
        if "季节特征" in trend_analysis:
            seasonal = trend_analysis["季节特征"]
            import datetime
            current_month = datetime.datetime.now().month
            
            if current_month in [1, 2] and "集中" in seasonal:
                alerts.append("🎄 季节性风险：春节期间车流集中，需防范拥堵和服务压力")
            elif current_month in [11, 12]:
                alerts.append("📅 年末风险：临近年底，需关注目标完成情况和资金回笼风险")
        
        # === 综合风险评估 ===
        high_risk_count = len([alert for alert in alerts if "🚨 高风险" in alert])
        medium_risk_count = len([alert for alert in alerts if "⚠️ 中风险" in alert or "⚠️" in alert])
        
        if high_risk_count > 2:
            alerts.insert(0, "🆘 系统性风险：存在多项高风险因素，建议立即召开风险评估会议，制定应对策略")
        elif high_risk_count > 0 or medium_risk_count > 3:
            alerts.insert(0, "⚠️ 综合风险：风险因素较多，建议加强风险监控和预防措施")
        
        # === 风险缓解建议 ===
        if alerts:
            alerts.append("🛡️ 风险管控建议：建立风险监控仪表板，定期评估风险状况，制定应急预案")
        
        return alerts[:10]  # 限制预警数量，突出重点风险
    
    async def generate_report(self, start_date: str, end_date: str) -> ReportData:
        """生成完整报告"""
        logger.info(f"开始生成报告，日期范围: {start_date} 到 {end_date}")
        
        # 计算对比日期范围
        prev_start, prev_end, year_ago_start, year_ago_end = self._calculate_date_ranges(start_date, end_date)
        
        # 顺序获取数据，避免并发限制
        logger.info("开始获取当前期间数据...")
        current_period_data = await self._make_request("trade/companyPayTypeTurnover", "POST", {"beginTime": start_date, "endTime": end_date})
        
        logger.info("开始获取上期数据...")
        previous_period_data = await self._make_request("trade/companyPayTypeTurnover", "POST", {"beginTime": prev_start, "endTime": prev_end})
        
        logger.info("开始获取去年同期数据...")
        year_ago_data = await self._make_request("trade/companyPayTypeTurnover", "POST", {"beginTime": year_ago_start, "endTime": year_ago_end})
        
        logger.info("开始获取交通流量数据...")
        traffic_flow_data = await self._make_request("traffic/companyPayTypeTrafficFlow", "POST", {"beginTime": start_date, "endTime": end_date})

        logger.info("开始获取去年同期交通流量数据...")
        year_ago_traffic_data = await self._make_request("traffic/companyPayTypeTrafficFlow", "POST", {"beginTime": year_ago_start, "endTime": year_ago_end})
        
        logger.info("开始获取车型数据...")
        vehicle_data = await self._make_request("traffic/companyVehTypeTrafficFlow", "POST", {"beginTime": start_date, "endTime": end_date})
        
        # 检查关键数据是否成功获取
        if "error" in current_period_data:
            logger.error(f"当前期间数据获取失败: {current_period_data['error']}")
            raise Exception(f"无法获取当前期间数据: {current_period_data['error']}")
        
        # 合并数据
        current_period_data['trafficFlow'] = traffic_flow_data
        current_period_data['vehicleData'] = vehicle_data
        year_ago_data['trafficFlow'] = year_ago_traffic_data
        
        # 生成图表数据
        charts_data = self._generate_charts_data(current_period_data, previous_period_data, year_ago_data, traffic_flow_data)
        
        # 生成分析文字
        analysis_text = self._generate_analysis_text(current_period_data, previous_period_data, year_ago_data)
        
        logger.info("报告生成完成")
        
        return ReportData(
            current_period_data=current_period_data,
            previous_period_data=previous_period_data,
            year_ago_data=year_ago_data,
            charts_data=charts_data,
            analysis_text=analysis_text
        )

async def main():
    """测试函数"""
    async with ReportGenerator() as generator:
        report = await generator.generate_report("2025-01-01", "2025-01-31")
        print("报告生成成功:")
        print(f"分析文字: {report.analysis_text}")
        print(f"图表数据: {json.dumps(report.charts_data, indent=2, ensure_ascii=False)}")

if __name__ == "__main__":
    asyncio.run(main())
