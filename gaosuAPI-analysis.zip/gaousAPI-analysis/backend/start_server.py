#!/usr/bin/env python3
"""
收费管理FastAPI服务启动脚本
"""

import os
import sys
import argparse
import uvicorn
from dotenv import load_dotenv

def main():
    """主启动函数"""
    parser = argparse.ArgumentParser(description="启动收费管理FastAPI服务")
    parser.add_argument(
        "--env-file", 
        default=None, 
        help="环境变量文件路径 (默认: 自动查找)"
    )
    parser.add_argument(
        "--host", 
        default=None, 
        help="绑定主机地址 (覆盖环境变量)"
    )
    parser.add_argument(
        "--port", 
        type=int, 
        default=None, 
        help="绑定端口 (覆盖环境变量)"
    )
    parser.add_argument(
        "--reload", 
        action="store_true", 
        help="启用热重载模式 (开发环境)"
    )
    parser.add_argument(
        "--workers", 
        type=int, 
        default=1, 
        help="工作进程数 (生产环境)"
    )
    parser.add_argument(
        "--log-level", 
        choices=["critical", "error", "warning", "info", "debug", "trace"], 
        default=None,
        help="日志级别 (覆盖环境变量)"
    )
    
    args = parser.parse_args()
    
    # 自动查找.env文件
    if args.env_file is None:
        # 获取脚本所在目录
        script_dir = os.path.dirname(os.path.abspath(__file__))
        possible_env_files = [
            os.path.join(script_dir, "config", ".env"),  # backend/config/.env (推荐)
            os.path.join(script_dir, ".env"),  # backend/.env (兼容)
            os.path.join(os.path.dirname(script_dir), ".env"),  # 项目根目录/.env
            ".env"  # 当前工作目录/.env
        ]
        
        env_file = None
        for possible_file in possible_env_files:
            if os.path.exists(possible_file):
                env_file = possible_file
                break
        
        if env_file:
            args.env_file = env_file
        else:
            args.env_file = os.path.join(script_dir, "config", ".env")  # 默认使用backend/config/.env
    
    # 加载环境变量
    if os.path.exists(args.env_file):
        load_dotenv(args.env_file, override=True)
        print(f"已加载环境变量文件: {args.env_file}")
    else:
        print(f"环境变量文件不存在: {args.env_file}")
        script_dir = os.path.dirname(os.path.abspath(__file__))
        example_file = os.path.join(script_dir, "config", ".env.example")
        if os.path.exists(example_file):
            print(f"提示: 请复制 {example_file} 为 {args.env_file} 并配置相关参数")
        else:
            fallback_example = os.path.join(script_dir, ".env.example")
            if os.path.exists(fallback_example):
                print(f"提示: 请复制 {fallback_example} 为 {args.env_file} 并配置相关参数")
            else:
                print("提示: 请创建.env文件并配置相关参数")
    
    # 导入配置模块
    from config import settings
    
    # 获取配置参数
    host = args.host or settings.fastapi_host
    port = args.port or settings.fastapi_port
    log_level = args.log_level or settings.log_level.lower()
    reload = args.reload or settings.fastapi_reload
    
    # 检查必要的环境变量
    missing_vars = settings.validate_required_settings()
    
    if missing_vars:
        print(f"错误: 缺少必要的环境变量: {', '.join(missing_vars)}")
        print("请检查环境变量配置或 config/.env 文件")
        sys.exit(1)
    
    # 检查MCP服务器脚本
    script_dir = os.path.dirname(os.path.abspath(__file__))
    default_mcp_path = os.path.join(script_dir, "apis", "platformbilling_mcp.py")
    mcp_server_path = os.getenv("MCP_SERVER_PATH", default_mcp_path)
    
    if not os.path.exists(mcp_server_path):
        print(f"错误: MCP服务器脚本不存在: {mcp_server_path}")
        print(f"当前工作目录: {os.getcwd()}")
        print(f"尝试的路径: {os.path.abspath(mcp_server_path)}")
        print(f"脚本目录: {script_dir}")
        sys.exit(1)
    
    print(f"启动配置:")
    print(f"  主机地址: {host}")
    print(f"  端口: {port}")
    print(f"  日志级别: {log_level}")
    print(f"  热重载: {reload}")
    print(f"  工作进程数: {args.workers}")
    print(f"  MCP服务器: {mcp_server_path}")
    print("-" * 50)
    
    try:
        # 启动服务
        uvicorn.run(
            "apis.fastapi_server:app",
            host=host,
            port=port,
            reload=reload,
            workers=args.workers if not reload else 1,  # 热重载模式下只能使用1个worker
            log_level=log_level,
            access_log=True,
            server_header=False,
            date_header=False
        )
    except KeyboardInterrupt:
        print("\n收到中断信号，正在关闭服务...")
    except Exception as e:
        print(f"启动服务时发生错误: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()