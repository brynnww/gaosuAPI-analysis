#!/usr/bin/env python3
"""
FastAPI服务测试脚本
"""

import asyncio
import json
import sys
from typing import Dict, Any
import httpx

class APITester:
    def __init__(self, base_url: str = "http://localhost:8000"):
        self.base_url = base_url
        self.client = httpx.AsyncClient(timeout=30.0)
    
    async def test_health_check(self) -> Dict[str, Any]:
        """测试健康检查端点"""
        print("🔍 测试健康检查端点...")
        try:
            response = await self.client.get(f"{self.base_url}/health")
            result = {
                "endpoint": "/health",
                "status_code": response.status_code,
                "response": response.json() if response.status_code == 200 else response.text
            }
            print(f"✅ 健康检查: {response.status_code}")
            return result
        except Exception as e:
            print(f"❌ 健康检查失败: {e}")
            return {"endpoint": "/health", "error": str(e)}
    
    async def test_models_endpoint(self) -> Dict[str, Any]:
        """测试模型列表端点"""
        print("🔍 测试模型列表端点...")
        try:
            response = await self.client.get(f"{self.base_url}/v1/models")
            result = {
                "endpoint": "/v1/models",
                "status_code": response.status_code,
                "response": response.json() if response.status_code == 200 else response.text
            }
            print(f"✅ 模型列表: {response.status_code}")
            return result
        except Exception as e:
            print(f"❌ 模型列表失败: {e}")
            return {"endpoint": "/v1/models", "error": str(e)}
    
    async def test_chat_completion(self, query: str, stream: bool = False) -> Dict[str, Any]:
        """测试聊天完成端点"""
        endpoint_name = "聊天完成(流式)" if stream else "聊天完成"
        print(f"🔍 测试{endpoint_name}端点...")
        
        payload = {
            "model": "toll-management",
            "messages": [
                {"role": "user", "content": query}
            ],
            "stream": stream
        }
        
        try:
            response = await self.client.post(
                f"{self.base_url}/v1/chat/completions",
                json=payload
            )
            
            if stream:
                # 处理流式响应
                content = ""
                async for chunk in response.aiter_text():
                    content += chunk
                
                result = {
                    "endpoint": "/v1/chat/completions (stream)",
                    "status_code": response.status_code,
                    "stream_data": content[:500] + "..." if len(content) > 500 else content
                }
            else:
                # 处理普通响应
                result = {
                    "endpoint": "/v1/chat/completions",
                    "status_code": response.status_code,
                    "response": response.json() if response.status_code == 200 else response.text
                }
            
            print(f"✅ {endpoint_name}: {response.status_code}")
            return result
            
        except Exception as e:
            print(f"❌ {endpoint_name}失败: {e}")
            return {"endpoint": "/v1/chat/completions", "error": str(e)}
    
    async def run_all_tests(self):
        """运行所有测试"""
        print("=" * 60)
        print("🚀 开始API功能测试")
        print("=" * 60)
        
        results = []
        
        # 1. 健康检查
        health_result = await self.test_health_check()
        results.append(health_result)
        print()
        
        # 2. 模型列表
        models_result = await self.test_models_endpoint()
        results.append(models_result)
        print()
        
        # 3. 简单查询测试
        simple_query = "获取所有分公司ID与名称"
        chat_result = await self.test_chat_completion(simple_query, stream=False)
        results.append(chat_result)
        print()
        
        # 4. 流式响应测试
        # stream_result = await self.test_chat_completion(simple_query, stream=True)
        # results.append(stream_result)
        # print()
        
        # 5. 复杂查询测试
        complex_query = "请基于今日集团实时数据，计算总体单车收入与按支付方式（ETC/现金/移动）单车收入，并给出占比与解读"
        complex_result = await self.test_chat_completion(complex_query, stream=False)
        results.append(complex_result)
        print()
        
        # 总结结果
        print("=" * 60)
        print("📊 测试结果汇总")
        print("=" * 60)
        
        success_count = 0
        total_count = len(results)
        
        for result in results:
            endpoint = result.get("endpoint", "unknown")
            if "error" in result:
                print(f"❌ {endpoint}: {result['error']}")
            else:
                status = result.get("status_code", 0)
                if 200 <= status < 300:
                    print(f"✅ {endpoint}: HTTP {status}")
                    success_count += 1
                else:
                    print(f"⚠️  {endpoint}: HTTP {status}")
        
        print(f"\n成功: {success_count}/{total_count}")
        
        if success_count == total_count:
            print("🎉 所有测试通过！")
        else:
            print("⚠️  部分测试失败，请检查服务状态和配置")
        
        return results
    
    async def close(self):
        """关闭HTTP客户端"""
        await self.client.aclose()

async def main():
    """主函数"""
    import argparse
    
    parser = argparse.ArgumentParser(description="测试FastAPI服务")
    parser.add_argument(
        "--base-url",
        default="http://localhost:8000",
        help="API服务基础URL (默认: http://localhost:8000)"
    )
    parser.add_argument(
        "--query",
        help="自定义测试查询"
    )
    
    args = parser.parse_args()
    
    tester = APITester(args.base_url)
    
    try:
        if args.query:
            # 单个查询测试
            print(f"🔍 测试自定义查询: {args.query}")
            result = await tester.test_chat_completion(args.query)
            print(json.dumps(result, indent=2, ensure_ascii=False))
        else:
            # 全套测试
            await tester.run_all_tests()
    
    except KeyboardInterrupt:
        print("\n测试被用户中断")
    except Exception as e:
        print(f"测试过程中发生错误: {e}")
        return 1
    finally:
        await tester.close()
    
    return 0

if __name__ == "__main__":
    sys.exit(asyncio.run(main()))