"""
配置管理模块
提供统一的配置加载和管理功能
"""

import os
from typing import Optional
from dotenv import load_dotenv


def find_and_load_env() -> Optional[str]:
    """
    自动查找并加载.env文件
    
    Returns:
        str: 找到的.env文件路径，如果没找到返回None
    """
    # 获取config目录（当前文件所在目录）
    config_dir = os.path.dirname(os.path.abspath(__file__))
    # 获取backend目录
    backend_dir = os.path.dirname(config_dir)
    # 获取项目根目录
    project_dir = os.path.dirname(backend_dir)
    
    # 按优先级查找.env文件
    possible_env_files = [
        os.path.join(config_dir, ".env"),  # backend/config/.env (推荐)
        os.path.join(backend_dir, ".env"),  # backend/.env (兼容)
        os.path.join(project_dir, ".env"),  # 项目根目录/.env
        ".env"  # 当前工作目录/.env
    ]
    
    for env_file in possible_env_files:
        if os.path.exists(env_file):
            load_dotenv(env_file, override=True)
            return env_file
    
    # 如果都没找到，使用默认行为
    load_dotenv(override=True)
    return None


def get_env_example_path() -> Optional[str]:
    """
    获取.env.example文件路径
    
    Returns:
        str: .env.example文件路径，如果没找到返回None
    """
    config_dir = os.path.dirname(os.path.abspath(__file__))
    backend_dir = os.path.dirname(config_dir)
    
    possible_example_files = [
        os.path.join(config_dir, ".env.example"),  # backend/config/.env.example (推荐)
        os.path.join(backend_dir, ".env.example"),  # backend/.env.example (兼容)
    ]
    
    for example_file in possible_example_files:
        if os.path.exists(example_file):
            return example_file
    
    return None


class Settings:
    """配置类"""
    
    def __init__(self):
        # 自动加载环境变量
        self.env_file = find_and_load_env()
        
    @property
    def qwen_api_key(self) -> str:
        """获取QWEN API密钥"""
        return os.getenv("QWEN_API_KEY", "")
    
    @property
    def qwen_base_url(self) -> str:
        """获取QWEN API基础URL"""
        return os.getenv("QWEN_BASE_URL", "https://dashscope.aliyuncs.com/compatible-mode/v1")
    
    @property
    def qwen_model(self) -> str:
        """获取QWEN模型名称"""
        return os.getenv("QWEN_MODEL", "qwen2.5-32b-instruct")
    
    @property
    def fastapi_host(self) -> str:
        """获取FastAPI主机地址"""
        return os.getenv("FASTAPI_HOST", "0.0.0.0")
    
    @property
    def fastapi_port(self) -> int:
        """获取FastAPI端口"""
        try:
            return int(os.getenv("FASTAPI_PORT", "8000"))
        except ValueError:
            return 8000
    
    @property
    def fastapi_reload(self) -> bool:
        """获取FastAPI热重载设置"""
        return os.getenv("FASTAPI_RELOAD", "false").lower() in ("true", "1", "yes", "on")
    
    @property
    def log_level(self) -> str:
        """获取日志级别"""
        return os.getenv("LOG_LEVEL", "INFO").upper()
    
    @property
    def max_tool_calls(self) -> int:
        """获取最大工具调用次数"""
        try:
            return int(os.getenv("MAX_TOOL_CALLS", "6"))
        except ValueError:
            return 6
    
    @property
    def max_tool_result_chars(self) -> int:
        """获取最大工具结果字符数"""
        try:
            return int(os.getenv("MAX_TOOL_RESULT_CHARS", "6000"))
        except ValueError:
            return 6000
    
    def validate_required_settings(self) -> list[str]:
        """
        验证必需的配置项
        
        Returns:
            list[str]: 缺失的配置项列表
        """
        required_settings = {
            "QWEN_API_KEY": self.qwen_api_key,
            "QWEN_BASE_URL": self.qwen_base_url,
            "QWEN_MODEL": self.qwen_model,
        }
        
        missing = []
        for key, value in required_settings.items():
            if not value or value.strip() == "":
                missing.append(key)
        
        return missing


# 全局配置实例
settings = Settings()
