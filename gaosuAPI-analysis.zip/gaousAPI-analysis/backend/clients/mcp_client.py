import asyncio
import sys
import os
import json
from typing import Optional
from contextlib import AsyncExitStack

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

from openai import OpenAI
from dotenv import load_dotenv

import httpx

# 使用配置模块加载环境变量
import sys
import os
# 添加backend目录到Python路径，以便导入config模块
backend_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if backend_dir not in sys.path:
    sys.path.insert(0, backend_dir)

from config import settings

class MCPClient:
    def __init__(self):
        # 初始化会话和客户端对象
        self.session: Optional[ClientSession] = None
        self.exit_stack = AsyncExitStack()
        
        # 初始化OpenAI客户端
        if not settings.qwen_api_key:
            raise ValueError("QWEN_API_KEY环境变量未设置。请将其添加到config/.env文件中。")
        
        self.openai_client = OpenAI(
                base_url=settings.qwen_base_url,
                api_key=settings.qwen_api_key,
                http_client=httpx.Client(verify=True, timeout=120, trust_env=False),
            )
        
        print(self.openai_client.models.list())

    async def connect_to_server(self, server_script_path: str):
        """连接到MCP服务器
        
        Args:
            server_script_path: 服务器脚本路径(.py或.js)
        """
        is_python = server_script_path.endswith('.py')
        is_js = server_script_path.endswith('.js')
        if not (is_python or is_js):
            raise ValueError("服务器脚本必须是.py或.js文件")

        command = "python" if is_python else "node"
        server_params = StdioServerParameters(
            command=command,
            args=[server_script_path],
            env=None
        )

        print(f"正在连接到服务器: {server_script_path}")
        stdio_transport = await self.exit_stack.enter_async_context(stdio_client(server_params))
        self.stdio, self.write = stdio_transport
        self.session = await self.exit_stack.enter_async_context(ClientSession(self.stdio, self.write))

        await self.session.initialize()

        # 列出可用工具
        response = await self.session.list_tools()
        tools = response.tools
        print("\n已连接到服务器，可用工具:", [tool.name for tool in tools])
        
    async def process_query(self, query: str, max_tool_calls: Optional[int] = None) -> str:
        """使用GPT和可用工具处理查询，带最大工具调用次数限制"""
        if not self.session:
            raise ValueError("未连接到服务器，请先调用connect_to_server方法")
        
        # 获取可用工具
        response = await self.session.list_tools()
        available_tools = []
        for tool in response.tools:
            # 构建OpenAI工具格式
            available_tools.append({
                "type": "function",
                "function": {
                    "name": tool.name,
                    "description": tool.description,
                    "parameters": tool.inputSchema
                }
            })

        # 最大工具调用限制
        if max_tool_calls is None:
            max_tool_calls = settings.max_tool_calls
        tool_calls_used = 0
        reached_limit = False

        # 限制回传给模型的工具结果长度
        max_tool_result_chars = settings.max_tool_result_chars

        # 初始消息
        messages = [{"role": "user", "content": query}]
        
        # 跟踪所有回复以拼接最终结果
        final_text = []
        
        # 循环处理工具调用直到完成
        while True:
            # 达到上限后，追加总结指令并禁止继续调用工具
            if tool_calls_used >= max_tool_calls and not reached_limit:
                messages.append({
                    "role": "system",
                    "content": f"工具调用次数已达上限（{max_tool_calls}）。请基于现有对话与工具返回内容给出清晰、简洁的最终总结，不要再调用任何工具。"
                })
                reached_limit = True

            tool_choice_value = "none" if tool_calls_used >= max_tool_calls else "auto"

            # 发送请求给OpenAI
            print("messages:", messages)
            response = self.openai_client.chat.completions.create(
                model=settings.qwen_model,
                messages=messages,
                tools=available_tools,
                tool_choice=tool_choice_value,
            )
            
            # 获取当前响应
            current_message = response.choices[0].message
            
            # 将文本内容添加到最终结果中
            if current_message.content:
                final_text.append(current_message.content)
            
            # 如果没有工具调用，则结束循环
            if not current_message.tool_calls:
                break
            
            # 将助手的消息添加到对话历史
            messages.append(current_message.model_dump())
            
            # 处理每个工具调用
            for tool_call in current_message.tool_calls:
                tool_name = tool_call.function.name

                # 超出上限时，不再执行调用，但回写一条tool消息告知模型
                if tool_calls_used >= max_tool_calls:
                    limit_msg = f"工具调用次数已达上限({max_tool_calls})，该调用未执行。"
                    final_text.append(f"[{limit_msg}]")
                    tool_call_id = tool_call.id
                    messages.append({
                        "tool_call_id": tool_call_id,
                        "role": "tool",
                        "name": tool_name,
                        "content": limit_msg
                    })
                    continue

                try:
                    tool_args = json.loads(tool_call.function.arguments)
                except json.JSONDecodeError:
                    print(f"无法解析工具参数: {tool_call.function.arguments}")
                    tool_args = {}
                
                # 静默执行工具调用（不显示调用详情）
                try:
                    # 执行工具调用
                    tool_result = await self.session.call_tool(tool_name, tool_args)

                    # 计数+1
                    tool_calls_used += 1
                    print(f"工具调用计数: {tool_calls_used}/{max_tool_calls}")
                    
                    # 不再将工具调用详情添加到输出中
                    
                    # 添加工具响应到消息历史
                    tool_call_id = tool_call.id
                    
                    # 处理content可能是列表的情况
                    content = tool_result.content
                    if isinstance(content, list):
                        # 如果content是列表，提取文本内容
                        content_text = ""
                        for item in content:
                            if hasattr(item, 'text'):
                                content_text += item.text
                            elif isinstance(item, str):
                                content_text += item
                            else:
                                content_text += str(item)
                        content = content_text

                    # 截断过长的工具结果，避免请求体过大
                    if isinstance(content, str) and len(content) > max_tool_result_chars:
                        content = content[:max_tool_result_chars] + f"... [truncated to {max_tool_result_chars} chars]"

                    messages.append({
                        "tool_call_id": tool_call_id,
                        "role": "tool",
                        "name": tool_name,
                        "content": content
                    })
                except Exception as e:
                    error_msg = f"工具执行失败: {str(e)}"
                    print(f"工具调用错误: {error_msg}")  # 只在控制台输出错误，不显示给用户
                    
                    tool_call_id = tool_call.id
                    messages.append({
                        "tool_call_id": tool_call_id,
                        "role": "tool",
                        "name": tool_name,
                        "content": error_msg
                    })
        
        return "\n".join([text for text in final_text if text])
    
    async def chat_loop(self):
        """运行交互式聊天循环"""
        print("\nMCP 客户端已启动!")
        print("输入您的问题，或输入'退出'结束会话。")

        while True:
            try:
                query = input("\n问题: ").strip()

                if query.lower() in ['退出', 'quit', 'exit']:
                    break

                print("处理中...")
                response = await self.process_query(query)
                print("\n" + response)

            except Exception as e:
                print(f"\n错误: {str(e)}")
                import traceback
                traceback.print_exc()
    
    async def cleanup(self):
        """清理资源"""
        if self.exit_stack:
            await self.exit_stack.aclose()

async def main():
    if len(sys.argv) < 2:
        print("用法: python client.py <服务器脚本路径>")
        sys.exit(1)

    client = MCPClient()
    try:
        await client.connect_to_server(sys.argv[1])
        await client.chat_loop()
    finally:
        await client.cleanup()

if __name__ == "__main__":
    asyncio.run(main())