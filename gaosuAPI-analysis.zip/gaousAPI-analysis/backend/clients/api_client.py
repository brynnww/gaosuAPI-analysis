# -*- coding: utf-8 -*-
"""
批量请求“管控平台app-收费”开放接口，并将结果保存为 Markdown（api_results.md）

说明：
- 使用 requests.request(...) 发送请求（遵循你的“使用 request 方法”要求）。
- beginTime/endTime 固定为 2025-03-01 ~ 2025-03-31（零填充格式）。
- 遍历 COMPANY_ID_NAME_PAIRS 中的 unitId，调用所有需要 unitId 的接口。
- 所有请求统一添加 Header: Authorization: Bear xxx。
- 将每次请求记录为 Markdown 片段，结构为：
  请求路由：/v1/api/xxxx
  请求参数：{...}
  返回结果：{...}

注意：
- 代码包含完整逻辑，但默认不执行。需要时取消最末行的注释后再运行。
"""

import json
import time
from typing import Any, Dict, Optional, Tuple
from urllib.parse import urlparse

import requests

# ---------------------------
# 配置区
# ---------------------------

COMPANY_ID_NAME_PAIRS = [
    {"unitId": "202000", "unitName": "哈绥分公司"},
    {"unitId": "204000", "unitName": "哈同分公司"},
    {"unitId": "203000", "unitName": "鹤大分公司"},
    {"unitId": "201000", "unitName": "哈尔滨分公司"},
    {"unitId": "206000", "unitName": "齐嫩分公司"},
    {"unitId": "208000", "unitName": "哈伊分公司"},
    {"unitId": "209000", "unitName": "哈大分公司"},
    {"unitId": "207000", "unitName": "北黑分公司"},
    {"unitId": "142000", "unitName": "监控分公司"},
    {"unitId": "205000", "unitName": "大齐分公司"},
    {"unitId": "230113", "unitName": "绥庆分公司"},
]

BEGIN_TIME = "2025-03-01"
END_TIME = "2025-03-31"

# 统一 Header（按你的要求使用“Bear xxx”，如需标准 Bearer 请自行调整）
COMMON_HEADERS = {
    "Authorization": "Basic anRnc3RBZG1pbjpwWXMzWGdBJjVObXM=",
    "Content-Type": "application/json",
}

# 基础 URL（按文档）
LOCAL_BASE = "http://localhost:9081"
OPEN_BASE = "http://116.182.4.67:8088/gssfApi2"
LOCAL_BASE = OPEN_BASE
# 请求间隔（避免目标限流，可按需调小/调大）
SLEEP_SECONDS_BETWEEN_REQUESTS = 10

# 输出文件
OUTPUT_MD = "api_results.md"


# ---------------------------
# 工具函数
# ---------------------------

def route_from_url(url: str) -> str:
    """从完整 URL 中提取 path 作为“请求路由”展示。"""
    return urlparse(url).path or "/"

def to_json_str(data: Any) -> str:
    """将对象转为 JSON 文本（确保中文不转义）。"""
    try:
        return json.dumps(data, ensure_ascii=False, separators=(",", ":"))
    except Exception:
        # 兜底：无法序列化时，转字符串
        return str(data)

def perform_request(
    method: str,
    url: str,
    params: Optional[Dict[str, Any]] = None,
    json_body: Optional[Dict[str, Any]] = None,
    headers: Optional[Dict[str, str]] = None,
    timeout: int = 20,
) -> Tuple[int, str, Optional[Dict[str, Any]]]:
    """
    发送请求（统一使用 requests.request）。
    返回：(status_code, raw_text, json_obj_if_any)
    """
    hdrs = dict(COMMON_HEADERS)
    if headers:
        hdrs.update(headers)

    try:
        resp = requests.request(
            method=method.upper(),
            url=url,
            params=params,
            json=json_body,
            headers=hdrs,
            timeout=timeout,
        )
        text = resp.text
        try:
            data = resp.json()
        except Exception:
            data = None
        return resp.status_code, text, data
    except requests.RequestException as e:
        return -1, f"REQUEST_ERROR: {e}", None

def append_markdown(
    fp,
    url: str,
    req_params: Optional[Dict[str, Any]],
    req_body: Optional[Dict[str, Any]],
    status_code: int,
    resp_text: str,
    resp_json: Optional[Dict[str, Any]],
    title_prefix: str = "",
):
    """
    写入 Markdown 段落，满足：
    请求路由：/xxx
    请求参数：{...}
    返回结果：{...}
    """
    route = route_from_url(url)
    # 组合“请求参数”：若 GET 则以 params 展示；若 POST 则以 body 展示；两者都有就都展示
    request_payload_display: Dict[str, Any] = {}
    if req_params:
        request_payload_display["query"] = req_params
    if req_body:
        request_payload_display["body"] = req_body

    # 响应结果：优先 JSON，其次原始文本
    resp_display = resp_json if resp_json is not None else {"raw": resp_text}

    # 标题（可携带前缀以区分分公司/站点等）
    if title_prefix:
        fp.write(f"### {title_prefix}\n")

    fp.write(f"**请求路由：** `{route}`\n\n")
    fp.write("**请求参数：**\n")
    fp.write("```json\n")
    fp.write(f"{to_json_str(request_payload_display)}\n")
    fp.write("```\n\n")
    fp.write(f"**返回结果（HTTP {status_code}）：**\n")
    fp.write("```json\n")
    fp.write(f"{to_json_str(resp_display)}\n")
    fp.write("```\n\n---\n\n")


# ---------------------------
# 具体接口封装
# ---------------------------

def call_service_state_analysis(fp):
    """
    对外开放接口 - 获取权限下属服务区（示例中为服务区）开关状态详情
    POST /v1/api/service/getServiceStateAnalysis
    Body: { serviceName, roadName }
    """
    url = f"{LOCAL_BASE}/v1/api/service/getServiceStateAnalysis"
    body = {
        "serviceName": "小兴安服务区",
        "roadName": "吉黑高速",
    }
    status, text, data = perform_request("POST", url, json_body=body)
    append_markdown(fp, url, None, body, status, text, data, title_prefix="服务区状态统计")

def call_station_state_analysis_by_company(fp, unit_id: str, unit_name: str):
    """
    对外开放接口 - 获取权限下属收费站开关状态详情
    GET /v1/api/station/getStationStateAnalysis?unitId=xxxx
    """
    url = f"{LOCAL_BASE}/v1/api/station/getStationStateAnalysis"
    params = {"unitId": unit_id}
    status, text, data = perform_request("GET", url, params=params)
    append_markdown(
        fp, url, params, None, status, text, data,
        title_prefix=f"收费站启停状态统计 - {unit_name}({unit_id})"
    )

def call_trade_realtime_turnover(fp):
    """
    交易 - 集团实时交易额数据
    GET /v1/api/trade/realTimeTurnover
    """
    url = f"{OPEN_BASE}/v1/api/trade/realTimeTurnover"
    status, text, data = perform_request("GET", url)
    append_markdown(fp, url, None, None, status, text, data, title_prefix="集团实时交易额")

def call_trade_company_paytype_turnover(fp):
    """
    交易 - 按支付方式获取分公司维度交易额
    POST /v1/api/trade/companyPayTypeTurnover
    """
    url = f"{OPEN_BASE}/v1/api/trade/companyPayTypeTurnover"
    body = {"beginTime": BEGIN_TIME, "endTime": END_TIME}
    status, text, data = perform_request("POST", url, json_body=body)
    append_markdown(fp, url, None, body, status, text, data, title_prefix="分公司维度交易额 - 支付方式")

def call_trade_company_vehtype_turnover(fp):
    """
    交易 - 按计费车型获取分公司维度交易额
    POST /v1/api/trade/companyVehTypeTurnover
    """
    url = f"{OPEN_BASE}/v1/api/trade/companyVehTypeTurnover"
    body = {"beginTime": BEGIN_TIME, "endTime": END_TIME}
    status, text, data = perform_request("POST", url, json_body=body)
    append_markdown(fp, url, None, body, status, text, data, title_prefix="分公司维度交易额 - 计费车型")

def call_trade_station_paytype_turnover_by_company(fp, unit_id: str, unit_name: str):
    """
    交易 - 按支付方式获取收费站维度交易额
    POST /v1/api/trade/stationPayTypeTurnover
    Body: { unitId, beginTime, endTime }
    """
    url = f"{OPEN_BASE}/v1/api/trade/stationPayTypeTurnover"
    body = {"unitId": unit_id, "beginTime": BEGIN_TIME, "endTime": END_TIME}
    status, text, data = perform_request("POST", url, json_body=body)
    append_markdown(
        fp, url, None, body, status, text, data,
        title_prefix=f"收费站维度交易额 - 支付方式 - {unit_name}({unit_id})"
    )

def call_trade_station_vehtype_turnover_by_company(fp, unit_id: str, unit_name: str):
    """
    交易 - 按计费车型获取收费站维度交易额
    POST /v1/api/trade/stationVehTypeTurnover
    Body: { unitId, beginTime, endTime }
    """
    url = f"{OPEN_BASE}/v1/api/trade/stationVehTypeTurnover"
    body = {"unitId": unit_id, "beginTime": BEGIN_TIME, "endTime": END_TIME}
    status, text, data = perform_request("POST", url, json_body=body)
    append_markdown(
        fp, url, None, body, status, text, data,
        title_prefix=f"收费站维度交易额 - 计费车型 - {unit_name}({unit_id})"
    )

def call_traffic_realtime(fp):
    """
    车流量 - 集团实时车流量数据
    GET /v1/api/traffic/realTimeTrafficFlow
    """
    url = f"{OPEN_BASE}/v1/api/traffic/realTimeTrafficFlow"
    status, text, data = perform_request("GET", url)
    append_markdown(fp, url, None, None, status, text, data, title_prefix="集团实时车流量")

def call_traffic_company_paytype(fp):
    """
    车流量 - 按支付方式获取分公司维度车流量
    POST /v1/api/traffic/companyPayTypeTrafficFlow
    """
    url = f"{OPEN_BASE}/v1/api/traffic/companyPayTypeTrafficFlow"
    body = {"beginTime": BEGIN_TIME, "endTime": END_TIME}
    status, text, data = perform_request("POST", url, json_body=body)
    append_markdown(fp, url, None, body, status, text, data, title_prefix="分公司维度车流量 - 支付方式")

def call_traffic_company_vehtype(fp):
    """
    车流量 - 按计费车型获取分公司维度车流量
    POST /v1/api/traffic/companyVehTypeTrafficFlow
    """
    url = f"{OPEN_BASE}/v1/api/traffic/companyVehTypeTrafficFlow"
    body = {"beginTime": BEGIN_TIME, "endTime": END_TIME}
    status, text, data = perform_request("POST", url, json_body=body)
    append_markdown(fp, url, None, body, status, text, data, title_prefix="分公司维度车流量 - 计费车型")

def call_traffic_station_paytype_by_company(fp, unit_id: str, unit_name: str):
    """
    车流量 - 按支付方式获取收费站维度交通流
    POST /v1/api/traffic/stationPayTypeTrafficFlow
    Body: { unitId, beginTime, endTime }
    """
    url = f"{OPEN_BASE}/v1/api/traffic/stationPayTypeTrafficFlow"
    body = {"unitId": unit_id, "beginTime": BEGIN_TIME, "endTime": END_TIME}
    status, text, data = perform_request("POST", url, json_body=body)
    append_markdown(
        fp, url, None, body, status, text, data,
        title_prefix=f"收费站维度交通流 - 支付方式 - {unit_name}({unit_id})"
    )

def call_traffic_station_vehtype_by_company(fp, unit_id: str, unit_name: str):
    """
    车流量 - 按计费车型获取收费站维度交通流
    POST /v1/api/traffic/stationVehTypeTrafficFlow
    Body: { unitId, beginTime, endTime }
    """
    url = f"{OPEN_BASE}/v1/api/traffic/stationVehTypeTrafficFlow"
    body = {"unitId": unit_id, "beginTime": BEGIN_TIME, "endTime": END_TIME}
    status, text, data = perform_request("POST", url, json_body=body)
    append_markdown(
        fp, url, None, body, status, text, data,
        title_prefix=f"收费站维度交通流 - 计费车型 - {unit_name}({unit_id})"
    )


# ---------------------------
# 主流程
# ---------------------------

def main():
    with open(OUTPUT_MD, "w", encoding="utf-8") as fp:
        fp.write("# 管控平台开放接口 - 请求结果汇总\n\n")
        fp.write(f"> 时间范围：{BEGIN_TIME} ~ {END_TIME}\n\n")
        fp.write("> 注：所有请求均添加 Header `Authorization: Bear xxx`\n\n")
        fp.write("---\n\n")

        # 1) 服务区状态统计（按示例参数）
        call_service_state_analysis(fp)
        time.sleep(SLEEP_SECONDS_BETWEEN_REQUESTS)

        # 2) 收费站启停状态统计（遍历所有分公司 unitId）
        for c in COMPANY_ID_NAME_PAIRS:
            call_station_state_analysis_by_company(fp, c["unitId"], c["unitName"])
            time.sleep(SLEEP_SECONDS_BETWEEN_REQUESTS)

        # 3) 交易 - 集团实时
        call_trade_realtime_turnover(fp)
        time.sleep(SLEEP_SECONDS_BETWEEN_REQUESTS)

        # 4) 交易 - 分公司维度（支付方式、计费车型）
        call_trade_company_paytype_turnover(fp)
        time.sleep(SLEEP_SECONDS_BETWEEN_REQUESTS)
        call_trade_company_vehtype_turnover(fp)
        time.sleep(SLEEP_SECONDS_BETWEEN_REQUESTS)

        # 5) 交易 - 收费站维度（需要遍历 unitId）
        for c in COMPANY_ID_NAME_PAIRS:
            call_trade_station_paytype_turnover_by_company(fp, c["unitId"], c["unitName"])
            time.sleep(SLEEP_SECONDS_BETWEEN_REQUESTS)
            call_trade_station_vehtype_turnover_by_company(fp, c["unitId"], c["unitName"])
            time.sleep(SLEEP_SECONDS_BETWEEN_REQUESTS)

        # 6) 车流量 - 集团实时
        call_traffic_realtime(fp)
        time.sleep(SLEEP_SECONDS_BETWEEN_REQUESTS)

        # 7) 车流量 - 分公司维度（支付方式、计费车型）
        call_traffic_company_paytype(fp)
        time.sleep(SLEEP_SECONDS_BETWEEN_REQUESTS)
        call_traffic_company_vehtype(fp)
        time.sleep(SLEEP_SECONDS_BETWEEN_REQUESTS)

        # 8) 车流量 - 收费站维度（需要遍历 unitId）
        for c in COMPANY_ID_NAME_PAIRS:
            call_traffic_station_paytype_by_company(fp, c["unitId"], c["unitName"])
            time.sleep(SLEEP_SECONDS_BETWEEN_REQUESTS)
            call_traffic_station_vehtype_by_company(fp, c["unitId"], c["unitName"])
            time.sleep(SLEEP_SECONDS_BETWEEN_REQUESTS)

        fp.write("\n> 生成完毕。\n")

# 如需执行，请取消下一行注释：
if __name__ == "__main__": 
    main()
