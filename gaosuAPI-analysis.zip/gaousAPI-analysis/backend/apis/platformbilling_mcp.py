import sys
import json
import logging
from typing import Any, Dict
import uvicorn
import httpx

# MCP imports
from mcp.server.fastmcp import FastMCP
from mcp.shared.exceptions import McpError

# Pydantic for input validation
from pydantic import BaseModel, Field, ValidationError

# Configure logging
logging.basicConfig(level=logging.INFO, 
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                    stream=sys.stderr)
logger = logging.getLogger("platform-billing-server")

# Base URL for the billing API
API_BASE_URL = ""

# Initialize MCP server using FastMCP
mcp = FastMCP("platform-billing")

# API client for making requests to the billing API
class BillingApiClient:
    def __init__(self, base_url: str):
        self.base_url = base_url
        self.headers = {
            "Content-Type": "application/json",
            "Authorization": "Basic anRnc3RBZG1pbjpwWXMzWGdBJjVObXM="
        }
        
    async def get(self, endpoint: str) -> Dict[str, Any]:
        """Make a GET request to the API"""
        url = f"{self.base_url}/{endpoint}"
        logger.info(f"GET {url}")
        
        async with httpx.AsyncClient() as client:
            try:
                response = await client.get(url, headers=self.headers, timeout=30.0)
                response.raise_for_status()
                return response.json()
            except httpx.HTTPStatusError as e:
                logger.error(f"HTTP error: {e}")
                raise
            except httpx.RequestError as e:
                logger.error(f"Request error: {e}")
                raise
            except Exception as e:
                logger.error(f"Unexpected error during GET request: {e}")
                raise

    async def post(self, endpoint: str, data: Dict[str, Any]) -> Dict[str, Any]:
        """Make a POST request to the API"""
        url = f"{self.base_url}/{endpoint}"
        logger.info(f"POST {url} {data}")
        
        async with httpx.AsyncClient() as client:
            try:
                response = await client.post(url, json=data, headers=self.headers, timeout=30.0)
                response.raise_for_status()
                return response.json()
            except httpx.HTTPStatusError as e:
                logger.error(f"HTTP error: {e}")
                raise
            except httpx.RequestError as e:
                logger.error(f"Request error: {e}")
                raise
            except Exception as e:
                logger.error(f"Unexpected error during POST request: {e}")
                raise

# Create API client
api_client = BillingApiClient(API_BASE_URL)

# 固定的公司ID与名称映射（无需再请求接口）
COMPANY_ID_NAME_PAIRS = [
    {"unitId": "202000", "unitName": "哈绥分公司"},
    {"unitId": "204000", "unitName": "哈同分公司"},
    {"unitId": "203000", "unitName": "鹤大分公司"},
    {"unitId": "201000", "unitName": "哈尔滨分公司"},
    {"unitId": "206000", "unitName": "齐嫩分公司"},
    {"unitId": "208000", "unitName": "哈伊分公司"},
    {"unitId": "209000", "unitName": "哈大分公司"},
    {"unitId": "207000", "unitName": "北黑分公司"},
    {"unitId": "142000", "unitName": "监控分公司"},
    {"unitId": "205000", "unitName": "大齐分公司"},
    {"unitId": "230113", "unitName": "绥庆分公司"},
]
COMPANY_IDS = [pair["unitId"] for pair in COMPANY_ID_NAME_PAIRS]
COMPANY_ID_TO_NAME = {pair["unitId"]: pair["unitName"] for pair in COMPANY_ID_NAME_PAIRS}

# Define input schemas for tools
class DateRangeParams(BaseModel):
    beginTime: str = Field(..., description="Start date (format: YYYY-MM-DD)")
    endTime: str = Field(..., description="End date (format: YYYY-MM-DD)")

class StationParams(BaseModel):
    unitId: str = Field(..., description="Company ID")
    beginTime: str = Field(..., description="Start date (format: YYYY-MM-DD)")
    endTime: str = Field(..., description="End date (format: YYYY-MM-DD)")

# Helper function to format API responses
def format_response(data: Dict[str, Any]) -> str:
    """Format API response data into a more readable string format"""
    try:
        return json.dumps(data, indent=2, ensure_ascii=False)
    except Exception as e:
        logger.error(f"Error formatting response: {e}")
        return json.dumps({"error": "Failed to format response"})

# Implement tools using the FastMCP decorator
@mcp.tool()
async def get_realtime_transaction() -> str:
    """获取集团实时交易数据

    示例返回(JSON 片段):
    {"code":1,"msg":"集团交易额数据请求成功","success":true,"data":{"todayTurnover":66361,"todayETCTurnover":2721,"todayCashTurnover":1400,"todayMobileTurnover":62240,"monthTurnover":88763947,"yearTurnover":991381579}}
    """
    try:
        response_data = await api_client.get("trade/realTimeTurnover")
        return format_response(response_data)
    except Exception as e:
        logger.error(f"Error in get_realtime_transaction: {e}")
        return json.dumps({"error": "Failed to get real-time transaction data"})

@mcp.tool()
async def get_company_payment_transaction(beginTime: str, endTime: str) -> str:
    """获取所有公司层级按支付方式统计的交易数据

    Args:
        beginTime: Start date (format: YYYY-MM-DD)
        endTime: End date (format: YYYY-MM-DD)

    示例返回(JSON 片段):
    {"data":{"payTypeTurnoverList":[{"unitId":"201000","unitName":"哈尔滨分公司","turnover":111004831,"etcTurnover":78304629,"cashTurnover":5397063,"mobileTurnover":27303139},{...}],"totalTurnover":446051348}}
    """
    try:
        # Validate input using Pydantic model
        args = DateRangeParams(beginTime=beginTime, endTime=endTime)
        response_data = await api_client.post("trade/companyPayTypeTurnover", args.model_dump())
        return format_response(response_data)
    except ValidationError as e:
        logger.error(f"Validation error: {e}")
        return json.dumps({"error": f"Invalid parameters: {e}"})
    except Exception as e:
        logger.error(f"Error in get_company_payment_transaction: {e}")
        return json.dumps({"error": "Failed to get company payment transaction data"})

@mcp.tool()
async def get_company_vehicle_transaction(beginTime: str, endTime: str) -> str:
    """获取所有公司层级按车型统计的交易数据
    
    Args:
        beginTime: Start date (format: YYYY-MM-DD)
        endTime: End date (format: YYYY-MM-DD)
    
    示例返回(JSON 片段):
    {"data":{"vehTypeTurnoverList":[{"unitId":"201000","unitName":"哈尔滨分公司","turnover":111004831,"carTurnover":47048030,"truckTurnover":63830258,"specialTurnover":126543}, ...],"totalTurnover":446051348}}
    """
    try:
        args = DateRangeParams(beginTime=beginTime, endTime=endTime)
        response_data = await api_client.post("trade/companyVehTypeTurnover", args.model_dump())
        return format_response(response_data)
    except ValidationError as e:
        logger.error(f"Validation error: {e}")
        return json.dumps({"error": f"Invalid parameters: {e}"})
    except Exception as e:
        logger.error(f"Error in get_company_vehicle_transaction: {e}")
        return json.dumps({"error": "Failed to get company vehicle transaction data"})

@mcp.tool()
async def get_station_payment_transaction(unitId: str, beginTime: str, endTime: str) -> str:
    """获取所有收费站层级按支付方式统计的交易数据

    Args:
        unitId: Company ID
        beginTime: Start date (format: YYYY-MM-DD)
        endTime: End date (format: YYYY-MM-DD)

    示例返回(JSON 片段):
    {"data":{"payTypeTurnoverList":[{"unitId":"G0001230010040","unitName":"新兴站","turnover":34939605,"etcTurnover":33243662,"cashTurnover":106171,"mobileTurnover":1589772},{...}]}}
    """
    try:
        args = StationParams(unitId=unitId, beginTime=beginTime, endTime=endTime)
        response_data = await api_client.post("trade/stationPayTypeTurnover", args.model_dump())
        return format_response(response_data)
    except ValidationError as e:
        logger.error(f"Validation error: {e}")
        return json.dumps({"error": f"Invalid parameters: {e}"})
    except Exception as e:
        logger.error(f"Error in get_station_payment_transaction: {e}")
        return json.dumps({"error": "Failed to get station payment transaction data"})

@mcp.tool()
async def get_station_vehicle_transaction(unitId: str, beginTime: str, endTime: str) -> str:
    """获取所有收费站层级按车型统计的交易数据

    Args:
        unitId: Company ID
        beginTime: Start date (format: YYYY-MM-DD)
        endTime: End date (format: YYYY-MM-DD)

    示例返回(JSON 片段):
    {"data":{"vehTypeTurnoverList":[{"unitId":"G0001230010040","unitName":"新兴站","turnover":36027986,"carTurnover":702694,"truckTurnover":35303815,"specialTurnover":21478},{...}]}}
    """
    try:
        args = StationParams(unitId=unitId, beginTime=beginTime, endTime=endTime)
        response_data = await api_client.post("trade/stationVehTypeTurnover", args.model_dump())
        return format_response(response_data)
    except ValidationError as e:
        logger.error(f"Validation error: {e}")
        return json.dumps({"error": f"Invalid parameters: {e}"})
    except Exception as e:
        logger.error(f"Error in get_station_vehicle_transaction: {e}")
        return json.dumps({"error": "Failed to get station vehicle transaction data"})

@mcp.tool()
async def get_realtime_traffic_flow() -> str:
    """获取集团实时交通流量数据

    示例返回(JSON 片段):
    {"code":1,"msg":"请求成功","success":true,"data":{"todayTrafficFlow":7352,"todayETCTrafficFlow":326,"todayCashTrafficFlow":695,"todayMobileTrafficFlow":6331,"todayFreeTrafficFlow":96,"monthTrafficFlow":1196412,"yearTrafficFlow":13178788}}
    """
    try:
        response_data = await api_client.get("traffic/realTimeTrafficFlow")
        return format_response(response_data)
    except Exception as e:
        logger.error(f"Error in get_realtime_traffic_flow: {e}")
        return json.dumps({"error": "Failed to get real-time traffic flow data"})

@mcp.tool()
async def get_company_payment_traffic_flow(beginTime: str, endTime: str) -> str:
    """获取所有公司层级按支付方式统计的交通流量数据

    Args:
        beginTime: Start date (format: YYYY-MM-DD)
        endTime: End date (format: YYYY-MM-DD)

    示例返回(JSON 片段):
    {"data":{"payTypeTrafficFlowList":[{"unitId":"204000","unitName":"哈同分公司","trafficFlow":978211,"etcTrafficFlow":542158,"cashTrafficFlow":78943,"mobileTrafficFlow":357110,"freeTrafficFlow":11265},{...}],"trafficTotalFlow":6132642}}
    """
    try:
        args = DateRangeParams(beginTime=beginTime, endTime=endTime)
        response_data = await api_client.post("traffic/companyPayTypeTrafficFlow", args.model_dump())
        return format_response(response_data)
    except ValidationError as e:
        logger.error(f"Validation error: {e}")
        return json.dumps({"error": f"Invalid parameters: {e}"})
    except Exception as e:
        logger.error(f"Error in get_company_payment_traffic_flow: {e}")
        return json.dumps({"error": "Failed to get company payment traffic flow data"})

@mcp.tool()
async def get_company_vehicle_traffic_flow(beginTime: str, endTime: str) -> str:
    """获取所有公司层级按车型统计的交通流量数据

    Args:
        beginTime: Start date (format: YYYY-MM-DD)
        endTime: End date (format: YYYY-MM-DD)

    示例返回(JSON 片段):
    {"data":{"vehTypeTrafficFlowList":[{"unitId":"204000","unitName":"哈同分公司","trafficFlow":978211,"carTrafficFlow":618116,"truckTrafficFlow":345980,"specialTrafficFlow":2850,"freeTrafficFlow":11265},{...}],"trafficTotalFlow":6132642}}
    """
    try:
        args = DateRangeParams(beginTime=beginTime, endTime=endTime)
        response_data = await api_client.post("traffic/companyVehTypeTrafficFlow", args.model_dump())
        return format_response(response_data)
    except ValidationError as e:
        logger.error(f"Validation error: {e}")
        return json.dumps({"error": f"Invalid parameters: {e}"})
    except Exception as e:
        logger.error(f"Error in get_company_vehicle_traffic_flow: {e}")
        return json.dumps({"error": "Failed to get company vehicle traffic flow data"})

@mcp.tool()
async def get_station_payment_traffic_flow(unitId: str, beginTime: str, endTime: str) -> str:
    """获取所有收费站层级按支付方式统计的交通流量数据

    Args:
        unitId: Company ID
        beginTime: Start date (format: YYYY-MM-DD)
        endTime: End date (format: YYYY-MM-DD)

    示例返回(JSON 片段):
    {"data":{"payTypeTrafficFlowList":[{"unitId":"G1011230040080","unitName":"哈尔滨东站","trafficFlow":133504,"etcTrafficFlow":76075,"cashTrafficFlow":9584,"mobileTrafficFlow":47845,"freeTrafficFlow":568},{...}]}}
    """
    try:
        args = StationParams(unitId=unitId, beginTime=beginTime, endTime=endTime)
        response_data = await api_client.post("traffic/stationPayTypeTrafficFlow", args.model_dump())
        return format_response(response_data)
    except ValidationError as e:
        logger.error(f"Validation error: {e}")
        return json.dumps({"error": f"Invalid parameters: {e}"})
    except Exception as e:
        logger.error(f"Error in get_station_payment_traffic_flow: {e}")
        return json.dumps({"error": "Failed to get station payment traffic flow data"})

@mcp.tool()
async def get_station_vehicle_traffic_flow(unitId: str, beginTime: str, endTime: str) -> str:
    """获取所有收费站层级按车型统计的交通流量数据

    Args:
        unitId: Company ID
        beginTime: Start date (format: YYYY-MM-DD)
        endTime: End date (format: YYYY-MM-DD)

    示例返回(JSON 片段):
    {"data":{"vehTypeTrafficFlowList":[{"unitId":"G0001230010050","unitName":"瓦盆窑站","trafficFlow":168483,"carTrafficFlow":102029,"truckTrafficFlow":59150,"specialTrafficFlow":651,"freeTrafficFlow":6653},{...}]}}
    """
    try:
        args = StationParams(unitId=unitId, beginTime=beginTime, endTime=endTime)
        response_data = await api_client.post("traffic/stationVehTypeTrafficFlow", args.model_dump())
        return format_response(response_data)
    except ValidationError as e:
        logger.error(f"Validation error: {e}")
        return json.dumps({"error": f"Invalid parameters: {e}"})
    except Exception as e:
        logger.error(f"Error in get_station_vehicle_traffic_flow: {e}")
        return json.dumps({"error": "Failed to get station vehicle traffic flow data"})

@mcp.tool()
async def get_all_company_ids() -> str:
    """获取所有分公司ID与名称。

    返回字段:
      - companyIds: [str]
      - companyIdNamePairs: [{unitId, unitName}]

    示例返回(JSON 片段):
    {"companyIds":["202000","204000",...],"companyIdNamePairs":[{"unitId":"202000","unitName":"哈绥分公司"},{...}]}
    """
    try:
        company_ids = COMPANY_IDS
        company_pairs = COMPANY_ID_NAME_PAIRS

        result = {
            "companyIds": company_ids,
            "companyIdNamePairs": company_pairs,
        }
        return json.dumps(result, ensure_ascii=False, indent=2)
    except Exception as e:
        logger.error(f"Error in get_all_company_ids: {e}")
        return json.dumps({"error": "Failed to get company IDs"})

@mcp.tool()
async def generate_report(beginTime: str, endTime: str) -> str:
    """生成数据分析报告

    Args:
        beginTime: 开始日期 (format: YYYY-MM-DD)
        endTime: 结束日期 (format: YYYY-MM-DD)

    返回字段:
      - reportId: 报告ID
      - status: 报告状态
      - message: 状态信息

    示例返回(JSON 片段):
    {"reportId":"report_20250101_120000_1234","status":"queued","message":"报告生成请求已提交，请使用报告ID查询状态"}
    """
    try:
        # 验证日期格式
        from datetime import datetime
        start_dt = datetime.strptime(beginTime, "%Y-%m-%d")
        end_dt = datetime.strptime(endTime, "%Y-%m-%d")
        
        if start_dt > end_dt:
            return json.dumps({"error": "开始日期不能晚于结束日期"})
        
        if (end_dt - start_dt).days > 365:
            return json.dumps({"error": "日期范围不能超过一年"})
        
        # 调用报告生成器
        from reports.report_generator import ReportGenerator
        
        async with ReportGenerator() as generator:
            report = await generator.generate_report(beginTime, endTime)
            
            result = {
                "status": "completed",
                "message": "报告生成完成",
                "data": {
                    "analysis_text": report.analysis_text,
                    "charts_data": report.charts_data,
                    "summary": f"已生成 {beginTime} 到 {endTime} 期间的数据分析报告"
                }
            }
            
            return json.dumps(result, ensure_ascii=False, indent=2)
            
    except ValueError as e:
        logger.error(f"日期格式错误: {e}")
        return json.dumps({"error": "日期格式错误，请使用 YYYY-MM-DD 格式"})
    except Exception as e:
        logger.error(f"报告生成失败: {e}")
        return json.dumps({"error": f"报告生成失败: {str(e)}"})

def main():
    import argparse

    parser = argparse.ArgumentParser(description="Run Platform Billing MCP Server")
    parser.add_argument(
        "--transport", 
        choices=["stdio", "sse"], 
        default="stdio",
        help="Transport protocol to use (stdio or sse, default: stdio)",
    )
    parser.add_argument(
        "--host", default="127.0.0.1", help="Host to bind to for SSE (default: 127.0.0.1)"
    )
    parser.add_argument(
        "--port", type=int, default=3001, help="Port to listen on for SSE (default: 3001)"
    )
    args = parser.parse_args()

    try:
        if args.transport == "sse":
            # Use the built-in SSE app method from FastMCP
            uvicorn.run(
                mcp.sse_app(),
                host=args.host,
                port=args.port
            )
        else:
            # Use run() for stdio mode
            mcp.run(transport="stdio")
    except McpError as e:
        logger.error(f"MCP Error: {e}")
        print(f"MCP Error: {e}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        logger.error(f"An unexpected error occurred: {e}")
        print(f"An unexpected error occurred: {e}", file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    main()