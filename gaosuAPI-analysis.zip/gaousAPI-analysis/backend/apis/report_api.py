import asyncio
import json
import logging
from datetime import datetime
from typing import Dict, Any
from fastapi import APIRouter, HTTPException, BackgroundTasks
from pydantic import BaseModel, Field
from reports.report_generator import ReportGenerator


# 配置日志
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger("report-api")

# 创建路由器
router = APIRouter(prefix="/api/report", tags=["报告生成"])

# 存储报告生成状态
report_status = {}



class ReportRequest(BaseModel):
    start_date: str = Field(..., description="开始日期 (YYYY-MM-DD)")
    end_date: str = Field(..., description="结束日期 (YYYY-MM-DD)")

class ReportStatus(BaseModel):
    report_id: str
    status: str
    progress: int
    message: str
    created_at: str

class ReportResponse(BaseModel):
    report_id: str
    status: str
    message: str

def _validate_date_format(date_str: str) -> bool:
    """验证日期格式"""
    try:
        datetime.strptime(date_str, "%Y-%m-%d")
        return True
    except ValueError:
        return False

async def _generate_report_background(report_id: str, start_date: str, end_date: str):
    """后台生成报告"""
    try:
        report_status[report_id] = {
            "status": "processing",
            "progress": 0,
            "message": "正在生成报告...",
            "created_at": datetime.now().isoformat()
        }
        
        # 更新进度
        report_status[report_id]["progress"] = 20
        report_status[report_id]["message"] = "正在获取数据..."
        
        # 使用真实API生成报告
        try:
            async with ReportGenerator() as generator:
                report_status[report_id]["progress"] = 50
                report_status[report_id]["message"] = "正在分析数据..."
                
                # 设置超时时间
                import asyncio
                report = await asyncio.wait_for(
                    generator.generate_report(start_date, end_date),
                    timeout=120.0  # 2分钟超时
                )
                
                # 如果成功，继续处理
                report_status[report_id]["progress"] = 80
                report_status[report_id]["message"] = "正在生成图表..."
                
        except asyncio.TimeoutError:
            logger.error("真实API请求超时")
            report_status[report_id]["message"] = "API请求超时，报告生成失败"
            raise Exception("API请求超时")
        except Exception as e:
            logger.error(f"真实API失败: {e}")
            report_status[report_id]["message"] = f"API请求失败: {str(e)}"
            raise Exception(f"API请求失败: {str(e)}")
        
        # 如果成功，继续处理
        report_status[report_id]["progress"] = 80
        report_status[report_id]["message"] = "正在生成图表..."
        
        # 存储报告结果
        report_status[report_id].update({
            "status": "completed",
            "progress": 100,
            "message": "报告生成完成",
            "result": {
                "current_period_data": report.current_period_data,
                "previous_period_data": report.previous_period_data,
                "year_ago_data": report.year_ago_data,
                "charts_data": report.charts_data,
                "analysis_text": report.analysis_text
            }
        })
        
        logger.info(f"报告 {report_id} 生成完成")
            
    except Exception as e:
        logger.error(f"报告生成失败 {report_id}: {e}")
        report_status[report_id].update({
            "status": "failed",
            "progress": 0,
            "message": f"报告生成失败: {str(e)}"
        })

@router.post("/generate", response_model=ReportResponse)
async def generate_report(request: ReportRequest, background_tasks: BackgroundTasks):
    """生成报告"""
    # 验证日期格式
    if not _validate_date_format(request.start_date) or not _validate_date_format(request.end_date):
        raise HTTPException(status_code=400, detail="日期格式错误，请使用 YYYY-MM-DD 格式")
    
    # 验证日期范围
    start_dt = datetime.strptime(request.start_date, "%Y-%m-%d")
    end_dt = datetime.strptime(request.end_date, "%Y-%m-%d")
    
    if start_dt > end_dt:
        raise HTTPException(status_code=400, detail="开始日期不能晚于结束日期")
    
    if (end_dt - start_dt).days > 365:
        raise HTTPException(status_code=400, detail="日期范围不能超过一年")
    
    # 生成报告ID
    report_id = f"report_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{hash(request.start_date + request.end_date) % 10000}"
    
    # 初始化状态
    report_status[report_id] = {
        "status": "queued",
        "progress": 0,
        "message": "报告已加入队列",
        "created_at": datetime.now().isoformat()
    }
    
    # 后台生成报告
    background_tasks.add_task(_generate_report_background, report_id, request.start_date, request.end_date)
    
    logger.info(f"报告生成请求已提交: {report_id}, 日期范围: {request.start_date} 到 {request.end_date}")
    
    return ReportResponse(
        report_id=report_id,
        status="queued",
        message="报告生成请求已提交，请使用报告ID查询状态"
    )

@router.get("/test-charts")
async def test_charts():
    """测试图表生成功能"""
    try:
        async with ReportGenerator() as generator:
            test_data = {
                'data': {
                    'payTypeTurnoverList': [
                        {'unitName': '哈尔滨分公司', 'turnover': 1000000, 'etcTurnover': 700000, 'cashTurnover': 150000, 'mobileTurnover': 150000},
                        {'unitName': '齐齐哈尔分公司', 'turnover': 800000, 'etcTurnover': 500000, 'cashTurnover': 150000, 'mobileTurnover': 150000},
                    ]
                }
            }
            charts = generator._generate_charts_data(test_data, {}, {}, {})
            return {"charts": [chart.__dict__ for chart in charts]}
    except Exception as e:
        return {"error": str(e)}

@router.get("/status/{report_id}", response_model=ReportStatus)
async def get_report_status(report_id: str):
    """获取报告生成状态"""
    if report_id not in report_status:
        raise HTTPException(status_code=404, detail="报告ID不存在")
    
    status_info = report_status[report_id]
    return ReportStatus(
        report_id=report_id,
        status=status_info["status"],
        progress=status_info["progress"],
        message=status_info["message"],
        created_at=status_info["created_at"]
    )

@router.get("/result/{report_id}")
async def get_report_result(report_id: str):
    """获取报告结果"""
    if report_id not in report_status:
        raise HTTPException(status_code=404, detail="报告ID不存在")
    
    status_info = report_status[report_id]
    
    if status_info["status"] == "completed":
        return {
            "report_id": report_id,
            "status": "completed",
            "data": status_info["result"]
        }
    elif status_info["status"] == "failed":
        raise HTTPException(status_code=500, detail=f"报告生成失败: {status_info['message']}")
    else:
        raise HTTPException(status_code=202, detail=f"报告正在生成中，当前状态: {status_info['status']}")

@router.get("/list")
async def list_reports():
    """列出所有报告"""
    reports = []
    for report_id, status_info in report_status.items():
        reports.append({
            "report_id": report_id,
            "status": status_info["status"],
            "progress": status_info["progress"],
            "message": status_info["message"],
            "created_at": status_info["created_at"]
        })
    
    # 按创建时间倒序排列
    reports.sort(key=lambda x: x["created_at"], reverse=True)
    
    return {
        "total": len(reports),
        "reports": reports
    }

@router.delete("/{report_id}")
async def delete_report(report_id: str):
    """删除报告"""
    if report_id not in report_status:
        raise HTTPException(status_code=404, detail="报告ID不存在")
    
    del report_status[report_id]
    logger.info(f"报告 {report_id} 已删除")
    
    return {"message": "报告已删除"}

# 健康检查
@router.get("/health")
async def health_check():
    """报告API健康检查"""
    return {
        "status": "healthy",
        "service": "report-api",
        "timestamp": datetime.now().isoformat(),
        "active_reports": len([r for r in report_status.values() if r["status"] in ["queued", "processing"]])
    }
