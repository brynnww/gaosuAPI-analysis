# APIs module
"""
API接口层模块
包含FastAPI服务器、报告API和MCP服务器
"""
