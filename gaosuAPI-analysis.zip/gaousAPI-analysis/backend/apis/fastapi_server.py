import asyncio
import sys
import os
import json
import time
import uuid
from typing import Optional, List, Dict, Any, AsyncGenerator
from contextlib import asynccontextmanager
import logging

from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse, JSONResponse
from pydantic import BaseModel, Field
import uvicorn

from clients.mcp_client import MCPClient
from apis.report_api import router as report_router

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("fastapi-toll-server")

# 全局MCP客户端实例
mcp_client: Optional[MCPClient] = None

# OpenAI API 兼容的数据模型
class ChatMessage(BaseModel):
    role: str = Field(..., description="消息角色: user, assistant, system")
    content: str = Field(..., description="消息内容")

class ChatCompletionRequest(BaseModel):
    model: str = Field(default="toll-management", description="模型名称")
    messages: List[ChatMessage] = Field(..., description="对话消息列表")
    stream: bool = Field(default=False, description="是否流式返回")
    max_tokens: Optional[int] = Field(default=None, description="最大token数")
    temperature: Optional[float] = Field(default=None, description="温度参数")
    top_p: Optional[float] = Field(default=None, description="top_p参数")

class ChatCompletionChoice(BaseModel):
    index: int
    message: ChatMessage
    finish_reason: str

class ChatCompletionUsage(BaseModel):
    prompt_tokens: int
    completion_tokens: int
    total_tokens: int

class ChatCompletionResponse(BaseModel):
    id: str
    object: str = "chat.completion"
    created: int
    model: str
    choices: List[ChatCompletionChoice]
    usage: ChatCompletionUsage

class ChatCompletionStreamChoice(BaseModel):
    index: int
    delta: Dict[str, Any]
    finish_reason: Optional[str] = None

class ChatCompletionStreamResponse(BaseModel):
    id: str
    object: str = "chat.completion.chunk"
    created: int
    model: str
    choices: List[ChatCompletionStreamChoice]

# 应用生命周期管理
@asynccontextmanager
async def lifespan(app: FastAPI):
    # 启动时初始化
    global mcp_client
    try:
        logger.info("初始化MCP客户端...")
        mcp_client = MCPClient()
        
        # 获取MCP服务器脚本路径
        script_dir = os.path.dirname(os.path.abspath(__file__))
        default_mcp_path = os.path.join(script_dir, "platformbilling_mcp.py")
        mcp_server_path = os.getenv("MCP_SERVER_PATH", default_mcp_path)
        if not os.path.exists(mcp_server_path):
            logger.error(f"MCP服务器脚本不存在: {mcp_server_path}")
            raise FileNotFoundError(f"MCP服务器脚本不存在: {mcp_server_path}")
        
        await mcp_client.connect_to_server(mcp_server_path)
        logger.info("MCP客户端初始化完成")
        
        yield
        
    except Exception as e:
        logger.error(f"MCP客户端初始化失败: {e}")
        raise
    finally:
        # 关闭时清理
        if mcp_client:
            try:
                await mcp_client.cleanup()
                logger.info("MCP客户端清理完成")
            except Exception as e:
                logger.error(f"MCP客户端清理失败: {e}")

# 创建FastAPI应用
app = FastAPI(
    title="收费管理API服务",
    description="基于MCP的收费站管理API服务，兼容OpenAI接口格式",
    version="1.0.0",
    lifespan=lifespan
)

# 添加CORS中间件
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # 生产环境应该设置具体的域名
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 注册报告API路由
app.include_router(report_router)

# 错误处理
@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    logger.error(f"全局异常处理: {exc}")
    return JSONResponse(
        status_code=500,
        content={"error": {"message": str(exc), "type": "internal_error"}}
    )

# 健康检查端点
@app.get("/health")
async def health_check():
    """健康检查端点"""
    global mcp_client
    if mcp_client is None:
        raise HTTPException(status_code=503, detail="MCP客户端未初始化")
    
    return {
        "status": "healthy",
        "timestamp": int(time.time()),
        "mcp_connected": mcp_client.session is not None
    }

# 获取模型列表（OpenAI兼容）
@app.get("/v1/models")
async def list_models():
    """获取可用模型列表"""
    return {
        "object": "list",
        "data": [
            {
                "id": "toll-management",
                "object": "model",
                "created": int(time.time()),
                "owned_by": "toll-management-system",
                "permission": [],
                "root": "toll-management",
                "parent": None
            }
        ]
    }

# 主要的聊天接口
@app.post("/v1/chat/completions")
async def chat_completions(request: ChatCompletionRequest):
    """OpenAI兼容的聊天完成接口"""
    global mcp_client
    
    if mcp_client is None:
        raise HTTPException(status_code=503, detail="MCP客户端未初始化")
    
    if not mcp_client.session:
        raise HTTPException(status_code=503, detail="MCP服务器连接断开")
    
    # 提取用户消息（简化处理，只取最后一条用户消息）
    user_message = None
    for msg in reversed(request.messages):
        if msg.role == "user":
            user_message = msg.content
            break
    
    if not user_message:
        raise HTTPException(status_code=400, detail="未找到用户消息")
    
    try:
        # 调用MCP客户端处理查询
        logger.info(f"处理用户查询: {user_message}")
        response_content = await mcp_client.process_query(user_message)
        
        # 生成响应ID和时间戳
        completion_id = f"chatcmpl-{uuid.uuid4().hex[:8]}"
        created = int(time.time())
        
        # 简单的token计算（实际生产中应该使用真正的tokenizer）
        prompt_tokens = len(user_message) // 4  # 粗略估算
        completion_tokens = len(response_content) // 4  # 粗略估算
        total_tokens = prompt_tokens + completion_tokens
        
        if request.stream:
            # 流式响应
            return StreamingResponse(
                stream_chat_response(completion_id, created, request.model, response_content),
                media_type="text/plain"
            )
        else:
            # 非流式响应
            return ChatCompletionResponse(
                id=completion_id,
                created=created,
                model=request.model,
                choices=[
                    ChatCompletionChoice(
                        index=0,
                        message=ChatMessage(role="assistant", content=response_content),
                        finish_reason="stop"
                    )
                ],
                usage=ChatCompletionUsage(
                    prompt_tokens=prompt_tokens,
                    completion_tokens=completion_tokens,
                    total_tokens=total_tokens
                )
            )
    
    except Exception as e:
        logger.error(f"处理查询时出错: {e}")
        raise HTTPException(status_code=500, detail=f"处理查询失败: {str(e)}")

# 流式响应生成器
async def stream_chat_response(completion_id: str, created: int, model: str, content: str) -> AsyncGenerator[str, None]:
    """生成流式响应数据"""
    
    # 开始流式响应
    start_chunk = ChatCompletionStreamResponse(
        id=completion_id,
        created=created,
        model=model,
        choices=[
            ChatCompletionStreamChoice(
                index=0,
                delta={"role": "assistant", "content": ""}
            )
        ]
    )
    yield f"data: {start_chunk.model_dump_json()}\n\n"
    
    # 分块发送内容
    chunk_size = 50  # 每次发送的字符数
    for i in range(0, len(content), chunk_size):
        chunk_content = content[i:i + chunk_size]
        
        chunk = ChatCompletionStreamResponse(
            id=completion_id,
            created=created,
            model=model,
            choices=[
                ChatCompletionStreamChoice(
                    index=0,
                    delta={"content": chunk_content}
                )
            ]
        )
        yield f"data: {chunk.model_dump_json()}\n\n"
        
        # 添加小延迟以模拟真实的流式效果
        await asyncio.sleep(0.01)
    
    # 结束流式响应
    end_chunk = ChatCompletionStreamResponse(
        id=completion_id,
        created=created,
        model=model,
        choices=[
            ChatCompletionStreamChoice(
                index=0,
                delta={},
                finish_reason="stop"
            )
        ]
    )
    yield f"data: {end_chunk.model_dump_json()}\n\n"
    yield "data: [DONE]\n\n"

# 获取服务器信息
@app.get("/")
async def root():
    """服务器根路径信息"""
    return {
        "service": "收费管理API服务",
        "version": "1.0.0",
        "description": "基于MCP的收费站管理API服务，兼容OpenAI接口格式",
        "endpoints": {
            "health": "/health",
            "models": "/v1/models",
            "chat": "/v1/chat/completions"
        },
        "docs": "/docs"
    }

# 开发环境启动
if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="启动收费管理FastAPI服务")
    parser.add_argument("--host", default="0.0.0.0", help="绑定主机地址")
    parser.add_argument("--port", type=int, default=8000, help="绑定端口")
    parser.add_argument("--reload", action="store_true", help="启用热重载")
    
    args = parser.parse_args()
    
    uvicorn.run(
        "fastapi_server:app",
        host=args.host,
        port=args.port,
        reload=args.reload,
        log_level="info"
    )