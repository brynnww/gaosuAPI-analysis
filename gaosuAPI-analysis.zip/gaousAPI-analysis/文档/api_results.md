# 管控平台开放接口 - 请求结果汇总

> 时间范围：2025-03-01 ~ 2025-03-31

> 注：所有请求均添加 Header `Authorization: Bear xxx`

---

### 收费站启停状态统计 - 哈绥分公司(202000)
**请求路由：** `/gssfApi2/v1/api/station/getStationStateAnalysis`

**请求参数：**

```json
{"query":{"unitId":"202000"}}
```

**返回结果（HTTP 200）：**
```json
{"code":1,"msg":"查看当前权限下收费站的启停状态统计请求成功","success":true,"data":{"detailList":[{"stationId":"G0010230060040","stationName":"下城子站","open":true},{"stationId":"G0010230060050","stationName":"永安站","open":true},{"stationId":"G0010230040100","stationName":"乌吉密站","open":true},{"stationId":"G0010230060060","stationName":"绥阳站","open":true},{"stationId":"G0010230040110","stationName":"尚志站","open":true},{"stationId":"G0010230040010","stationName":"哈尔滨站","open":true},{"stationId":"G0010230040120","stationName":"一面坡站","open":true},{"stationId":"G0010230060070","stationName":"绥芬河站","open":true},{"stationId":"G0010230040020","stationName":"阿城站","open":true},{"stationId":"G0010230040130","stationName":"苇河站","open":true},{"stationId":"G0010230040140","stationName":"亚布力站","open":true},{"stationId":"G0010230060010","stationName":"磨刀石站","open":true},{"stationId":"G0010230040040","stationName":"亚沟站","open":true},{"stationId":"G0010230060020","stationName":"穆棱站","open":true},{"stationId":"G0010230040150","stationName":"明新站","open":true},{"stationId":"G0010230060030","stationName":"兴源站","open":true},{"stationId":"G0010230040050","stationName":"动物园站","open":true},{"stationId":"G0010230040060","stationName":"玉泉站","open":true},{"stationId":"G0010230040070","stationName":"小岭站","open":true},{"stationId":"G0010230040080","stationName":"平山站","open":true},{"stationId":"G0010230040090","stationName":"帽儿山站","open":true},{"stationId":"G0010230050010","stationName":"横道站","open":true},{"stationId":"G0010230050020","stationName":"海林站","open":true},{"stationId":"G0010230050030","stationName":"牡丹江站","open":true}],"openCountT":24,"openCountF":0}}
```

---

### 收费站启停状态统计 - 哈同分公司(204000)
**请求路由：** `/gssfApi2/v1/api/station/getStationStateAnalysis`

**请求参数：**
```json
{"query":{"unitId":"204000"}}
```

**返回结果（HTTP 200）：**
```json
{"code":1,"msg":"查看当前权限下收费站的启停状态统计请求成功","success":true,"data":{"detailList":[{"stationId":"G1011230030030","stationName":"依兰站","open":true},{"stationId":"G1011230030010","stationName":"佳西站","open":true},{"stationId":"G1011230030050","stationName":"高楞站","open":true},{"stationId":"G1011230040030","stationName":"会发站","open":true},{"stationId":"G1012230010010","stationName":"黑瞎子岛站","open":true},{"stationId":"G1011230040050","stationName":"常安站","open":true},{"stationId":"G1011230010060","stationName":"二九一站","open":true},{"stationId":"G1011230010040","stationName":"富锦站","open":true},{"stationId":"G1011230040010","stationName":"方正站","open":true},{"stationId":"G1011230010020","stationName":"二龙山站","open":true},{"stationId":"G1011230040070","stationName":"宾西站","open":true},{"stationId":"G1011230030040","stationName":"达连河站","open":true},{"stationId":"G0011230010010","stationName":"万兴站","open":true},{"stationId":"G1011230030020","stationName":"宏克力站","open":true},{"stationId":"G1011230040020","stationName":"方通站","open":true},{"stationId":"G1011230040040","stationName":"摆渡站","open":true},{"stationId":"G1011230010070","stationName":"双鸭山站","open":true},{"stationId":"G1011230010050","stationName":"锦山站","open":true},{"stationId":"G1011230020010","stationName":"集贤站","open":true},{"stationId":"G1011230010030","stationName":"富锦东站","open":true},{"stationId":"G1011230020030","stationName":"佳南站","open":true},{"stationId":"G1011230010010","stationName":"同江站","open":true},{"stationId":"G2313230010010","stationName":"黑龙江富绥大桥站","open":false},{"stationId":"G1011230040060","stationName":"宾州站","open":true},{"stationId":"G1012230010020","stationName":"浓桥站","open":true},{"stationId":"G1011230040080","stationName":"哈尔滨东站","open":true}],"openCountT":25,"openCountF":1}}
```

---

### 收费站启停状态统计 - 鹤大分公司(203000)
**请求路由：** `/gssfApi2/v1/api/station/getStationStateAnalysis`

**请求参数：**
```json
{"query":{"unitId":"203000"}}
```

**返回结果（HTTP 200）：**
```json
{"code":1,"msg":"查看当前权限下收费站的启停状态统计请求成功","success":true,"data":{"detailList":[{"stationId":"G0011230030010","stationName":"牡丹江南站","open":true},{"stationId":"G0011230030030","stationName":"宁安站","open":true},{"stationId":"G0011230030020","stationName":"温春站","open":true},{"stationId":"G0011230010030","stationName":"曙光站","open":true},{"stationId":"G0011230010020","stationName":"明义站","open":true},{"stationId":"G0011230030050","stationName":"镜泊湖站","open":true},{"stationId":"G0011230030040","stationName":"东京城站","open":true},{"stationId":"G0011230030060","stationName":"西湖岫站","open":true},{"stationId":"G0011230040030","stationName":"江口站","open":true},{"stationId":"G0011230040020","stationName":"鹤立站","open":true},{"stationId":"G0011230040010","stationName":"鹤岗站","open":true},{"stationId":"S0016230010010","stationName":"密山站","open":true},{"stationId":"G0011230020020","stationName":"西长发站","open":true},{"stationId":"S0016230010020","stationName":"兴凯湖站","open":true},{"stationId":"G0011230020010","stationName":"桦南站","open":true},{"stationId":"G0011230020060","stationName":"柳树站","open":true},{"stationId":"G0011230020050","stationName":"林口站","open":true},{"stationId":"G0011230020040","stationName":"麻山站","open":true},{"stationId":"G0011230020030","stationName":"兴农站","open":true},{"stationId":"G0011230020080","stationName":"铁岭河站","open":true},{"stationId":"G0011230020070","stationName":"柴河站","open":true}],"openCountT":21,"openCountF":0}}
```

---

### 收费站启停状态统计 - 齐嫩分公司(206000)
**请求路由：** `/gssfApi2/v1/api/station/getStationStateAnalysis`

**请求参数：**
```json
{"query":{"unitId":"206000"}}
```

**返回结果（HTTP 200）：**
```json
{"code":1,"msg":"查看当前权限下收费站的启停状态统计请求成功","success":true,"data":{"detailList":[{"stationId":"G4513230010010","stationName":"白桦站","open":false},{"stationId":"G0010230010060","stationName":"卜奎站","open":true},{"stationId":"G0010230010050","stationName":"奈门沁站","open":true},{"stationId":"G0010230010040","stationName":"共和站","open":true},{"stationId":"G0010230010030","stationName":"长山站","open":true},{"stationId":"S0012230010040","stationName":"依安站","open":true},{"stationId":"G4513230030010","stationName":"额尔和站","open":false},{"stationId":"G0010230010070","stationName":"建华站","open":true},{"stationId":"S0012230010050","stationName":"富海站","open":true},{"stationId":"G4512230020020","stationName":"冯屯站","open":true},{"stationId":"G0010230010020","stationName":"甘南站","open":true},{"stationId":"G4512230020010","stationName":"富裕站","open":true},{"stationId":"G4512230030010","stationName":"水师营站","open":true},{"stationId":"G4513230020020","stationName":"大杨树站","open":false},{"stationId":"G4512230010030","stationName":"老莱站","open":true},{"stationId":"G4512230010020","stationName":"农垦九三站","open":true},{"stationId":"G0010230020010","stationName":"齐齐哈尔站","open":true},{"stationId":"G4512230010010","stationName":"嫩江站","open":true},{"stationId":"G4512230030060","stationName":"泰来站","open":true},{"stationId":"G4512230030050","stationName":"塔子城站","open":true},{"stationId":"G4512230030040","stationName":"江桥站","open":true},{"stationId":"G4512230030030","stationName":"齐齐哈尔大兴站","open":true},{"stationId":"G4512230010050","stationName":"拉哈站","open":true},{"stationId":"G4512230010040","stationName":"讷河站","open":true},{"stationId":"G4512230030020","stationName":"昂昂溪站","open":true}],"openCountT":22,"openCountF":3}}
```

---

### 收费站启停状态统计 - 哈伊分公司(208000)
**请求路由：** `/gssfApi2/v1/api/station/getStationStateAnalysis`

**请求参数：**
```json
{"query":{"unitId":"208000"}}
```

**返回结果（HTTP 200）：**
```json
{"code":1,"msg":"查看当前权限下收费站的启停状态统计请求成功","success":true,"data":{"detailList":[{"stationId":"G1111230010020","stationName":"翠峦站","open":true},{"stationId":"G1111230010030","stationName":"二股站","open":true},{"stationId":"G1111230010040","stationName":"铁力站","open":true},{"stationId":"G1111230010050","stationName":"双丰站","open":true},{"stationId":"G1111230010010","stationName":"伊春站","open":true},{"stationId":"S0015230020030","stationName":"绥棱站","open":true},{"stationId":"S0015230020040","stationName":"望奎站","open":true},{"stationId":"S0015230020050","stationName":"绥西站","open":true},{"stationId":"G1111230030010","stationName":"绥化站","open":true},{"stationId":"G1111230030020","stationName":"兴隆站","open":true},{"stationId":"G1111230030030","stationName":"康金站","open":true},{"stationId":"G1111230030040","stationName":"呼兰站","open":true},{"stationId":"G1111230020010","stationName":"庆安站","open":true},{"stationId":"G1111230030050","stationName":"赵家站","open":true},{"stationId":"G1111230020020","stationName":"东富站","open":true},{"stationId":"S0015230020010","stationName":"海北站","open":true},{"stationId":"S0015230020020","stationName":"海伦站","open":true}],"openCountT":17,"openCountF":0}}
```

---

### 收费站启停状态统计 - 哈大分公司(209000)
**请求路由：** `/gssfApi2/v1/api/station/getStationStateAnalysis`

**请求参数：**

```json
{"query":{"unitId":"209000"}}
```

**返回结果（HTTP 200）：**
```json
{"code":1,"msg":"查看当前权限下收费站的启停状态统计请求成功","success":true,"data":{"detailList":[{"stationId":"G0010230030050","stationName":"大耿家站","open":true},{"stationId":"G0010230030030","stationName":"承平站","open":true},{"stationId":"G0010230030040","stationName":"肇东站","open":true},{"stationId":"G0010230030010","stationName":"卧里屯站","open":true},{"stationId":"G0010230030020","stationName":"安达站","open":true}],"openCountT":5,"openCountF":0}}
```

---

### 收费站启停状态统计 - 监控分公司(142000)
**请求路由：** `/gssfApi2/v1/api/station/getStationStateAnalysis`

**请求参数：**
```json
{"query":{"unitId":"142000"}}
```

**返回结果（HTTP 200）：**
```json
{"code":1,"msg":"查看当前权限下收费站的启停状态统计请求成功","success":true,"data":{"detailList":[{"stationId":"S0022230010060","stationName":"肇州收费站","open":true},{"stationId":"S0022230010040","stationName":"朝阳沟收费站","open":true},{"stationId":"S0022230010050","stationName":"丰乐收费站","open":true},{"stationId":"S0022230010020","stationName":"五站收费站","open":true},{"stationId":"S0022230010030","stationName":"五里明收费站","open":true},{"stationId":"S0022230010010","stationName":"中源大道收费站","open":true}],"openCountT":6,"openCountF":0}}
```

---

### 收费站启停状态统计 - 大齐分公司(205000)
**请求路由：** `/gssfApi2/v1/api/station/getStationStateAnalysis`

**请求参数：**
```json
{"query":{"unitId":"205000"}}
```

**返回结果（HTTP 200）：**
```json
{"code":1,"msg":"查看当前权限下收费站的启停状态统计请求成功","success":true,"data":{"detailList":[{"stationId":"G0010230020080","stationName":"庆东站","open":true},{"stationId":"G0010230020040","stationName":"花园站","open":true},{"stationId":"G0010230020050","stationName":"庆北站","open":true},{"stationId":"G0010230020060","stationName":"机场路站","open":true},{"stationId":"G0010230020070","stationName":"城北站","open":true},{"stationId":"G0010230020020","stationName":"鹤鸣湖站","open":true},{"stationId":"G0010230020030","stationName":"林甸站","open":true}],"openCountT":7,"openCountF":0}}
```

---

### 收费站启停状态统计 - 绥庆分公司(230113)
**请求路由：** `/gssfApi2/v1/api/station/getStationStateAnalysis`

**请求参数：**
```json
{"query":{"unitId":"230113"}}
```

**返回结果（HTTP 200）：**
```json
{"code":1,"msg":"查看当前权限下收费站的启停状态统计请求成功","success":true,"data":{"detailList":[{"stationId":"S0018230010010","stationName":"绥化北收费站","open":true},{"stationId":"S0018230010020","stationName":"卫星收费站","open":true},{"stationId":"S0018230010050","stationName":"青冈收费站","open":true},{"stationId":"S0018230010060","stationName":"燎原收费站","open":true},{"stationId":"S0018230010030","stationName":"望奎南收费站","open":true},{"stationId":"S0018230010040","stationName":"民政收费站","open":true},{"stationId":"S0018230010090","stationName":"红岗东收费站","open":true},{"stationId":"S0018230010070","stationName":"火石山收费站","open":true},{"stationId":"S0018230010080","stationName":"万宝山收费站","open":true}],"openCountT":9,"openCountF":0}}
```

---

### 集团实时交易额
**请求路由：** `/gssfApi2/v1/api/trade/realTimeTurnover`

**请求参数：**
```json
{}
```

**返回结果（HTTP 200）：**
```json
{"code":1,"msg":"集团交易额数据请求成功","success":true,"data":{"todayTurnover":15661089,"todayETCTurnover":8503517,"todayCashTurnover":435249,"todayMobileTurnover":6722323,"monthTurnover":286784879,"yearTurnover":3759470570}}
```

---

### 分公司维度交易额 - 支付方式
**请求路由：** `/gssfApi2/v1/api/trade/companyPayTypeTurnover`

**请求参数：**
```json
{"body":{"beginTime":"2025-03-01","endTime":"2025-03-31"}}
```

**返回结果（HTTP 200）：**
```json
{"code":1,"msg":"按支付方式获取分公司维度交易额请求成功","success":true,"data":{"payTypeTurnoverList":[{"unitId":"201000","unitName":"哈尔滨分公司","turnover":126603311,"etcTurnover":101760369,"cashTurnover":1245305,"mobileTurnover":23597637,"turnoverD":126603310.75,"etcTurnoverD":101760369.15,"cashTurnoverD":1245305.0,"mobileTurnoverD":23597636.6},{"unitId":"204000","unitName":"哈同分公司","turnover":78289586,"etcTurnover":52870304,"cashTurnover":2307021,"mobileTurnover":23112261,"turnoverD":78289586.19,"etcTurnoverD":52870303.78,"cashTurnoverD":2307021.0,"mobileTurnoverD":23112261.41},{"unitId":"206000","unitName":"齐嫩分公司","turnover":53873094,"etcTurnover":31972941,"cashTurnover":2291445,"mobileTurnover":19608707,"turnoverD":53873093.74,"etcTurnoverD":31972941.44,"cashTurnoverD":2291445.0,"mobileTurnoverD":19608707.3},{"unitId":"202000","unitName":"哈绥分公司","turnover":45538388,"etcTurnover":32004734,"cashTurnover":1018175,"mobileTurnover":12515480,"turnoverD":45538388.2,"etcTurnoverD":32004733.7,"cashTurnoverD":1018175.0,"mobileTurnoverD":12515479.5},{"unitId":"208000","unitName":"哈伊分公司","turnover":40889285,"etcTurnover":23924157,"cashTurnover":1724245,"mobileTurnover":15240883,"turnoverD":40889284.98,"etcTurnoverD":23924157.17,"cashTurnoverD":1724245.0,"mobileTurnoverD":15240882.81},{"unitId":"209000","unitName":"哈大分公司","turnover":32009767,"etcTurnover":16821622,"cashTurnover":77388,"mobileTurnover":15110757,"turnoverD":32009766.52,"etcTurnoverD":16821622.02,"cashTurnoverD":77388.0,"mobileTurnoverD":15110756.5},{"unitId":"203000","unitName":"鹤大分公司","turnover":31811959,"etcTurnover":20237792,"cashTurnover":1107347,"mobileTurnover":10466819,"turnoverD":31811958.67,"etcTurnoverD":20237792.33,"cashTurnoverD":1107347.0,"mobileTurnoverD":10466819.34},{"unitId":"207000","unitName":"北黑分公司","turnover":23892349,"etcTurnover":13862958,"cashTurnover":1030064,"mobileTurnover":8999327,"turnoverD":23892349.12,"etcTurnoverD":13862957.8,"cashTurnoverD":1030064.0,"mobileTurnoverD":8999327.32},{"unitId":"205000","unitName":"大齐分公司","turnover":10108618,"etcTurnover":5614452,"cashTurnover":290454,"mobileTurnover":4203712,"turnoverD":10108618.04,"etcTurnoverD":5614452.05,"cashTurnoverD":290454.0,"mobileTurnoverD":4203711.99},{"unitId":"142000","unitName":"监控分公司","turnover":8586190,"etcTurnover":4639768,"cashTurnover":32988,"mobileTurnover":3913434,"turnoverD":8586189.98,"etcTurnoverD":4639768.39,"cashTurnoverD":32988.0,"mobileTurnoverD":3913433.59},{"unitId":"230113","unitName":"绥庆分公司","turnover":7601720,"etcTurnover":4002427,"cashTurnover":32776,"mobileTurnover":3566517,"turnoverD":7601719.88,"etcTurnoverD":4002426.84,"cashTurnoverD":32776.0,"mobileTurnoverD":3566517.04}],"totalTurnover":459204266,"etcTotalTurnover":307711525,"cashTotalTurnover":11157208,"mobileTotalTurnover":140335533}}
```

---

### 分公司维度交易额 - 计费车型
**请求路由：** `/gssfApi2/v1/api/trade/companyVehTypeTurnover`

**请求参数：**
```json
{"body":{"beginTime":"2025-03-01","endTime":"2025-03-31"}}
```

**返回结果（HTTP 200）：**
```json
{"code":1,"msg":"按计费车型获取分公司维度交易额请求成功","success":true,"data":{"vehTypeTurnoverList":[{"unitId":"201000","unitName":"哈尔滨分公司","turnover":126603311,"carTurnover":32228680,"truckTurnover":94057516,"specialTurnover":317115,"turnoverD":126603310.75,"carTurnoverD":32228679.62,"truckTurnoverD":94057516.43,"specialTurnoverD":317114.7},{"unitId":"204000","unitName":"哈同分公司","turnover":78289586,"carTurnover":35359669,"truckTurnover":42713671,"specialTurnover":216246,"turnoverD":78289586.19,"carTurnoverD":35359669.29,"truckTurnoverD":42713670.68,"specialTurnoverD":216246.22},{"unitId":"206000","unitName":"齐嫩分公司","turnover":53873094,"carTurnover":26327252,"truckTurnover":27367476,"specialTurnover":178366,"turnoverD":53873093.74,"carTurnoverD":26327252.2,"truckTurnoverD":27367475.8,"specialTurnoverD":178365.74},{"unitId":"202000","unitName":"哈绥分公司","turnover":45538388,"carTurnover":19897619,"truckTurnover":25358794,"specialTurnover":281975,"turnoverD":45538388.2,"carTurnoverD":19897618.62,"truckTurnoverD":25358794.1,"specialTurnoverD":281975.48},{"unitId":"208000","unitName":"哈伊分公司","turnover":40889285,"carTurnover":23901924,"truckTurnover":16840453,"specialTurnover":146908,"turnoverD":40889284.98,"carTurnoverD":23901924.27,"truckTurnoverD":16840453.11,"specialTurnoverD":146907.6},{"unitId":"209000","unitName":"哈大分公司","turnover":32009767,"carTurnover":23185483,"truckTurnover":8755378,"specialTurnover":68905,"turnoverD":32009766.52,"carTurnoverD":23185483.41,"truckTurnoverD":8755377.88,"specialTurnoverD":68905.23},{"unitId":"203000","unitName":"鹤大分公司","turnover":31811959,"carTurnover":17116617,"truckTurnover":14602919,"specialTurnover":92422,"turnoverD":31811958.67,"carTurnoverD":17116617.41,"truckTurnoverD":14602919.3,"specialTurnoverD":92421.96},{"unitId":"207000","unitName":"北黑分公司","turnover":23892349,"carTurnover":13159662,"truckTurnover":10595743,"specialTurnover":136944,"turnoverD":23892349.12,"carTurnoverD":13159662.27,"truckTurnoverD":10595743.25,"specialTurnoverD":136943.6},{"unitId":"205000","unitName":"大齐分公司","turnover":10108618,"carTurnover":5332886,"truckTurnover":4745416,"specialTurnover":30316,"turnoverD":10108618.04,"carTurnoverD":5332886.18,"truckTurnoverD":4745416.04,"specialTurnoverD":30315.82},{"unitId":"142000","unitName":"监控分公司","turnover":8586190,"carTurnover":5871546,"truckTurnover":2691401,"specialTurnover":23243,"turnoverD":8586189.98,"carTurnoverD":5871545.72,"truckTurnoverD":2691401.21,"specialTurnoverD":23243.05},{"unitId":"230113","unitName":"绥庆分公司","turnover":7601720,"carTurnover":4647436,"truckTurnover":2912346,"specialTurnover":41938,"turnoverD":7601719.88,"carTurnoverD":4647436.03,"truckTurnoverD":2912345.99,"specialTurnoverD":41937.86}],"totalTurnover":459204266,"carTotalTurnover":207028775,"truckTotalTurnover":250641114,"specialTotalTurnover":1534377}}
```

---

### 收费站维度交易额 - 支付方式 - 哈绥分公司(202000)
**请求路由：** `/gssfApi2/v1/api/trade/stationPayTypeTurnover`

**请求参数：**
```json
{"body":{"unitId":"202000","beginTime":"2025-03-01","endTime":"2025-03-31"}}
```

**返回结果（HTTP 200）：**
```json
{"code":1,"msg":"按支付方式获取收费站维度交易额请求成功","success":true,"data":{"payTypeTurnoverList":[{"unitId":"G0010230060070","unitName":"绥芬河站","turnover":11792199,"etcTurnover":10379306,"cashTurnover":116158,"mobileTurnover":1296735,"turnoverD":11792198.63,"etcTurnoverD":10379305.69,"cashTurnoverD":116158.0,"mobileTurnoverD":1296734.94},{"unitId":"G0010230040010","unitName":"哈尔滨站","turnover":10395609,"etcTurnover":6970010,"cashTurnover":86264,"mobileTurnover":3339335,"turnoverD":10395609.28,"etcTurnoverD":6970009.91,"cashTurnoverD":86264.0,"mobileTurnoverD":3339335.37},{"unitId":"G0010230050030","unitName":"牡丹江站","turnover":3635394,"etcTurnover":2365473,"cashTurnover":113644,"mobileTurnover":1156277,"turnoverD":3635394.21,"etcTurnoverD":2365472.86,"cashTurnoverD":113644.0,"mobileTurnoverD":1156277.35},{"unitId":"G0010230040020","unitName":"阿城站","turnover":3440974,"etcTurnover":2113107,"cashTurnover":14815,"mobileTurnover":1313053,"turnoverD":3440974.32,"etcTurnoverD":2113106.72,"cashTurnoverD":14815.0,"mobileTurnoverD":1313052.6},{"unitId":"G0010230060040","unitName":"下城子站","turnover":2660555,"etcTurnover":1869382,"cashTurnover":42549,"mobileTurnover":748624,"turnoverD":2660554.51,"etcTurnoverD":1869381.54,"cashTurnoverD":42549.0,"mobileTurnoverD":748623.97},{"unitId":"G0010230040110","unitName":"尚志站","turnover":2164201,"etcTurnover":1328788,"cashTurnover":77778,"mobileTurnover":757635,"turnoverD":2164201.06,"etcTurnoverD":1328788.19,"cashTurnoverD":77778.0,"mobileTurnoverD":757634.87},{"unitId":"G0010230040100","unitName":"乌吉密站","turnover":1836588,"etcTurnover":1049870,"cashTurnover":75069,"mobileTurnover":711649,"turnoverD":1836588.38,"etcTurnoverD":1049870.04,"cashTurnoverD":75069.0,"mobileTurnoverD":711649.34},{"unitId":"G0010230050020","unitName":"海林站","turnover":1653640,"etcTurnover":1089532,"cashTurnover":56187,"mobileTurnover":507921,"turnoverD":1653640.23,"etcTurnoverD":1089531.82,"cashTurnoverD":56187.0,"mobileTurnoverD":507921.41},{"unitId":"G0010230060010","unitName":"磨刀石站","turnover":1293885,"etcTurnover":858196,"cashTurnover":82170,"mobileTurnover":353519,"turnoverD":1293884.74,"etcTurnoverD":858196.24,"cashTurnoverD":82170.0,"mobileTurnoverD":353518.5},{"unitId":"G0010230040140","unitName":"亚布力站","turnover":968761,"etcTurnover":475093,"cashTurnover":49714,"mobileTurnover":443954,"turnoverD":968760.81,"etcTurnoverD":475093.16,"cashTurnoverD":49714.0,"mobileTurnoverD":443953.65},{"unitId":"G0010230040130","unitName":"苇河站","turnover":800908,"etcTurnover":487090,"cashTurnover":46292,"mobileTurnover":267526,"turnoverD":800907.74,"etcTurnoverD":487090.12,"cashTurnoverD":46292.0,"mobileTurnoverD":267525.62},{"unitId":"G0010230040040","unitName":"亚沟站","turnover":726531,"etcTurnover":483543,"cashTurnover":24230,"mobileTurnover":218758,"turnoverD":726531.42,"etcTurnoverD":483543.36,"cashTurnoverD":24230.0,"mobileTurnoverD":218758.06},{"unitId":"G0010230060060","unitName":"绥阳站","turnover":697675,"etcTurnover":465492,"cashTurnover":29846,"mobileTurnover":202337,"turnoverD":697675.05,"etcTurnoverD":465492.01,"cashTurnoverD":29846.0,"mobileTurnoverD":202337.04},{"unitId":"G0010230040120","unitName":"一面坡站","turnover":529296,"etcTurnover":330740,"cashTurnover":27797,"mobileTurnover":170759,"turnoverD":529295.83,"etcTurnoverD":330739.89,"cashTurnoverD":27797.0,"mobileTurnoverD":170758.94},{"unitId":"G0010230040070","unitName":"小岭站","turnover":474714,"etcTurnover":300935,"cashTurnover":20967,"mobileTurnover":152812,"turnoverD":474713.97,"etcTurnoverD":300935.4,"cashTurnoverD":20967.0,"mobileTurnoverD":152811.57},{"unitId":"G0010230040090","unitName":"帽儿山站","turnover":442819,"etcTurnover":240063,"cashTurnover":21095,"mobileTurnover":181661,"turnoverD":442818.67,"etcTurnoverD":240063.13,"cashTurnoverD":21095.0,"mobileTurnoverD":181660.54},{"unitId":"G0010230060020","unitName":"穆棱站","turnover":430562,"etcTurnover":265097,"cashTurnover":36099,"mobileTurnover":129366,"turnoverD":430561.55,"etcTurnoverD":265096.7,"cashTurnoverD":36099.0,"mobileTurnoverD":129365.85},{"unitId":"G0010230040060","unitName":"玉泉站","turnover":314090,"etcTurnover":242949,"cashTurnover":8811,"mobileTurnover":62330,"turnoverD":314090.29,"etcTurnoverD":242948.9,"cashTurnoverD":8811.0,"mobileTurnoverD":62330.39},{"unitId":"G0010230040150","unitName":"明新站","turnover":307366,"etcTurnover":173296,"cashTurnover":20425,"mobileTurnover":113645,"turnoverD":307366.06,"etcTurnoverD":173296.05,"cashTurnoverD":20425.0,"mobileTurnoverD":113645.01},{"unitId":"G0010230050010","unitName":"横道站","turnover":289911,"etcTurnover":147276,"cashTurnover":17665,"mobileTurnover":124969,"turnoverD":289910.82,"etcTurnoverD":147276.44,"cashTurnoverD":17665.0,"mobileTurnoverD":124969.38},{"unitId":"G0010230060030","unitName":"兴源站","turnover":254018,"etcTurnover":152526,"cashTurnover":19353,"mobileTurnover":82139,"turnoverD":254018.05,"etcTurnoverD":152525.74,"cashTurnoverD":19353.0,"mobileTurnoverD":82139.31},{"unitId":"G0010230060050","unitName":"永安站","turnover":240356,"etcTurnover":133381,"cashTurnover":20614,"mobileTurnover":86361,"turnoverD":240356.34,"etcTurnoverD":133381.41,"cashTurnoverD":20614.0,"mobileTurnoverD":86360.93},{"unitId":"G0010230040080","unitName":"平山站","turnover":165593,"etcTurnover":70429,"cashTurnover":10196,"mobileTurnover":84967,"turnoverD":165592.51,"etcTurnoverD":70429.45,"cashTurnoverD":10196.0,"mobileTurnoverD":84967.06},{"unitId":"G0010230040050","unitName":"动物园站","turnover":22744,"etcTurnover":13159,"cashTurnover":437,"mobileTurnover":9148,"turnoverD":22743.73,"etcTurnoverD":13158.93,"cashTurnoverD":437.0,"mobileTurnoverD":9147.8}],"totalTurnover":45538388,"etcTotalTurnover":32004734,"cashTotalTurnover":1018175,"mobileTotalTurnover":12515480}}
```

---

### 收费站维度交易额 - 计费车型 - 哈绥分公司(202000)
**请求路由：** `/gssfApi2/v1/api/trade/stationVehTypeTurnover`

**请求参数：**
```json
{"body":{"unitId":"202000","beginTime":"2025-03-01","endTime":"2025-03-31"}}
```

**返回结果（HTTP 502）：**
```json
{"raw":""}
```

---

### 收费站维度交易额 - 支付方式 - 哈同分公司(204000)
**请求路由：** `/gssfApi2/v1/api/trade/stationPayTypeTurnover`

**请求参数：**
```json
{"body":{"unitId":"204000","beginTime":"2025-03-01","endTime":"2025-03-31"}}
```

**返回结果（HTTP 200）：**
```json
{"code":1,"msg":"按支付方式获取收费站维度交易额请求成功","success":true,"data":{"payTypeTurnoverList":[{"unitId":"G1011230040080","unitName":"哈尔滨东站","turnover":20956033,"etcTurnover":16165396,"cashTurnover":409324,"mobileTurnover":4381313,"turnoverD":20956032.88,"etcTurnoverD":16165395.78,"cashTurnoverD":409324.0,"mobileTurnoverD":4381313.1},{"unitId":"G0011230010010","unitName":"万兴站","turnover":6518601,"etcTurnover":3878735,"cashTurnover":215024,"mobileTurnover":2424842,"turnoverD":6518600.84,"etcTurnoverD":3878734.69,"cashTurnoverD":215024.0,"mobileTurnoverD":2424842.15},{"unitId":"G1011230020030","unitName":"佳南站","turnover":6504241,"etcTurnover":4465915,"cashTurnover":253441,"mobileTurnover":1784885,"turnoverD":6504240.82,"etcTurnoverD":4465914.84,"cashTurnoverD":253441.0,"mobileTurnoverD":1784884.98},{"unitId":"G1011230010070","unitName":"双鸭山站","turnover":5139990,"etcTurnover":3282286,"cashTurnover":150714,"mobileTurnover":1706989,"turnoverD":5139989.79,"etcTurnoverD":3282286.37,"cashTurnoverD":150714.0,"mobileTurnoverD":1706989.42},{"unitId":"G1011230030030","unitName":"依兰站","turnover":4142028,"etcTurnover":2605721,"cashTurnover":163277,"mobileTurnover":1373030,"turnoverD":4142028.44,"etcTurnoverD":2605721.18,"cashTurnoverD":163277.0,"mobileTurnoverD":1373030.26},{"unitId":"G1011230030010","unitName":"佳西站","turnover":4097043,"etcTurnover":3248344,"cashTurnover":45245,"mobileTurnover":803454,"turnoverD":4097042.74,"etcTurnoverD":3248344.13,"cashTurnoverD":45245.0,"mobileTurnoverD":803453.61},{"unitId":"G1011230020010","unitName":"集贤站","turnover":3976367,"etcTurnover":2473221,"cashTurnover":112897,"mobileTurnover":1390249,"turnoverD":3976366.8,"etcTurnoverD":2473221.03,"cashTurnoverD":112897.0,"mobileTurnoverD":1390248.77},{"unitId":"G1011230010040","unitName":"富锦站","turnover":3292062,"etcTurnover":1949583,"cashTurnover":148389,"mobileTurnover":1194091,"turnoverD":3292062.2,"etcTurnoverD":1949582.68,"cashTurnoverD":148389.0,"mobileTurnoverD":1194090.52},{"unitId":"G1011230010020","unitName":"二龙山站","turnover":3246321,"etcTurnover":2138804,"cashTurnover":91896,"mobileTurnover":1015622,"turnoverD":3246321.22,"etcTurnoverD":2138803.57,"cashTurnoverD":91896.0,"mobileTurnoverD":1015621.65},{"unitId":"G1011230040070","unitName":"宾西站","turnover":3128746,"etcTurnover":2073619,"cashTurnover":47768,"mobileTurnover":1007359,"turnoverD":3128746.22,"etcTurnoverD":2073618.87,"cashTurnoverD":47768.0,"mobileTurnoverD":1007359.35},{"unitId":"G1011230040020","unitName":"方通站","turnover":2862349,"etcTurnover":1885326,"cashTurnover":95480,"mobileTurnover":881543,"turnoverD":2862349.46,"etcTurnoverD":1885326.2,"cashTurnoverD":95480.0,"mobileTurnoverD":881543.26},{"unitId":"G1011230040060","unitName":"宾州站","turnover":2651154,"etcTurnover":1469036,"cashTurnover":70236,"mobileTurnover":1111882,"turnoverD":2651154.22,"etcTurnoverD":1469035.85,"cashTurnoverD":70236.0,"mobileTurnoverD":1111882.37},{"unitId":"G1011230030050","unitName":"高楞站","turnover":1923937,"etcTurnover":1301821,"cashTurnover":95459,"mobileTurnover":526657,"turnoverD":1923936.59,"etcTurnoverD":1301820.83,"cashTurnoverD":95459.0,"mobileTurnoverD":526656.76},{"unitId":"G1011230010010","unitName":"同江站","turnover":1754761,"etcTurnover":1080715,"cashTurnover":24355,"mobileTurnover":649691,"turnoverD":1754760.67,"etcTurnoverD":1080714.6,"cashTurnoverD":24355.0,"mobileTurnoverD":649691.07},{"unitId":"G1011230040040","unitName":"摆渡站","turnover":1428407,"etcTurnover":833065,"cashTurnover":76509,"mobileTurnover":518833,"turnoverD":1428407.2,"etcTurnoverD":833065.04,"cashTurnoverD":76509.0,"mobileTurnoverD":518833.16},{"unitId":"G1011230010030","unitName":"富锦东站","turnover":1405510,"etcTurnover":863270,"cashTurnover":39899,"mobileTurnover":502341,"turnoverD":1405510.03,"etcTurnoverD":863269.6,"cashTurnoverD":39899.0,"mobileTurnoverD":502341.43},{"unitId":"G1011230040030","unitName":"会发站","turnover":954317,"etcTurnover":646284,"cashTurnover":35804,"mobileTurnover":272229,"turnoverD":954316.72,"etcTurnoverD":646284.19,"cashTurnoverD":35804.0,"mobileTurnoverD":272228.53},{"unitId":"G1011230040010","unitName":"方正站","turnover":854323,"etcTurnover":476641,"cashTurnover":54672,"mobileTurnover":323010,"turnoverD":854323.19,"etcTurnoverD":476641.18,"cashTurnoverD":54672.0,"mobileTurnoverD":323010.01},{"unitId":"G1011230030040","unitName":"达连河站","turnover":816343,"etcTurnover":496330,"cashTurnover":33547,"mobileTurnover":286466,"turnoverD":816342.77,"etcTurnoverD":496330.21,"cashTurnoverD":33547.0,"mobileTurnoverD":286465.56},{"unitId":"G1011230010060","unitName":"二九一站","turnover":755764,"etcTurnover":526245,"cashTurnover":36947,"mobileTurnover":192572,"turnoverD":755764.17,"etcTurnoverD":526244.77,"cashTurnoverD":36947.0,"mobileTurnoverD":192572.4},{"unitId":"G1011230040050","unitName":"常安站","turnover":697686,"etcTurnover":362216,"cashTurnover":43127,"mobileTurnover":292343,"turnoverD":697685.58,"etcTurnoverD":362216.07,"cashTurnoverD":43127.0,"mobileTurnoverD":292342.51},{"unitId":"G1012230010020","unitName":"浓桥站","turnover":569181,"etcTurnover":289466,"cashTurnover":30378,"mobileTurnover":249337,"turnoverD":569181.01,"etcTurnoverD":289466.36,"cashTurnoverD":30378.0,"mobileTurnoverD":249336.65},{"unitId":"G1011230030020","unitName":"宏克力站","turnover":315014,"etcTurnover":180983,"cashTurnover":12381,"mobileTurnover":121650,"turnoverD":315014.27,"etcTurnoverD":180983.15,"cashTurnoverD":12381.0,"mobileTurnoverD":121650.12},{"unitId":"G1011230010050","unitName":"锦山站","turnover":269580,"etcTurnover":160037,"cashTurnover":19742,"mobileTurnover":89802,"turnoverD":269580.49,"etcTurnoverD":160036.72,"cashTurnoverD":19742.0,"mobileTurnoverD":89801.77},{"unitId":"G1012230010010","unitName":"黑瞎子岛站","turnover":29828,"etcTurnover":17246,"cashTurnover":510,"mobileTurnover":12072,"turnoverD":29827.87,"etcTurnoverD":17245.87,"cashTurnoverD":510.0,"mobileTurnoverD":12072.0}],"totalTurnover":78289586,"etcTotalTurnover":52870304,"cashTotalTurnover":2307021,"mobileTotalTurnover":23112261}}
```

---

### 收费站维度交易额 - 计费车型 - 哈同分公司(204000)
**请求路由：** `/gssfApi2/v1/api/trade/stationVehTypeTurnover`

**请求参数：**
```json
{"body":{"unitId":"204000","beginTime":"2025-03-01","endTime":"2025-03-31"}}
```

**返回结果（HTTP -1）：**
```json
{"raw":"REQUEST_ERROR: HTTPConnectionPool(host='127.0.0.1', port=10808): Max retries exceeded with url: http://116.182.4.67:8088/gssfApi2/v1/api/trade/stationVehTypeTurnover (Caused by ProxyError('Unable to connect to proxy', ConnectionResetError(10054, '远程主机强迫关闭了一个现有的连接。', None, 10054, None)))"}
```

---

### 收费站维度交易额 - 支付方式 - 鹤大分公司(203000)
**请求路由：** `/gssfApi2/v1/api/trade/stationPayTypeTurnover`

**请求参数：**
```json
{"body":{"unitId":"203000","beginTime":"2025-03-01","endTime":"2025-03-31"}}
```

**返回结果（HTTP -1）：**
```json
{"raw":"REQUEST_ERROR: HTTPConnectionPool(host='127.0.0.1', port=10808): Max retries exceeded with url: http://116.182.4.67:8088/gssfApi2/v1/api/trade/stationPayTypeTurnover (Caused by ProxyError('Unable to connect to proxy', ConnectionResetError(10054, '远程主机强迫关闭了一个现有的连接。', None, 10054, None)))"}
```

---

### 收费站维度交易额 - 计费车型 - 鹤大分公司(203000)
**请求路由：** `/gssfApi2/v1/api/trade/stationVehTypeTurnover`

**请求参数：**
```json
{"body":{"unitId":"203000","beginTime":"2025-03-01","endTime":"2025-03-31"}}
```

**返回结果（HTTP 200）：**
```json
{"code":1,"msg":"按计费车型获取收费站维度交易额请求成功","success":true,"data":{"vehTypeTurnoverList":[{"unitId":"G0011230030010","unitName":"牡丹江南站","turnover":5606259,"carTurnover":2388978,"truckTurnover":3200753,"specialTurnover":16529,"turnoverD":5606259.28,"carTurnoverD":2388977.65,"truckTurnoverD":3200752.75,"specialTurnoverD":16528.88},{"unitId":"G0011230040010","unitName":"鹤岗站","turnover":5286139,"carTurnover":2684142,"truckTurnover":2591670,"specialTurnover":10328,"turnoverD":5286139.15,"carTurnoverD":2684141.97,"truckTurnoverD":2591669.54,"specialTurnoverD":10327.64},{"unitId":"G0011230020080","unitName":"铁岭河站","turnover":3392128,"carTurnover":2029364,"truckTurnover":1355720,"specialTurnover":7043,"turnoverD":3392128.16,"carTurnoverD":2029364.46,"truckTurnoverD":1355720.46,"specialTurnoverD":7043.24},{"unitId":"G0011230030030","unitName":"宁安站","turnover":2532259,"carTurnover":1428977,"truckTurnover":1092358,"specialTurnover":10924,"turnoverD":2532259.29,"carTurnoverD":1428976.76,"truckTurnoverD":1092358.32,"specialTurnoverD":10924.21},{"unitId":"G0011230020050","unitName":"林口站","turnover":2011513,"carTurnover":1081731,"truckTurnover":922650,"specialTurnover":7132,"turnoverD":2011513.46,"carTurnoverD":1081731.33,"truckTurnoverD":922650.19,"specialTurnoverD":7131.94},{"unitId":"G0011230030040","unitName":"东京城站","turnover":1928169,"carTurnover":1033248,"truckTurnover":887829,"specialTurnover":7092,"turnoverD":1928169.39,"carTurnoverD":1033248.04,"truckTurnoverD":887828.93,"specialTurnoverD":7092.42},{"unitId":"G0011230020010","unitName":"桦南站","turnover":1922813,"carTurnover":1421116,"truckTurnover":496443,"specialTurnover":5254,"turnoverD":1922812.91,"carTurnoverD":1421115.92,"truckTurnoverD":496442.8,"specialTurnoverD":5254.19},{"unitId":"G0011230040030","unitName":"江口站","turnover":1370401,"carTurnover":1049674,"truckTurnover":318446,"specialTurnover":2281,"turnoverD":1370400.51,"carTurnoverD":1049674.11,"truckTurnoverD":318445.51,"specialTurnoverD":2280.89},{"unitId":"G0011230020070","unitName":"柴河站","turnover":1202246,"carTurnover":639834,"truckTurnover":555172,"specialTurnover":7241,"turnoverD":1202246.18,"carTurnoverD":639833.63,"truckTurnoverD":555171.54,"specialTurnoverD":7241.01},{"unitId":"G0011230020020","unitName":"西长发站","turnover":1110743,"carTurnover":546632,"truckTurnover":561472,"specialTurnover":2639,"turnoverD":1110743.03,"carTurnoverD":546631.61,"truckTurnoverD":561472.47,"specialTurnoverD":2638.95},{"unitId":"G0011230040020","unitName":"鹤立站","turnover":873659,"carTurnover":483050,"truckTurnover":388330,"specialTurnover":2279,"turnoverD":873659.28,"carTurnoverD":483050.24,"truckTurnoverD":388330.3,"specialTurnoverD":2278.74},{"unitId":"G0011230030050","unitName":"镜泊湖站","turnover":819222,"carTurnover":167887,"truckTurnover":647381,"specialTurnover":3954,"turnoverD":819222.43,"carTurnoverD":167887.03,"truckTurnoverD":647381.23,"specialTurnoverD":3954.17},{"unitId":"S0016230010010","unitName":"密山站","turnover":815243,"carTurnover":629818,"truckTurnover":184765,"specialTurnover":660,"turnoverD":815243.24,"carTurnoverD":629818.38,"truckTurnoverD":184765.11,"specialTurnoverD":659.75},{"unitId":"G0011230010030","unitName":"曙光站","turnover":474648,"carTurnover":233930,"truckTurnover":239344,"specialTurnover":1374,"turnoverD":474648.07,"carTurnoverD":233929.92,"truckTurnoverD":239344.36,"specialTurnoverD":1373.79},{"unitId":"G0011230020040","unitName":"麻山站","turnover":462690,"carTurnover":261135,"truckTurnover":200109,"specialTurnover":1446,"turnoverD":462690.44,"carTurnoverD":261134.66,"truckTurnoverD":200109.34,"specialTurnoverD":1446.44},{"unitId":"G0011230020030","unitName":"兴农站","turnover":439907,"carTurnover":208484,"truckTurnover":230916,"specialTurnover":507,"turnoverD":439906.8,"carTurnoverD":208484.05,"truckTurnoverD":230916.12,"specialTurnoverD":506.63},{"unitId":"G0011230030060","unitName":"西湖岫站","turnover":420735,"carTurnover":118199,"truckTurnover":301388,"specialTurnover":1149,"turnoverD":420735.27,"carTurnoverD":118198.62,"truckTurnoverD":301387.9,"specialTurnoverD":1148.75},{"unitId":"G0011230020060","unitName":"柳树站","turnover":357581,"carTurnover":170728,"truckTurnover":183820,"specialTurnover":3033,"turnoverD":357581.06,"carTurnoverD":170728.04,"truckTurnoverD":183819.85,"specialTurnoverD":3033.17},{"unitId":"G0011230030020","unitName":"温春站","turnover":322178,"carTurnover":191529,"truckTurnover":129917,"specialTurnover":732,"turnoverD":322178.04,"carTurnoverD":191528.85,"truckTurnoverD":129917.31,"specialTurnoverD":731.88},{"unitId":"S0016230010020","unitName":"兴凯湖站","turnover":245198,"carTurnover":192202,"truckTurnover":52721,"specialTurnover":276,"turnoverD":245198.34,"carTurnoverD":192201.77,"truckTurnoverD":52720.67,"specialTurnoverD":275.9},{"unitId":"G0011230010020","unitName":"明义站","turnover":218224,"carTurnover":155960,"truckTurnover":61715,"specialTurnover":549,"turnoverD":218224.34,"carTurnoverD":155960.37,"truckTurnoverD":61714.6,"specialTurnoverD":549.37}],"totalTurnover":31811959,"carTotalTurnover":17116617,"truckTotalTurnover":14602919,"specialTotalTurnover":92422}}
```

---

### 收费站维度交易额 - 支付方式 - 哈尔滨分公司(201000)
**请求路由：** `/gssfApi2/v1/api/trade/stationPayTypeTurnover`

**请求参数：**
```json
{"body":{"unitId":"201000","beginTime":"2025-03-01","endTime":"2025-03-31"}}
```

**返回结果（HTTP 200）：**
```json
{"code":1,"msg":"按支付方式获取收费站维度交易额请求成功","success":true,"data":{"payTypeTurnoverList":[{"unitId":"G0001230010040","unitName":"新兴站","turnover":35511580,"etcTurnover":34076044,"cashTurnover":36168,"mobileTurnover":1399368,"turnoverD":35511579.73,"etcTurnoverD":34076044.22,"cashTurnoverD":36168.0,"mobileTurnoverD":1399367.51},{"unitId":"G0001230010050","unitName":"瓦盆窑站","turnover":27641351,"etcTurnover":19741776,"cashTurnover":367748,"mobileTurnover":7531827,"turnoverD":27641351.16,"etcTurnoverD":19741775.68,"cashTurnoverD":367748.0,"mobileTurnoverD":7531827.48},{"unitId":"G1001230010020","unitName":"群力站","turnover":16089955,"etcTurnover":11525410,"cashTurnover":339980,"mobileTurnover":4224565,"turnoverD":16089954.67,"etcTurnoverD":11525410.0,"cashTurnoverD":339980.0,"mobileTurnoverD":4224564.67},{"unitId":"G1001230010010","unitName":"朝阳站","turnover":13977042,"etcTurnover":12358131,"cashTurnover":97539,"mobileTurnover":1521372,"turnoverD":13977042.49,"etcTurnoverD":12358131.3,"cashTurnoverD":97539.0,"mobileTurnoverD":1521372.19},{"unitId":"G0001230010030","unitName":"双城站","turnover":10294229,"etcTurnover":7365550,"cashTurnover":37628,"mobileTurnover":2891050,"turnoverD":10294228.68,"etcTurnoverD":7365550.26,"cashTurnoverD":37628.0,"mobileTurnoverD":2891050.42},{"unitId":"G1001230020030","unitName":"长江路站","turnover":7905271,"etcTurnover":6519778,"cashTurnover":17553,"mobileTurnover":1367940,"turnoverD":7905271.22,"etcTurnoverD":6519778.28,"cashTurnoverD":17553.0,"mobileTurnoverD":1367939.94},{"unitId":"G1001230020010","unitName":"哈肇站","turnover":7536932,"etcTurnover":4485558,"cashTurnover":204217,"mobileTurnover":2847156,"turnoverD":7536931.89,"etcTurnoverD":4485558.43,"cashTurnoverD":204217.0,"mobileTurnoverD":2847156.46},{"unitId":"G1001230020040","unitName":"成高子站","turnover":3875880,"etcTurnover":3117057,"cashTurnover":20825,"mobileTurnover":737998,"turnoverD":3875879.72,"etcTurnoverD":3117056.81,"cashTurnoverD":20825.0,"mobileTurnoverD":737997.91},{"unitId":"G1001230020020","unitName":"五星站","turnover":1991927,"etcTurnover":1489437,"cashTurnover":78279,"mobileTurnover":424211,"turnoverD":1991927.42,"etcTurnoverD":1489437.09,"cashTurnoverD":78279.0,"mobileTurnoverD":424211.33},{"unitId":"G1001230010030","unitName":"松北站","turnover":1779144,"etcTurnover":1081627,"cashTurnover":45368,"mobileTurnover":652149,"turnoverD":1779143.77,"etcTurnoverD":1081627.08,"cashTurnoverD":45368.0,"mobileTurnoverD":652148.69}],"totalTurnover":126603311,"etcTotalTurnover":101760369,"cashTotalTurnover":1245305,"mobileTotalTurnover":23597637}}
```

---

### 收费站维度交易额 - 计费车型 - 哈尔滨分公司(201000)
**请求路由：** `/gssfApi2/v1/api/trade/stationVehTypeTurnover`

**请求参数：**
```json
{"body":{"unitId":"201000","beginTime":"2025-03-01","endTime":"2025-03-31"}}
```

**返回结果（HTTP 502）：**
```json
{"raw":""}
```

---

### 收费站维度交易额 - 支付方式 - 齐嫩分公司(206000)
**请求路由：** `/gssfApi2/v1/api/trade/stationPayTypeTurnover`

**请求参数：**
```json
{"body":{"unitId":"206000","beginTime":"2025-03-01","endTime":"2025-03-31"}}
```

**返回结果（HTTP -1）：**
```json
{"raw":"REQUEST_ERROR: HTTPConnectionPool(host='127.0.0.1', port=10808): Max retries exceeded with url: http://116.182.4.67:8088/gssfApi2/v1/api/trade/stationPayTypeTurnover (Caused by ProxyError('Unable to connect to proxy', ConnectionResetError(10054, '远程主机强迫关闭了一个现有的连接。', None, 10054, None)))"}
```

---

### 收费站维度交易额 - 计费车型 - 齐嫩分公司(206000)
**请求路由：** `/gssfApi2/v1/api/trade/stationVehTypeTurnover`

**请求参数：**
```json
{"body":{"unitId":"206000","beginTime":"2025-03-01","endTime":"2025-03-31"}}
```

**返回结果（HTTP 200）：**
```json
{"code":1,"msg":"按计费车型获取收费站维度交易额请求成功","success":true,"data":{"vehTypeTurnoverList":[{"unitId":"G0010230020010","unitName":"齐齐哈尔站","turnover":7549935,"carTurnover":3890611,"truckTurnover":3632773,"specialTurnover":26551,"turnoverD":7549934.89,"carTurnoverD":3890610.53,"truckTurnoverD":3632773.23,"specialTurnoverD":26551.13},{"unitId":"G0010230010070","unitName":"建华站","turnover":6413181,"carTurnover":2495151,"truckTurnover":3904799,"specialTurnover":13231,"turnoverD":6413180.96,"carTurnoverD":2495151.31,"truckTurnoverD":3904798.53,"specialTurnoverD":13231.12},{"unitId":"G0010230010060","unitName":"卜奎站","turnover":3834424,"carTurnover":2862931,"truckTurnover":962988,"specialTurnover":8505,"turnoverD":3834424.43,"carTurnoverD":2862930.99,"truckTurnoverD":962988.02,"specialTurnoverD":8505.42},{"unitId":"G4512230030010","unitName":"水师营站","turnover":3754414,"carTurnover":1753342,"truckTurnover":1982959,"specialTurnover":18113,"turnoverD":3754414.23,"carTurnoverD":1753342.29,"truckTurnoverD":1982959.12,"specialTurnoverD":18112.82},{"unitId":"G4512230010010","unitName":"嫩江站","turnover":3494555,"carTurnover":2398398,"truckTurnover":1073310,"specialTurnover":22847,"turnoverD":3494554.68,"carTurnoverD":2398397.97,"truckTurnoverD":1073309.92,"specialTurnoverD":22846.79},{"unitId":"G4512230030050","unitName":"塔子城站","turnover":3369152,"carTurnover":397922,"truckTurnover":2965023,"specialTurnover":6207,"turnoverD":3369151.53,"carTurnoverD":397921.71,"truckTurnoverD":2965022.65,"specialTurnoverD":6207.17},{"unitId":"G0010230010030","unitName":"长山站","turnover":3158537,"carTurnover":626793,"truckTurnover":2528958,"specialTurnover":2785,"turnoverD":3158536.68,"carTurnoverD":626793.18,"truckTurnoverD":2528958.27,"specialTurnoverD":2785.23},{"unitId":"G0010230010050","unitName":"奈门沁站","turnover":2946940,"carTurnover":1294205,"truckTurnover":1644226,"specialTurnover":8508,"turnoverD":2946939.87,"carTurnoverD":1294205.41,"truckTurnoverD":1644226.09,"specialTurnoverD":8508.37},{"unitId":"G4512230010040","unitName":"讷河站","turnover":2803335,"carTurnover":2089271,"truckTurnover":700302,"specialTurnover":13762,"turnoverD":2803334.58,"carTurnoverD":2089270.56,"truckTurnoverD":700302.03,"specialTurnoverD":13761.99},{"unitId":"G0010230010040","unitName":"共和站","turnover":2580150,"carTurnover":1145461,"truckTurnover":1429274,"specialTurnover":5414,"turnoverD":2580149.51,"carTurnoverD":1145461.13,"truckTurnoverD":1429274.08,"specialTurnoverD":5414.3},{"unitId":"G0010230010020","unitName":"甘南站","turnover":2124175,"carTurnover":1007872,"truckTurnover":1109973,"specialTurnover":6330,"turnoverD":2124174.95,"carTurnoverD":1007871.69,"truckTurnoverD":1109973.35,"specialTurnoverD":6329.91},{"unitId":"G4512230030040","unitName":"江桥站","turnover":1764336,"carTurnover":907159,"truckTurnover":849862,"specialTurnover":7315,"turnoverD":1764335.69,"carTurnoverD":907158.55,"truckTurnoverD":849861.94,"specialTurnoverD":7315.2},{"unitId":"G4512230020020","unitName":"冯屯站","turnover":1715130,"carTurnover":597094,"truckTurnover":1109105,"specialTurnover":8931,"turnoverD":1715129.61,"carTurnoverD":597094.03,"truckTurnoverD":1109105.02,"specialTurnoverD":8930.56},{"unitId":"G4512230030060","unitName":"泰来站","turnover":1604912,"carTurnover":1178962,"truckTurnover":420993,"specialTurnover":4958,"turnoverD":1604911.96,"carTurnoverD":1178961.66,"truckTurnoverD":420992.79,"specialTurnoverD":4957.51},{"unitId":"G4512230030020","unitName":"昂昂溪站","turnover":1472906,"carTurnover":271225,"truckTurnover":1199267,"specialTurnover":2414,"turnoverD":1472906.14,"carTurnoverD":271224.86,"truckTurnoverD":1199267.03,"specialTurnoverD":2414.25},{"unitId":"G4512230020010","unitName":"富裕站","turnover":1377783,"carTurnover":989752,"truckTurnover":378402,"specialTurnover":9628,"turnoverD":1377782.65,"carTurnoverD":989752.02,"truckTurnoverD":378402.21,"specialTurnoverD":9628.42},{"unitId":"G4512230030030","unitName":"齐齐哈尔大兴站","turnover":1100121,"carTurnover":464688,"truckTurnover":630316,"specialTurnover":5117,"turnoverD":1100121.42,"carTurnoverD":464688.44,"truckTurnoverD":630315.98,"specialTurnoverD":5117.0},{"unitId":"S0012230010040","unitName":"依安站","turnover":1063749,"carTurnover":808429,"truckTurnover":252550,"specialTurnover":2769,"turnoverD":1063749.12,"carTurnoverD":808429.45,"truckTurnoverD":252550.33,"specialTurnoverD":2769.34},{"unitId":"G4512230010020","unitName":"农垦九三站","turnover":666292,"carTurnover":535718,"truckTurnover":129767,"specialTurnover":807,"turnoverD":666292.08,"carTurnoverD":535718.31,"truckTurnoverD":129767.01,"specialTurnoverD":806.76},{"unitId":"G4512230010050","unitName":"拉哈站","turnover":638440,"carTurnover":432135,"truckTurnover":203653,"specialTurnover":2653,"turnoverD":638440.18,"carTurnoverD":432134.7,"truckTurnoverD":203652.55,"specialTurnoverD":2652.93},{"unitId":"G4512230010030","unitName":"老莱站","turnover":280558,"carTurnover":92552,"truckTurnover":187278,"specialTurnover":728,"turnoverD":280558.24,"carTurnoverD":92552.27,"truckTurnoverD":187278.44,"specialTurnoverD":727.53},{"unitId":"S0012230010050","unitName":"富海站","turnover":160070,"carTurnover":87581,"truckTurnover":71697,"specialTurnover":792,"turnoverD":160070.34,"carTurnoverD":87581.14,"truckTurnoverD":71697.21,"specialTurnoverD":791.99}],"totalTurnover":53873094,"carTotalTurnover":26327252,"truckTotalTurnover":27367476,"specialTotalTurnover":178366}}
```

---

### 收费站维度交易额 - 支付方式 - 哈伊分公司(208000)
**请求路由：** `/gssfApi2/v1/api/trade/stationPayTypeTurnover`

**请求参数：**
```json
{"body":{"unitId":"208000","beginTime":"2025-03-01","endTime":"2025-03-31"}}
```

**返回结果（HTTP 200）：**
```json
{"code":1,"msg":"按支付方式获取收费站维度交易额请求成功","success":true,"data":{"payTypeTurnoverList":[{"unitId":"G1111230030010","unitName":"绥化站","turnover":6758496,"etcTurnover":4050985,"cashTurnover":159805,"mobileTurnover":2547706,"turnoverD":6758496.37,"etcTurnoverD":4050985.43,"cashTurnoverD":159805.0,"mobileTurnoverD":2547705.94},{"unitId":"G1111230030050","unitName":"赵家站","turnover":4965070,"etcTurnover":3183040,"cashTurnover":168362,"mobileTurnover":1613668,"turnoverD":4965069.68,"etcTurnoverD":3183040.02,"cashTurnoverD":168362.0,"mobileTurnoverD":1613667.66},{"unitId":"G1111230010010","unitName":"伊春站","turnover":4702740,"etcTurnover":2568804,"cashTurnover":259517,"mobileTurnover":1874418,"turnoverD":4702739.54,"etcTurnoverD":2568804.25,"cashTurnoverD":259517.0,"mobileTurnoverD":1874418.29},{"unitId":"S0015230020020","unitName":"海伦站","turnover":3493058,"etcTurnover":1819746,"cashTurnover":225022,"mobileTurnover":1448291,"turnoverD":3493058.19,"etcTurnoverD":1819745.53,"cashTurnoverD":225022.0,"mobileTurnoverD":1448290.66},{"unitId":"G1111230020010","unitName":"庆安站","turnover":3277329,"etcTurnover":1979700,"cashTurnover":141274,"mobileTurnover":1156355,"turnoverD":3277329.31,"etcTurnoverD":1979700.11,"cashTurnoverD":141274.0,"mobileTurnoverD":1156355.2},{"unitId":"G1111230010040","unitName":"铁力站","turnover":2874451,"etcTurnover":1536191,"cashTurnover":176457,"mobileTurnover":1161803,"turnoverD":2874450.53,"etcTurnoverD":1536190.65,"cashTurnoverD":176457.0,"mobileTurnoverD":1161802.88},{"unitId":"G1111230020020","unitName":"东富站","turnover":2570591,"etcTurnover":1660907,"cashTurnover":106273,"mobileTurnover":803411,"turnoverD":2570590.78,"etcTurnoverD":1660906.9,"cashTurnoverD":106273.0,"mobileTurnoverD":803410.88},{"unitId":"G1111230030020","unitName":"兴隆站","turnover":2120513,"etcTurnover":1332663,"cashTurnover":88145,"mobileTurnover":699705,"turnoverD":2120513.48,"etcTurnoverD":1332663.1,"cashTurnoverD":88145.0,"mobileTurnoverD":699705.38},{"unitId":"S0015230020050","unitName":"绥西站","turnover":1866959,"etcTurnover":1017799,"cashTurnover":64724,"mobileTurnover":784436,"turnoverD":1866959.09,"etcTurnoverD":1017799.19,"cashTurnoverD":64724.0,"mobileTurnoverD":784435.9},{"unitId":"G1111230030040","unitName":"呼兰站","turnover":1849300,"etcTurnover":1123021,"cashTurnover":65188,"mobileTurnover":661091,"turnoverD":1849300.15,"etcTurnoverD":1123020.94,"cashTurnoverD":65188.0,"mobileTurnoverD":661091.21},{"unitId":"S0015230020030","unitName":"绥棱站","turnover":1669509,"etcTurnover":823988,"cashTurnover":42708,"mobileTurnover":802813,"turnoverD":1669508.99,"etcTurnoverD":823988.37,"cashTurnoverD":42708.0,"mobileTurnoverD":802812.62},{"unitId":"G1111230010050","unitName":"双丰站","turnover":1528582,"etcTurnover":954527,"cashTurnover":92024,"mobileTurnover":482031,"turnoverD":1528581.69,"etcTurnoverD":954526.73,"cashTurnoverD":92024.0,"mobileTurnoverD":482030.96},{"unitId":"G1111230010020","unitName":"翠峦站","turnover":1343418,"etcTurnover":869149,"cashTurnover":57722,"mobileTurnover":416547,"turnoverD":1343418.06,"etcTurnoverD":869148.78,"cashTurnoverD":57722.0,"mobileTurnoverD":416547.28},{"unitId":"S0015230020040","unitName":"望奎站","turnover":624477,"etcTurnover":292927,"cashTurnover":7373,"mobileTurnover":324177,"turnoverD":624477.16,"etcTurnoverD":292926.89,"cashTurnoverD":7373.0,"mobileTurnoverD":324177.27},{"unitId":"G1111230030030","unitName":"康金站","turnover":607229,"etcTurnover":320432,"cashTurnover":36367,"mobileTurnover":250431,"turnoverD":607229.44,"etcTurnoverD":320431.8,"cashTurnoverD":36367.0,"mobileTurnoverD":250430.64},{"unitId":"S0015230020010","unitName":"海北站","turnover":358527,"etcTurnover":220574,"cashTurnover":21036,"mobileTurnover":116917,"turnoverD":358527.1,"etcTurnoverD":220574.45,"cashTurnoverD":21036.0,"mobileTurnoverD":116916.65},{"unitId":"G1111230010030","unitName":"二股站","turnover":279035,"etcTurnover":169704,"cashTurnover":12248,"mobileTurnover":97083,"turnoverD":279035.42,"etcTurnoverD":169704.03,"cashTurnoverD":12248.0,"mobileTurnoverD":97083.39}],"totalTurnover":40889285,"etcTotalTurnover":23924157,"cashTotalTurnover":1724245,"mobileTotalTurnover":15240883}}
```

---

### 收费站维度交易额 - 计费车型 - 哈伊分公司(208000)
**请求路由：** `/gssfApi2/v1/api/trade/stationVehTypeTurnover`

**请求参数：**
```json
{"body":{"unitId":"208000","beginTime":"2025-03-01","endTime":"2025-03-31"}}
```

**返回结果（HTTP 200）：**
```json
{"code":1,"msg":"按计费车型获取收费站维度交易额请求成功","success":true,"data":{"vehTypeTurnoverList":[{"unitId":"G1111230030010","unitName":"绥化站","turnover":6758496,"carTurnover":4045454,"truckTurnover":2688739,"specialTurnover":24304,"turnoverD":6758496.37,"carTurnoverD":4045453.83,"truckTurnoverD":2688739.01,"specialTurnoverD":24303.53},{"unitId":"G1111230030050","unitName":"赵家站","turnover":4965070,"carTurnover":2690627,"truckTurnover":2260130,"specialTurnover":14312,"turnoverD":4965069.68,"carTurnoverD":2690627.04,"truckTurnoverD":2260130.21,"specialTurnoverD":14312.43},{"unitId":"G1111230010010","unitName":"伊春站","turnover":4702740,"carTurnover":2928271,"truckTurnover":1759010,"specialTurnover":15458,"turnoverD":4702739.54,"carTurnoverD":2928271.03,"truckTurnoverD":1759010.32,"specialTurnoverD":15458.19},{"unitId":"S0015230020020","unitName":"海伦站","turnover":3493058,"carTurnover":2626646,"truckTurnover":857460,"specialTurnover":8953,"turnoverD":3493058.19,"carTurnoverD":2626645.53,"truckTurnoverD":857459.63,"specialTurnoverD":8953.03},{"unitId":"G1111230020010","unitName":"庆安站","turnover":3277329,"carTurnover":2078330,"truckTurnover":1172508,"specialTurnover":26491,"turnoverD":3277329.31,"carTurnoverD":2078329.81,"truckTurnoverD":1172508.47,"specialTurnoverD":26491.03},{"unitId":"G1111230010040","unitName":"铁力站","turnover":2874451,"carTurnover":1895100,"truckTurnover":969382,"specialTurnover":9969,"turnoverD":2874450.53,"carTurnoverD":1895100.01,"truckTurnoverD":969381.75,"specialTurnoverD":9968.77},{"unitId":"G1111230020020","unitName":"东富站","turnover":2570591,"carTurnover":1068616,"truckTurnover":1496316,"specialTurnover":5658,"turnoverD":2570590.78,"carTurnoverD":1068616.26,"truckTurnoverD":1496316.4,"specialTurnoverD":5658.12},{"unitId":"G1111230030020","unitName":"兴隆站","turnover":2120513,"carTurnover":1016450,"truckTurnover":1099144,"specialTurnover":4919,"turnoverD":2120513.48,"carTurnoverD":1016450.35,"truckTurnoverD":1099144.2,"specialTurnoverD":4918.93},{"unitId":"S0015230020050","unitName":"绥西站","turnover":1866959,"carTurnover":1197304,"truckTurnover":664350,"specialTurnover":5305,"turnoverD":1866959.09,"carTurnoverD":1197304.21,"truckTurnoverD":664350.17,"specialTurnoverD":5304.71},{"unitId":"G1111230030040","unitName":"呼兰站","turnover":1849300,"carTurnover":755192,"truckTurnover":1086479,"specialTurnover":7630,"turnoverD":1849300.15,"carTurnoverD":755191.54,"truckTurnoverD":1086478.7,"specialTurnoverD":7629.91},{"unitId":"S0015230020030","unitName":"绥棱站","turnover":1669509,"carTurnover":1210803,"truckTurnover":453584,"specialTurnover":5122,"turnoverD":1669508.99,"carTurnoverD":1210802.76,"truckTurnoverD":453583.81,"specialTurnoverD":5122.42},{"unitId":"G1111230010050","unitName":"双丰站","turnover":1528582,"carTurnover":644432,"truckTurnover":876848,"specialTurnover":7301,"turnoverD":1528581.69,"carTurnoverD":644432.28,"truckTurnoverD":876848.18,"specialTurnoverD":7301.23},{"unitId":"G1111230010020","unitName":"翠峦站","turnover":1343418,"carTurnover":736789,"truckTurnover":604225,"specialTurnover":2404,"turnoverD":1343418.06,"carTurnoverD":736789.17,"truckTurnoverD":604225.0,"specialTurnoverD":2403.89},{"unitId":"S0015230020040","unitName":"望奎站","turnover":624477,"carTurnover":415304,"truckTurnover":206645,"specialTurnover":2527,"turnoverD":624477.16,"carTurnoverD":415304.49,"truckTurnoverD":206645.2,"specialTurnoverD":2527.47},{"unitId":"G1111230030030","unitName":"康金站","turnover":607229,"carTurnover":338608,"truckTurnover":265323,"specialTurnover":3299,"turnoverD":607229.44,"carTurnoverD":338608.13,"truckTurnoverD":265322.63,"specialTurnoverD":3298.68},{"unitId":"S0015230020010","unitName":"海北站","turnover":358527,"carTurnover":148815,"truckTurnover":206897,"specialTurnover":2814,"turnoverD":358527.1,"carTurnoverD":148815.36,"truckTurnoverD":206897.27,"specialTurnoverD":2814.47},{"unitId":"G1111230010030","unitName":"二股站","turnover":279035,"carTurnover":105182,"truckTurnover":173412,"specialTurnover":441,"turnoverD":279035.42,"carTurnoverD":105182.47,"truckTurnoverD":173412.16,"specialTurnoverD":440.79}],"totalTurnover":40889285,"carTotalTurnover":23901924,"truckTotalTurnover":16840453,"specialTotalTurnover":146908}}
```

---

### 收费站维度交易额 - 支付方式 - 哈大分公司(209000)
**请求路由：** `/gssfApi2/v1/api/trade/stationPayTypeTurnover`

**请求参数：**
```json
{"body":{"unitId":"209000","beginTime":"2025-03-01","endTime":"2025-03-31"}}
```

**返回结果（HTTP -1）：**
```json
{"raw":"REQUEST_ERROR: HTTPConnectionPool(host='127.0.0.1', port=10808): Max retries exceeded with url: http://116.182.4.67:8088/gssfApi2/v1/api/trade/stationPayTypeTurnover (Caused by ProxyError('Unable to connect to proxy', ConnectionResetError(10054, '远程主机强迫关闭了一个现有的连接。', None, 10054, None)))"}
```

---

### 收费站维度交易额 - 计费车型 - 哈大分公司(209000)
**请求路由：** `/gssfApi2/v1/api/trade/stationVehTypeTurnover`

**请求参数：**
```json
{"body":{"unitId":"209000","beginTime":"2025-03-01","endTime":"2025-03-31"}}
```

**返回结果（HTTP 502）：**
```json
{"raw":""}
```

---

### 收费站维度交易额 - 支付方式 - 北黑分公司(207000)
**请求路由：** `/gssfApi2/v1/api/trade/stationPayTypeTurnover`

**请求参数：**
```json
{"body":{"unitId":"207000","beginTime":"2025-03-01","endTime":"2025-03-31"}}
```

**返回结果（HTTP 200）：**
```json
{"code":1,"msg":"按支付方式获取收费站维度交易额请求成功","success":true,"data":{"payTypeTurnoverList":[{"unitId":"G1211230010010","unitName":"黑河站","turnover":5720854,"etcTurnover":3853569,"cashTurnover":160696,"mobileTurnover":1706589,"turnoverD":5720853.59,"etcTurnoverD":3853568.94,"cashTurnoverD":160696.0,"mobileTurnoverD":1706588.65},{"unitId":"G1211230010040","unitName":"孙吴站","turnover":3036852,"etcTurnover":1711247,"cashTurnover":30301,"mobileTurnover":1295304,"turnoverD":3036852.23,"etcTurnoverD":1711247.22,"cashTurnoverD":30301.0,"mobileTurnoverD":1295304.01},{"unitId":"S0015230010010","unitName":"北安北站","turnover":2531823,"etcTurnover":1447455,"cashTurnover":144566,"mobileTurnover":939802,"turnoverD":2531823.13,"etcTurnoverD":1447454.94,"cashTurnoverD":144566.0,"mobileTurnoverD":939802.19},{"unitId":"S0015230010020","unitName":"北安东站","turnover":2349015,"etcTurnover":1201312,"cashTurnover":148189,"mobileTurnover":999513,"turnoverD":2349014.87,"etcTurnoverD":1201312.39,"cashTurnoverD":148189.0,"mobileTurnoverD":999513.48},{"unitId":"G1213230010020","unitName":"五大连池站","turnover":1428025,"etcTurnover":729066,"cashTurnover":96300,"mobileTurnover":602658,"turnoverD":1428024.55,"etcTurnoverD":729066.39,"cashTurnoverD":96300.0,"mobileTurnoverD":602658.16},{"unitId":"S0012230010010","unitName":"宝泉站","turnover":1323758,"etcTurnover":814209,"cashTurnover":43495,"mobileTurnover":466055,"turnoverD":1323758.38,"etcTurnoverD":814208.87,"cashTurnoverD":43495.0,"mobileTurnoverD":466054.51},{"unitId":"S0015230010040","unitName":"通北站","turnover":1268338,"etcTurnover":692923,"cashTurnover":94390,"mobileTurnover":481025,"turnoverD":1268338.09,"etcTurnoverD":692922.62,"cashTurnoverD":94390.0,"mobileTurnoverD":481025.47},{"unitId":"G1213230010010","unitName":"五大连池风景区站","turnover":992625,"etcTurnover":454252,"cashTurnover":75823,"mobileTurnover":462550,"turnoverD":992624.67,"etcTurnoverD":454251.75,"cashTurnoverD":75823.0,"mobileTurnoverD":462549.92},{"unitId":"G1211230010070","unitName":"沾河站","turnover":908959,"etcTurnover":468937,"cashTurnover":64062,"mobileTurnover":375960,"turnoverD":908958.88,"etcTurnoverD":468936.91,"cashTurnoverD":64062.0,"mobileTurnoverD":375959.97},{"unitId":"S0015230010030","unitName":"赵光站","turnover":849533,"etcTurnover":539851,"cashTurnover":13312,"mobileTurnover":296369,"turnoverD":849532.52,"etcTurnoverD":539851.35,"cashTurnoverD":13312.0,"mobileTurnoverD":296369.17},{"unitId":"S0012230010020","unitName":"克山站","turnover":822075,"etcTurnover":363304,"cashTurnover":66244,"mobileTurnover":392527,"turnoverD":822074.83,"etcTurnoverD":363303.9,"cashTurnoverD":66244.0,"mobileTurnoverD":392526.93},{"unitId":"G1211230010080","unitName":"龙镇站","turnover":692758,"etcTurnover":475662,"cashTurnover":29078,"mobileTurnover":188018,"turnoverD":692758.23,"etcTurnoverD":475661.97,"cashTurnoverD":29078.0,"mobileTurnoverD":188018.26},{"unitId":"G1211230010030","unitName":"西岗子站","turnover":587535,"etcTurnover":364179,"cashTurnover":19125,"mobileTurnover":204231,"turnoverD":587535.49,"etcTurnoverD":364179.24,"cashTurnoverD":19125.0,"mobileTurnoverD":204231.25},{"unitId":"G1211230010050","unitName":"辰清站","turnover":564883,"etcTurnover":325776,"cashTurnover":7015,"mobileTurnover":232091,"turnoverD":564882.53,"etcTurnoverD":325776.21,"cashTurnoverD":7015.0,"mobileTurnoverD":232091.32},{"unitId":"G1211230010060","unitName":"龙门站","turnover":233476,"etcTurnover":121320,"cashTurnover":5155,"mobileTurnover":107001,"turnoverD":233476.47,"etcTurnoverD":121320.46,"cashTurnoverD":5155.0,"mobileTurnoverD":107001.01},{"unitId":"S0011230010010","unitName":"红星站","turnover":211161,"etcTurnover":120720,"cashTurnover":8739,"mobileTurnover":81701,"turnoverD":211160.85,"etcTurnoverD":120720.39,"cashTurnoverD":8739.0,"mobileTurnoverD":81701.46},{"unitId":"G1211230010020","unitName":"爱辉站","turnover":154702,"etcTurnover":87258,"cashTurnover":6349,"mobileTurnover":61095,"turnoverD":154702.13,"etcTurnoverD":87258.43,"cashTurnoverD":6349.0,"mobileTurnoverD":61094.7},{"unitId":"S0012230010030","unitName":"古城站","turnover":88052,"etcTurnover":40703,"cashTurnover":7211,"mobileTurnover":40138,"turnoverD":88051.56,"etcTurnoverD":40702.76,"cashTurnoverD":7211.0,"mobileTurnoverD":40137.8},{"unitId":"S0011230010020","unitName":"前进站","turnover":73410,"etcTurnover":30344,"cashTurnover":7597,"mobileTurnover":35469,"turnoverD":73409.74,"etcTurnoverD":30343.68,"cashTurnoverD":7597.0,"mobileTurnoverD":35469.06},{"unitId":"S0011230010030","unitName":"建兴站","turnover":54516,"etcTurnover":20869,"cashTurnover":2417,"mobileTurnover":31230,"turnoverD":54516.38,"etcTurnoverD":20869.38,"cashTurnoverD":2417.0,"mobileTurnoverD":31230.0}],"totalTurnover":23892349,"etcTotalTurnover":13862958,"cashTotalTurnover":1030064,"mobileTotalTurnover":8999327}}
```

---

### 收费站维度交易额 - 计费车型 - 北黑分公司(207000)
**请求路由：** `/gssfApi2/v1/api/trade/stationVehTypeTurnover`

**请求参数：**
```json
{"body":{"unitId":"207000","beginTime":"2025-03-01","endTime":"2025-03-31"}}
```

**返回结果（HTTP 502）：**
```json
{"raw":""}
```

---

### 收费站维度交易额 - 支付方式 - 监控分公司(142000)
**请求路由：** `/gssfApi2/v1/api/trade/stationPayTypeTurnover`

**请求参数：**
```json
{"body":{"unitId":"142000","beginTime":"2025-03-01","endTime":"2025-03-31"}}
```

**返回结果（HTTP 502）：**
```json
{"raw":""}
```

---

### 收费站维度交易额 - 计费车型 - 监控分公司(142000)
**请求路由：** `/gssfApi2/v1/api/trade/stationVehTypeTurnover`

**请求参数：**
```json
{"body":{"unitId":"142000","beginTime":"2025-03-01","endTime":"2025-03-31"}}
```

**返回结果（HTTP 200）：**
```json
{"code":1,"msg":"按计费车型获取收费站维度交易额请求成功","success":true,"data":{"vehTypeTurnoverList":[{"unitId":"S0022230010010","unitName":"中源大道收费站","turnover":4198261,"carTurnover":3298254,"truckTurnover":891024,"specialTurnover":8984,"turnoverD":4198261.16,"carTurnoverD":3298253.78,"truckTurnoverD":891023.71,"specialTurnoverD":8983.67},{"unitId":"S0022230010060","unitName":"肇州收费站","turnover":1767591,"carTurnover":801304,"truckTurnover":962631,"specialTurnover":3656,"turnoverD":1767590.89,"carTurnoverD":801304.12,"truckTurnoverD":962630.99,"specialTurnoverD":3655.78},{"unitId":"S0022230010050","unitName":"丰乐收费站","turnover":1210876,"carTurnover":700300,"truckTurnover":508831,"specialTurnover":1745,"turnoverD":1210876.28,"carTurnoverD":700300.12,"truckTurnoverD":508831.35,"specialTurnoverD":1744.81},{"unitId":"S0022230010030","unitName":"五里明收费站","turnover":917072,"carTurnover":698224,"truckTurnover":213312,"specialTurnover":5536,"turnoverD":917071.77,"carTurnoverD":698223.54,"truckTurnoverD":213312.24,"specialTurnoverD":5535.99},{"unitId":"S0022230010040","unitName":"朝阳沟收费站","turnover":492390,"carTurnover":373464,"truckTurnover":115603,"specialTurnover":3323,"turnoverD":492389.88,"carTurnoverD":373464.16,"truckTurnoverD":115602.92,"specialTurnoverD":3322.8}],"totalTurnover":8586190,"carTotalTurnover":5871546,"truckTotalTurnover":2691401,"specialTotalTurnover":23243}}
```

---

### 收费站维度交易额 - 支付方式 - 大齐分公司(205000)
**请求路由：** `/gssfApi2/v1/api/trade/stationPayTypeTurnover`

**请求参数：**
```json
{"body":{"unitId":"205000","beginTime":"2025-03-01","endTime":"2025-03-31"}}
```

**返回结果（HTTP 200）：**
```json
{"code":1,"msg":"按支付方式获取收费站维度交易额请求成功","success":true,"data":{"payTypeTurnoverList":[{"unitId":"G0010230020030","unitName":"林甸站","turnover":3403087,"etcTurnover":2017263,"cashTurnover":18681,"mobileTurnover":1367143,"turnoverD":3403087.19,"etcTurnoverD":2017262.79,"cashTurnoverD":18681.0,"mobileTurnoverD":1367143.4},{"unitId":"G0010230020060","unitName":"机场路站","turnover":2788306,"etcTurnover":1447228,"cashTurnover":84495,"mobileTurnover":1256583,"turnoverD":2788306.36,"etcTurnoverD":1447227.92,"cashTurnoverD":84495.0,"mobileTurnoverD":1256583.44},{"unitId":"G0010230020050","unitName":"庆北站","turnover":1680073,"etcTurnover":938369,"cashTurnover":80183,"mobileTurnover":661521,"turnoverD":1680073.37,"etcTurnoverD":938369.45,"cashTurnoverD":80183.0,"mobileTurnoverD":661520.92},{"unitId":"G0010230020070","unitName":"城北站","turnover":1161605,"etcTurnover":605105,"cashTurnover":51810,"mobileTurnover":504690,"turnoverD":1161604.61,"etcTurnoverD":605104.91,"cashTurnoverD":51810.0,"mobileTurnoverD":504689.7},{"unitId":"G0010230020020","unitName":"鹤鸣湖站","turnover":644380,"etcTurnover":375699,"cashTurnover":33826,"mobileTurnover":234855,"turnoverD":644380.17,"etcTurnoverD":375699.35,"cashTurnoverD":33826.0,"mobileTurnoverD":234854.82},{"unitId":"G0010230020040","unitName":"花园站","turnover":431100,"etcTurnover":230721,"cashTurnover":21459,"mobileTurnover":178920,"turnoverD":431100.13,"etcTurnoverD":230721.42,"cashTurnoverD":21459.0,"mobileTurnoverD":178919.71},{"unitId":"G0010230020080","unitName":"庆东站","turnover":66,"etcTurnover":66,"cashTurnover":0,"mobileTurnover":0,"turnoverD":66.21,"etcTurnoverD":66.21,"cashTurnoverD":0.0,"mobileTurnoverD":0.0}],"totalTurnover":10108618,"etcTotalTurnover":5614452,"cashTotalTurnover":290454,"mobileTotalTurnover":4203712}}
```

---

### 收费站维度交易额 - 计费车型 - 大齐分公司(205000)
**请求路由：** `/gssfApi2/v1/api/trade/stationVehTypeTurnover`

**请求参数：**
```json
{"body":{"unitId":"205000","beginTime":"2025-03-01","endTime":"2025-03-31"}}
```

**返回结果（HTTP -1）：**
```json
{"raw":"REQUEST_ERROR: HTTPConnectionPool(host='127.0.0.1', port=10808): Max retries exceeded with url: http://116.182.4.67:8088/gssfApi2/v1/api/trade/stationVehTypeTurnover (Caused by ProxyError('Unable to connect to proxy', ConnectionResetError(10054, '远程主机强迫关闭了一个现有的连接。', None, 10054, None)))"}
```

---

### 收费站维度交易额 - 支付方式 - 绥庆分公司(230113)
**请求路由：** `/gssfApi2/v1/api/trade/stationPayTypeTurnover`

**请求参数：**
```json
{"body":{"unitId":"230113","beginTime":"2025-03-01","endTime":"2025-03-31"}}
```

**返回结果（HTTP 200）：**
```json
{"code":1,"msg":"按支付方式获取收费站维度交易额请求成功","success":true,"data":{"payTypeTurnoverList":[{"unitId":"S0018230010010","unitName":"绥化北收费站","turnover":1777246,"etcTurnover":997091,"cashTurnover":13236,"mobileTurnover":766919,"turnoverD":1777245.95,"etcTurnoverD":997091.0,"cashTurnoverD":13236.0,"mobileTurnoverD":766918.95},{"unitId":"S0018230010030","unitName":"望奎南收费站","turnover":1635034,"etcTurnover":707647,"cashTurnover":1755,"mobileTurnover":925632,"turnoverD":1635034.13,"etcTurnoverD":707646.92,"cashTurnoverD":1755.0,"mobileTurnoverD":925632.21},{"unitId":"S0018230010090","unitName":"红岗东收费站","turnover":1329005,"etcTurnover":855005,"cashTurnover":803,"mobileTurnover":473198,"turnoverD":1329005.38,"etcTurnoverD":855004.75,"cashTurnoverD":803.0,"mobileTurnoverD":473197.63},{"unitId":"S0018230010050","unitName":"青冈收费站","turnover":1218554,"etcTurnover":567968,"cashTurnover":11722,"mobileTurnover":638863,"turnoverD":1218553.54,"etcTurnoverD":567968.29,"cashTurnoverD":11722.0,"mobileTurnoverD":638863.25},{"unitId":"S0018230010040","unitName":"民政收费站","turnover":535101,"etcTurnover":256395,"cashTurnover":3545,"mobileTurnover":275161,"turnoverD":535100.52,"etcTurnoverD":256394.82,"cashTurnoverD":3545.0,"mobileTurnoverD":275160.7},{"unitId":"S0018230010080","unitName":"万宝山收费站","turnover":372858,"etcTurnover":262372,"cashTurnover":0,"mobileTurnover":110485,"turnoverD":372857.64,"etcTurnoverD":262372.34,"cashTurnoverD":0.0,"mobileTurnoverD":110485.3},{"unitId":"S0018230010070","unitName":"火石山收费站","turnover":275508,"etcTurnover":100435,"cashTurnover":491,"mobileTurnover":174583,"turnoverD":275508.12,"etcTurnoverD":100434.62,"cashTurnoverD":491.0,"mobileTurnoverD":174582.5},{"unitId":"S0018230010060","unitName":"燎原收费站","turnover":275507,"etcTurnover":169807,"cashTurnover":1131,"mobileTurnover":104569,"turnoverD":275506.53,"etcTurnoverD":169806.62,"cashTurnoverD":1131.0,"mobileTurnoverD":104568.91},{"unitId":"S0018230010020","unitName":"卫星收费站","turnover":182908,"etcTurnover":85707,"cashTurnover":93,"mobileTurnover":97108,"turnoverD":182908.07,"etcTurnoverD":85707.48,"cashTurnoverD":93.0,"mobileTurnoverD":97107.59}],"totalTurnover":7601720,"etcTotalTurnover":4002427,"cashTotalTurnover":32776,"mobileTotalTurnover":3566517}}
```

---

### 收费站维度交易额 - 计费车型 - 绥庆分公司(230113)
**请求路由：** `/gssfApi2/v1/api/trade/stationVehTypeTurnover`

**请求参数：**
```json
{"body":{"unitId":"230113","beginTime":"2025-03-01","endTime":"2025-03-31"}}
```

**返回结果（HTTP 502）：**
```json
{"raw":""}
```

---

### 集团实时车流量
**请求路由：** `/gssfApi2/v1/api/traffic/realTimeTrafficFlow`

**请求参数：**
```json
{}
```

**返回结果（HTTP 200）：**
```json
{"code":1,"msg":"请求成功","success":true,"data":{"todayTrafficFlow":230514,"todayETCTrafficFlow":109811,"todayCashTrafficFlow":10140,"todayMobileTrafficFlow":110563,"todayFreeTrafficFlow":1465,"monthTrafficFlow":3924373,"yearTrafficFlow":51538856}}
```

---

### 分公司维度车流量 - 支付方式
**请求路由：** `/gssfApi2/v1/api/traffic/companyPayTypeTrafficFlow`

**请求参数：**
```json
{"body":{"beginTime":"2025-03-01","endTime":"2025-03-31"}}
```

**返回结果（HTTP 200）：**
```json
{"code":1,"msg":"按支付方式获取分公司维度车流量请求成功","success":true,"data":{"payTypeTrafficFlowList":[{"unitId":"204000","unitName":"哈同分公司","trafficFlow":949842,"etcTrafficFlow":517133,"cashTrafficFlow":56500,"mobileTrafficFlow":376209,"freeTrafficFlow":8994},{"unitId":"202000","unitName":"哈绥分公司","trafficFlow":846339,"etcTrafficFlow":478237,"cashTrafficFlow":40230,"mobileTrafficFlow":327872,"freeTrafficFlow":7227},{"unitId":"201000","unitName":"哈尔滨分公司","trafficFlow":821555,"etcTrafficFlow":464592,"cashTrafficFlow":28175,"mobileTrafficFlow":328788,"freeTrafficFlow":13249},{"unitId":"203000","unitName":"鹤大分公司","trafficFlow":772560,"etcTrafficFlow":438013,"cashTrafficFlow":41964,"mobileTrafficFlow":292583,"freeTrafficFlow":6225},{"unitId":"206000","unitName":"齐嫩分公司","trafficFlow":756124,"etcTrafficFlow":343609,"cashTrafficFlow":59648,"mobileTrafficFlow":352867,"freeTrafficFlow":9200},{"unitId":"208000","unitName":"哈伊分公司","trafficFlow":616994,"etcTrafficFlow":309806,"cashTrafficFlow":43129,"mobileTrafficFlow":264059,"freeTrafficFlow":7029},{"unitId":"209000","unitName":"哈大分公司","trafficFlow":540013,"etcTrafficFlow":256867,"cashTrafficFlow":3550,"mobileTrafficFlow":279596,"freeTrafficFlow":2651},{"unitId":"207000","unitName":"北黑分公司","trafficFlow":313367,"etcTrafficFlow":151424,"cashTrafficFlow":25529,"mobileTrafficFlow":136414,"freeTrafficFlow":4177},{"unitId":"205000","unitName":"大齐分公司","trafficFlow":195217,"etcTrafficFlow":89588,"cashTrafficFlow":9813,"mobileTrafficFlow":95816,"freeTrafficFlow":2015},{"unitId":"142000","unitName":"监控分公司","trafficFlow":151445,"etcTrafficFlow":72280,"cashTrafficFlow":1155,"mobileTrafficFlow":78010,"freeTrafficFlow":769},{"unitId":"230113","unitName":"绥庆分公司","trafficFlow":117224,"etcTrafficFlow":49907,"cashTrafficFlow":1707,"mobileTrafficFlow":65610,"freeTrafficFlow":1442}],"trafficTotalFlow":6080680,"etcTrafficTotalFlow":3171456,"cashTrafficTotalFlow":311400,"mobileTrafficTotalFlow":2597824,"freeTrafficTotalFlow":62978}}
```

---

### 分公司维度车流量 - 计费车型
**请求路由：** `/gssfApi2/v1/api/traffic/companyVehTypeTrafficFlow`

**请求参数：**
```json
{"body":{"beginTime":"2025-03-01","endTime":"2025-03-31"}}
```

**返回结果（HTTP -1）：**
```json
{"raw":"REQUEST_ERROR: HTTPConnectionPool(host='127.0.0.1', port=10808): Max retries exceeded with url: http://116.182.4.67:8088/gssfApi2/v1/api/traffic/companyVehTypeTrafficFlow (Caused by ProxyError('Unable to connect to proxy', ConnectionResetError(10054, '远程主机强迫关闭了一个现有的连接。', None, 10054, None)))"}
```

---

### 收费站维度交通流 - 支付方式 - 哈绥分公司(202000)
**请求路由：** `/gssfApi2/v1/api/traffic/stationPayTypeTrafficFlow`

**请求参数：**
```json
{"body":{"unitId":"202000","beginTime":"2025-03-01","endTime":"2025-03-31"}}
```

**返回结果（HTTP 200）：**
```json
{"code":1,"msg":"按支付方式获取收费站维度交通流请求成功","success":true,"data":{"payTypeTrafficFlowList":[{"unitId":"G0010230040010","unitName":"哈尔滨站","trafficFlow":239414,"etcTrafficFlow":140850,"cashTrafficFlow":2610,"mobileTrafficFlow":95954,"freeTrafficFlow":798},{"unitId":"G0010230040020","unitName":"阿城站","trafficFlow":168701,"etcTrafficFlow":103341,"cashTrafficFlow":1199,"mobileTrafficFlow":64161,"freeTrafficFlow":739},{"unitId":"G0010230050030","unitName":"牡丹江站","trafficFlow":50107,"etcTrafficFlow":27645,"cashTrafficFlow":3541,"mobileTrafficFlow":18921,"freeTrafficFlow":309},{"unitId":"G0010230060040","unitName":"下城子站","trafficFlow":42902,"etcTrafficFlow":23467,"cashTrafficFlow":1976,"mobileTrafficFlow":17459,"freeTrafficFlow":226},{"unitId":"G0010230050020","unitName":"海林站","trafficFlow":38250,"etcTrafficFlow":21295,"cashTrafficFlow":2842,"mobileTrafficFlow":14113,"freeTrafficFlow":213},{"unitId":"G0010230040110","unitName":"尚志站","trafficFlow":37719,"etcTrafficFlow":19441,"cashTrafficFlow":2953,"mobileTrafficFlow":15325,"freeTrafficFlow":746},{"unitId":"G0010230060070","unitName":"绥芬河站","trafficFlow":36040,"etcTrafficFlow":19302,"cashTrafficFlow":3894,"mobileTrafficFlow":12844,"freeTrafficFlow":2312},{"unitId":"G0010230060010","unitName":"磨刀石站","trafficFlow":31374,"etcTrafficFlow":17086,"cashTrafficFlow":3535,"mobileTrafficFlow":10753,"freeTrafficFlow":65},{"unitId":"G0010230040100","unitName":"乌吉密站","trafficFlow":25158,"etcTrafficFlow":12523,"cashTrafficFlow":1743,"mobileTrafficFlow":10892,"freeTrafficFlow":490},{"unitId":"G0010230040040","unitName":"亚沟站","trafficFlow":22398,"etcTrafficFlow":12786,"cashTrafficFlow":1478,"mobileTrafficFlow":8134,"freeTrafficFlow":465},{"unitId":"G0010230040140","unitName":"亚布力站","trafficFlow":18169,"etcTrafficFlow":8558,"cashTrafficFlow":1367,"mobileTrafficFlow":8244,"freeTrafficFlow":78},{"unitId":"G0010230040130","unitName":"苇河站","trafficFlow":17639,"etcTrafficFlow":9250,"cashTrafficFlow":1721,"mobileTrafficFlow":6668,"freeTrafficFlow":137},{"unitId":"G0010230040070","unitName":"小岭站","trafficFlow":16468,"etcTrafficFlow":9239,"cashTrafficFlow":1323,"mobileTrafficFlow":5906,"freeTrafficFlow":125},{"unitId":"G0010230060030","unitName":"兴源站","trafficFlow":16330,"etcTrafficFlow":8515,"cashTrafficFlow":2159,"mobileTrafficFlow":5656,"freeTrafficFlow":45},{"unitId":"G0010230060020","unitName":"穆棱站","trafficFlow":16204,"etcTrafficFlow":8704,"cashTrafficFlow":1942,"mobileTrafficFlow":5558,"freeTrafficFlow":20},{"unitId":"G0010230060060","unitName":"绥阳站","trafficFlow":11286,"etcTrafficFlow":5563,"cashTrafficFlow":1105,"mobileTrafficFlow":4618,"freeTrafficFlow":168},{"unitId":"G0010230040060","unitName":"玉泉站","trafficFlow":11023,"etcTrafficFlow":7539,"cashTrafficFlow":817,"mobileTrafficFlow":2667,"freeTrafficFlow":28},{"unitId":"G0010230040120","unitName":"一面坡站","trafficFlow":10998,"etcTrafficFlow":5939,"cashTrafficFlow":1053,"mobileTrafficFlow":4006,"freeTrafficFlow":70},{"unitId":"G0010230040090","unitName":"帽儿山站","trafficFlow":10257,"etcTrafficFlow":4975,"cashTrafficFlow":675,"mobileTrafficFlow":4607,"freeTrafficFlow":46},{"unitId":"G0010230060050","unitName":"永安站","trafficFlow":8339,"etcTrafficFlow":3940,"cashTrafficFlow":933,"mobileTrafficFlow":3466,"freeTrafficFlow":29},{"unitId":"G0010230050010","unitName":"横道站","trafficFlow":7633,"etcTrafficFlow":3627,"cashTrafficFlow":559,"mobileTrafficFlow":3447,"freeTrafficFlow":46},{"unitId":"G0010230040150","unitName":"明新站","trafficFlow":5061,"etcTrafficFlow":2327,"cashTrafficFlow":523,"mobileTrafficFlow":2211,"freeTrafficFlow":45},{"unitId":"G0010230040080","unitName":"平山站","trafficFlow":3797,"etcTrafficFlow":1667,"cashTrafficFlow":250,"mobileTrafficFlow":1880,"freeTrafficFlow":21},{"unitId":"G0010230040050","unitName":"动物园站","trafficFlow":1072,"etcTrafficFlow":658,"cashTrafficFlow":32,"mobileTrafficFlow":382,"freeTrafficFlow":6}],"trafficTotalFlow":846339,"etcTrafficTotalFlow":478237,"cashTrafficTotalFlow":40230,"mobileTrafficTotalFlow":327872,"freeTrafficTotalFlow":7227}}
```

---

### 收费站维度交通流 - 计费车型 - 哈绥分公司(202000)
**请求路由：** `/gssfApi2/v1/api/traffic/stationVehTypeTrafficFlow`

**请求参数：**
```json
{"body":{"unitId":"202000","beginTime":"2025-03-01","endTime":"2025-03-31"}}
```

**返回结果（HTTP 200）：**
```json
{"code":1,"msg":"按计费车型获取收费站维度交通流请求成功","success":true,"data":{"vehTypeTrafficFlowList":[{"unitId":"G0010230040010","unitName":"哈尔滨站","trafficFlow":239414,"carTrafficFlow":211420,"truckTrafficFlow":24787,"specialTrafficFlow":2409,"freeTrafficFlow":798},{"unitId":"G0010230040020","unitName":"阿城站","trafficFlow":168701,"carTrafficFlow":154509,"truckTrafficFlow":13288,"specialTrafficFlow":165,"freeTrafficFlow":739},{"unitId":"G0010230050030","unitName":"牡丹江站","trafficFlow":50107,"carTrafficFlow":39728,"truckTrafficFlow":9958,"specialTrafficFlow":112,"freeTrafficFlow":309},{"unitId":"G0010230060040","unitName":"下城子站","trafficFlow":42902,"carTrafficFlow":29810,"truckTrafficFlow":12747,"specialTrafficFlow":119,"freeTrafficFlow":226},{"unitId":"G0010230050020","unitName":"海林站","trafficFlow":38250,"carTrafficFlow":30476,"truckTrafficFlow":7484,"specialTrafficFlow":77,"freeTrafficFlow":213},{"unitId":"G0010230040110","unitName":"尚志站","trafficFlow":37719,"carTrafficFlow":30002,"truckTrafficFlow":6835,"specialTrafficFlow":136,"freeTrafficFlow":746},{"unitId":"G0010230060070","unitName":"绥芬河站","trafficFlow":36040,"carTrafficFlow":21123,"truckTrafficFlow":12496,"specialTrafficFlow":109,"freeTrafficFlow":2312},{"unitId":"G0010230060010","unitName":"磨刀石站","trafficFlow":31374,"carTrafficFlow":21294,"truckTrafficFlow":9933,"specialTrafficFlow":82,"freeTrafficFlow":65},{"unitId":"G0010230040100","unitName":"乌吉密站","trafficFlow":25158,"carTrafficFlow":19762,"truckTrafficFlow":4817,"specialTrafficFlow":89,"freeTrafficFlow":490},{"unitId":"G0010230040040","unitName":"亚沟站","trafficFlow":22398,"carTrafficFlow":13481,"truckTrafficFlow":8209,"specialTrafficFlow":243,"freeTrafficFlow":465},{"unitId":"G0010230040140","unitName":"亚布力站","trafficFlow":18169,"carTrafficFlow":14708,"truckTrafficFlow":3342,"specialTrafficFlow":41,"freeTrafficFlow":78},{"unitId":"G0010230040130","unitName":"苇河站","trafficFlow":17639,"carTrafficFlow":13454,"truckTrafficFlow":3992,"specialTrafficFlow":56,"freeTrafficFlow":137},{"unitId":"G0010230040070","unitName":"小岭站","trafficFlow":16468,"carTrafficFlow":12577,"truckTrafficFlow":3675,"specialTrafficFlow":91,"freeTrafficFlow":125},{"unitId":"G0010230060030","unitName":"兴源站","trafficFlow":16330,"carTrafficFlow":12141,"truckTrafficFlow":4094,"specialTrafficFlow":50,"freeTrafficFlow":45},{"unitId":"G0010230060020","unitName":"穆棱站","trafficFlow":16204,"carTrafficFlow":13142,"truckTrafficFlow":3006,"specialTrafficFlow":36,"freeTrafficFlow":20},{"unitId":"G0010230060060","unitName":"绥阳站","trafficFlow":11286,"carTrafficFlow":7590,"truckTrafficFlow":3474,"specialTrafficFlow":54,"freeTrafficFlow":168},{"unitId":"G0010230040060","unitName":"玉泉站","trafficFlow":11023,"carTrafficFlow":5821,"truckTrafficFlow":2700,"specialTrafficFlow":2474,"freeTrafficFlow":28},{"unitId":"G0010230040120","unitName":"一面坡站","trafficFlow":10998,"carTrafficFlow":7827,"truckTrafficFlow":3060,"specialTrafficFlow":41,"freeTrafficFlow":70},{"unitId":"G0010230040090","unitName":"帽儿山站","trafficFlow":10257,"carTrafficFlow":8585,"truckTrafficFlow":1595,"specialTrafficFlow":31,"freeTrafficFlow":46},{"unitId":"G0010230060050","unitName":"永安站","trafficFlow":8339,"carTrafficFlow":5843,"truckTrafficFlow":2455,"specialTrafficFlow":12,"freeTrafficFlow":29},{"unitId":"G0010230050010","unitName":"横道站","trafficFlow":7633,"carTrafficFlow":6382,"truckTrafficFlow":1126,"specialTrafficFlow":79,"freeTrafficFlow":46},{"unitId":"G0010230040150","unitName":"明新站","trafficFlow":5061,"carTrafficFlow":3321,"truckTrafficFlow":1670,"specialTrafficFlow":25,"freeTrafficFlow":45},{"unitId":"G0010230040080","unitName":"平山站","trafficFlow":3797,"carTrafficFlow":3287,"truckTrafficFlow":479,"specialTrafficFlow":10,"freeTrafficFlow":21},{"unitId":"G0010230040050","unitName":"动物园站","trafficFlow":1072,"carTrafficFlow":949,"truckTrafficFlow":115,"specialTrafficFlow":2,"freeTrafficFlow":6}],"trafficTotalFlow":846339,"carTrafficTotalFlow":687232,"truckTrafficTotalFlow":145337,"specialTrafficTotalFlow":6543,"freeTrafficTotalFlow":null}}
```

---

### 收费站维度交通流 - 支付方式 - 哈同分公司(204000)
**请求路由：** `/gssfApi2/v1/api/traffic/stationPayTypeTrafficFlow`

**请求参数：**
```json
{"body":{"unitId":"204000","beginTime":"2025-03-01","endTime":"2025-03-31"}}
```

**返回结果（HTTP 200）：**
```json
{"code":1,"msg":"按支付方式获取收费站维度交通流请求成功","success":true,"data":{"payTypeTrafficFlowList":[{"unitId":"G1011230040080","unitName":"哈尔滨东站","trafficFlow":130211,"etcTrafficFlow":69346,"cashTrafficFlow":5898,"mobileTrafficFlow":54967,"freeTrafficFlow":547},{"unitId":"G0011230010010","unitName":"万兴站","trafficFlow":96289,"etcTrafficFlow":50788,"cashTrafficFlow":4719,"mobileTrafficFlow":40782,"freeTrafficFlow":481},{"unitId":"G1011230020030","unitName":"佳南站","trafficFlow":73538,"etcTrafficFlow":40159,"cashTrafficFlow":5463,"mobileTrafficFlow":27916,"freeTrafficFlow":159},{"unitId":"G1011230010070","unitName":"双鸭山站","trafficFlow":70732,"etcTrafficFlow":40906,"cashTrafficFlow":3469,"mobileTrafficFlow":26357,"freeTrafficFlow":267},{"unitId":"G1011230010020","unitName":"二龙山站","trafficFlow":70452,"etcTrafficFlow":38967,"cashTrafficFlow":3726,"mobileTrafficFlow":27759,"freeTrafficFlow":331},{"unitId":"G1011230040060","unitName":"宾州站","trafficFlow":60516,"etcTrafficFlow":31721,"cashTrafficFlow":2691,"mobileTrafficFlow":26104,"freeTrafficFlow":1027},{"unitId":"G1011230020010","unitName":"集贤站","trafficFlow":55104,"etcTrafficFlow":29313,"cashTrafficFlow":3179,"mobileTrafficFlow":22612,"freeTrafficFlow":881},{"unitId":"G1011230010030","unitName":"富锦东站","trafficFlow":54850,"etcTrafficFlow":31018,"cashTrafficFlow":2570,"mobileTrafficFlow":21262,"freeTrafficFlow":189},{"unitId":"G1011230010040","unitName":"富锦站","trafficFlow":45447,"etcTrafficFlow":24756,"cashTrafficFlow":3420,"mobileTrafficFlow":17271,"freeTrafficFlow":477},{"unitId":"G1011230040070","unitName":"宾西站","trafficFlow":45185,"etcTrafficFlow":23740,"cashTrafficFlow":1764,"mobileTrafficFlow":19681,"freeTrafficFlow":461},{"unitId":"G1011230010060","unitName":"二九一站","trafficFlow":38228,"etcTrafficFlow":27093,"cashTrafficFlow":2219,"mobileTrafficFlow":8916,"freeTrafficFlow":24},{"unitId":"G1011230030030","unitName":"依兰站","trafficFlow":32500,"etcTrafficFlow":15610,"cashTrafficFlow":2713,"mobileTrafficFlow":14177,"freeTrafficFlow":652},{"unitId":"G1011230040020","unitName":"方通站","trafficFlow":26413,"etcTrafficFlow":15316,"cashTrafficFlow":1460,"mobileTrafficFlow":9637,"freeTrafficFlow":198},{"unitId":"G1011230030050","unitName":"高楞站","trafficFlow":24198,"etcTrafficFlow":13551,"cashTrafficFlow":2252,"mobileTrafficFlow":8395,"freeTrafficFlow":145},{"unitId":"G1011230030010","unitName":"佳西站","trafficFlow":19204,"etcTrafficFlow":9773,"cashTrafficFlow":2645,"mobileTrafficFlow":6786,"freeTrafficFlow":2045},{"unitId":"G1011230010010","unitName":"同江站","trafficFlow":18129,"etcTrafficFlow":9598,"cashTrafficFlow":401,"mobileTrafficFlow":8130,"freeTrafficFlow":152},{"unitId":"G1011230040050","unitName":"常安站","trafficFlow":16388,"etcTrafficFlow":8063,"cashTrafficFlow":1434,"mobileTrafficFlow":6891,"freeTrafficFlow":95},{"unitId":"G1011230040010","unitName":"方正站","trafficFlow":16386,"etcTrafficFlow":7558,"cashTrafficFlow":2074,"mobileTrafficFlow":6754,"freeTrafficFlow":359},{"unitId":"G1011230040040","unitName":"摆渡站","trafficFlow":16174,"etcTrafficFlow":7772,"cashTrafficFlow":1232,"mobileTrafficFlow":7170,"freeTrafficFlow":99},{"unitId":"G1011230010050","unitName":"锦山站","trafficFlow":12837,"etcTrafficFlow":7703,"cashTrafficFlow":1177,"mobileTrafficFlow":3957,"freeTrafficFlow":55},{"unitId":"G1011230040030","unitName":"会发站","trafficFlow":10369,"etcTrafficFlow":6266,"cashTrafficFlow":575,"mobileTrafficFlow":3528,"freeTrafficFlow":49},{"unitId":"G1011230030040","unitName":"达连河站","trafficFlow":7913,"etcTrafficFlow":4281,"cashTrafficFlow":613,"mobileTrafficFlow":3019,"freeTrafficFlow":91},{"unitId":"G1011230030020","unitName":"宏克力站","trafficFlow":4934,"etcTrafficFlow":2206,"cashTrafficFlow":531,"mobileTrafficFlow":2197,"freeTrafficFlow":165},{"unitId":"G1012230010020","unitName":"浓桥站","trafficFlow":3469,"etcTrafficFlow":1503,"cashTrafficFlow":263,"mobileTrafficFlow":1703,"freeTrafficFlow":41},{"unitId":"G1012230010010","unitName":"黑瞎子岛站","trafficFlow":376,"etcTrafficFlow":126,"cashTrafficFlow":12,"mobileTrafficFlow":238,"freeTrafficFlow":4}],"trafficTotalFlow":949842,"etcTrafficTotalFlow":517133,"cashTrafficTotalFlow":56500,"mobileTrafficTotalFlow":376209,"freeTrafficTotalFlow":8994}}
```

---

### 收费站维度交通流 - 计费车型 - 哈同分公司(204000)
**请求路由：** `/gssfApi2/v1/api/traffic/stationVehTypeTrafficFlow`

**请求参数：**
```json
{"body":{"unitId":"204000","beginTime":"2025-03-01","endTime":"2025-03-31"}}
```

**返回结果（HTTP 200）：**
```json
{"code":1,"msg":"按计费车型获取收费站维度交通流请求成功","success":true,"data":{"vehTypeTrafficFlowList":[{"unitId":"G1011230040080","unitName":"哈尔滨东站","trafficFlow":130211,"carTrafficFlow":90710,"truckTrafficFlow":38643,"specialTrafficFlow":311,"freeTrafficFlow":547},{"unitId":"G0011230010010","unitName":"万兴站","trafficFlow":96289,"carTrafficFlow":74688,"truckTrafficFlow":20809,"specialTrafficFlow":311,"freeTrafficFlow":481},{"unitId":"G1011230020030","unitName":"佳南站","trafficFlow":73538,"carTrafficFlow":54197,"truckTrafficFlow":18983,"specialTrafficFlow":199,"freeTrafficFlow":159},{"unitId":"G1011230010070","unitName":"双鸭山站","trafficFlow":70732,"carTrafficFlow":58693,"truckTrafficFlow":11575,"specialTrafficFlow":197,"freeTrafficFlow":267},{"unitId":"G1011230010020","unitName":"二龙山站","trafficFlow":70452,"carTrafficFlow":50586,"truckTrafficFlow":19274,"specialTrafficFlow":261,"freeTrafficFlow":331},{"unitId":"G1011230040060","unitName":"宾州站","trafficFlow":60516,"carTrafficFlow":51424,"truckTrafficFlow":7902,"specialTrafficFlow":163,"freeTrafficFlow":1027},{"unitId":"G1011230020010","unitName":"集贤站","trafficFlow":55104,"carTrafficFlow":41408,"truckTrafficFlow":12716,"specialTrafficFlow":99,"freeTrafficFlow":881},{"unitId":"G1011230010030","unitName":"富锦东站","trafficFlow":54850,"carTrafficFlow":38592,"truckTrafficFlow":15921,"specialTrafficFlow":148,"freeTrafficFlow":189},{"unitId":"G1011230010040","unitName":"富锦站","trafficFlow":45447,"carTrafficFlow":35215,"truckTrafficFlow":9508,"specialTrafficFlow":247,"freeTrafficFlow":477},{"unitId":"G1011230040070","unitName":"宾西站","trafficFlow":45185,"carTrafficFlow":33673,"truckTrafficFlow":10924,"specialTrafficFlow":127,"freeTrafficFlow":461},{"unitId":"G1011230010060","unitName":"二九一站","trafficFlow":38228,"carTrafficFlow":32046,"truckTrafficFlow":6105,"specialTrafficFlow":53,"freeTrafficFlow":24},{"unitId":"G1011230030030","unitName":"依兰站","trafficFlow":32500,"carTrafficFlow":22134,"truckTrafficFlow":9580,"specialTrafficFlow":134,"freeTrafficFlow":652},{"unitId":"G1011230040020","unitName":"方通站","trafficFlow":26413,"carTrafficFlow":14099,"truckTrafficFlow":12024,"specialTrafficFlow":92,"freeTrafficFlow":198},{"unitId":"G1011230030050","unitName":"高楞站","trafficFlow":24198,"carTrafficFlow":12914,"truckTrafficFlow":10984,"specialTrafficFlow":155,"freeTrafficFlow":145},{"unitId":"G1011230030010","unitName":"佳西站","trafficFlow":19204,"carTrafficFlow":9400,"truckTrafficFlow":7604,"specialTrafficFlow":155,"freeTrafficFlow":2045},{"unitId":"G1011230010010","unitName":"同江站","trafficFlow":18129,"carTrafficFlow":13603,"truckTrafficFlow":4275,"specialTrafficFlow":99,"freeTrafficFlow":152},{"unitId":"G1011230040050","unitName":"常安站","trafficFlow":16388,"carTrafficFlow":10934,"truckTrafficFlow":5300,"specialTrafficFlow":59,"freeTrafficFlow":95},{"unitId":"G1011230040010","unitName":"方正站","trafficFlow":16386,"carTrafficFlow":11978,"truckTrafficFlow":3918,"specialTrafficFlow":131,"freeTrafficFlow":359},{"unitId":"G1011230040040","unitName":"摆渡站","trafficFlow":16174,"carTrafficFlow":10889,"truckTrafficFlow":5134,"specialTrafficFlow":52,"freeTrafficFlow":99},{"unitId":"G1011230010050","unitName":"锦山站","trafficFlow":12837,"carTrafficFlow":9911,"truckTrafficFlow":2824,"specialTrafficFlow":47,"freeTrafficFlow":55},{"unitId":"G1011230040030","unitName":"会发站","trafficFlow":10369,"carTrafficFlow":4654,"truckTrafficFlow":5619,"specialTrafficFlow":47,"freeTrafficFlow":49},{"unitId":"G1011230030040","unitName":"达连河站","trafficFlow":7913,"carTrafficFlow":4726,"truckTrafficFlow":3067,"specialTrafficFlow":29,"freeTrafficFlow":91},{"unitId":"G1011230030020","unitName":"宏克力站","trafficFlow":4934,"carTrafficFlow":3025,"truckTrafficFlow":1722,"specialTrafficFlow":22,"freeTrafficFlow":165},{"unitId":"G1012230010020","unitName":"浓桥站","trafficFlow":3469,"carTrafficFlow":2953,"truckTrafficFlow":472,"specialTrafficFlow":3,"freeTrafficFlow":41},{"unitId":"G1012230010010","unitName":"黑瞎子岛站","trafficFlow":376,"carTrafficFlow":233,"truckTrafficFlow":139,"specialTrafficFlow":0,"freeTrafficFlow":4}],"trafficTotalFlow":949842,"carTrafficTotalFlow":692685,"truckTrafficTotalFlow":245022,"specialTrafficTotalFlow":3141,"freeTrafficTotalFlow":null}}
```

---

### 收费站维度交通流 - 支付方式 - 鹤大分公司(203000)
**请求路由：** `/gssfApi2/v1/api/traffic/stationPayTypeTrafficFlow`

**请求参数：**
```json
{"body":{"unitId":"203000","beginTime":"2025-03-01","endTime":"2025-03-31"}}
```

**返回结果（HTTP 200）：**
```json
{"code":1,"msg":"按支付方式获取收费站维度交通流请求成功","success":true,"data":{"payTypeTrafficFlowList":[{"unitId":"G0011230030010","unitName":"牡丹江南站","trafficFlow":108482,"etcTrafficFlow":71394,"cashTrafficFlow":5206,"mobileTrafficFlow":31882,"freeTrafficFlow":1354},{"unitId":"G0011230040010","unitName":"鹤岗站","trafficFlow":93410,"etcTrafficFlow":53036,"cashTrafficFlow":2837,"mobileTrafficFlow":37537,"freeTrafficFlow":602},{"unitId":"G0011230040030","unitName":"江口站","trafficFlow":91444,"etcTrafficFlow":54170,"cashTrafficFlow":2609,"mobileTrafficFlow":34665,"freeTrafficFlow":127},{"unitId":"G0011230030030","unitName":"宁安站","trafficFlow":87735,"etcTrafficFlow":57491,"cashTrafficFlow":4114,"mobileTrafficFlow":26130,"freeTrafficFlow":857},{"unitId":"G0011230020010","unitName":"桦南站","trafficFlow":55502,"etcTrafficFlow":28514,"cashTrafficFlow":1757,"mobileTrafficFlow":25231,"freeTrafficFlow":381},{"unitId":"G0011230020080","unitName":"铁岭河站","trafficFlow":49513,"etcTrafficFlow":23183,"cashTrafficFlow":4503,"mobileTrafficFlow":21827,"freeTrafficFlow":1338},{"unitId":"G0011230030040","unitName":"东京城站","trafficFlow":39181,"etcTrafficFlow":22399,"cashTrafficFlow":2858,"mobileTrafficFlow":13924,"freeTrafficFlow":393},{"unitId":"G0011230040020","unitName":"鹤立站","trafficFlow":39114,"etcTrafficFlow":25181,"cashTrafficFlow":667,"mobileTrafficFlow":13266,"freeTrafficFlow":49},{"unitId":"G0011230020050","unitName":"林口站","trafficFlow":36779,"etcTrafficFlow":16656,"cashTrafficFlow":4051,"mobileTrafficFlow":16072,"freeTrafficFlow":326},{"unitId":"G0011230020070","unitName":"柴河站","trafficFlow":21769,"etcTrafficFlow":10016,"cashTrafficFlow":1274,"mobileTrafficFlow":10479,"freeTrafficFlow":42},{"unitId":"G0011230030020","unitName":"温春站","trafficFlow":21649,"etcTrafficFlow":14544,"cashTrafficFlow":382,"mobileTrafficFlow":6723,"freeTrafficFlow":95},{"unitId":"G0011230020020","unitName":"西长发站","trafficFlow":20662,"etcTrafficFlow":9659,"cashTrafficFlow":1324,"mobileTrafficFlow":9679,"freeTrafficFlow":99},{"unitId":"S0016230010010","unitName":"密山站","trafficFlow":20397,"etcTrafficFlow":8608,"cashTrafficFlow":2366,"mobileTrafficFlow":9423,"freeTrafficFlow":195},{"unitId":"G0011230020030","unitName":"兴农站","trafficFlow":15736,"etcTrafficFlow":7215,"cashTrafficFlow":3179,"mobileTrafficFlow":5342,"freeTrafficFlow":99},{"unitId":"G0011230020040","unitName":"麻山站","trafficFlow":14782,"etcTrafficFlow":7200,"cashTrafficFlow":1810,"mobileTrafficFlow":5772,"freeTrafficFlow":74},{"unitId":"G0011230010030","unitName":"曙光站","trafficFlow":14629,"etcTrafficFlow":7863,"cashTrafficFlow":331,"mobileTrafficFlow":6435,"freeTrafficFlow":22},{"unitId":"G0011230010020","unitName":"明义站","trafficFlow":11846,"etcTrafficFlow":5775,"cashTrafficFlow":173,"mobileTrafficFlow":5898,"freeTrafficFlow":13},{"unitId":"G0011230020060","unitName":"柳树站","trafficFlow":11084,"etcTrafficFlow":4823,"cashTrafficFlow":955,"mobileTrafficFlow":5306,"freeTrafficFlow":37},{"unitId":"G0011230030050","unitName":"镜泊湖站","trafficFlow":7279,"etcTrafficFlow":4741,"cashTrafficFlow":336,"mobileTrafficFlow":2202,"freeTrafficFlow":72},{"unitId":"S0016230010020","unitName":"兴凯湖站","trafficFlow":6823,"etcTrafficFlow":2573,"cashTrafficFlow":964,"mobileTrafficFlow":3286,"freeTrafficFlow":30},{"unitId":"G0011230030060","unitName":"西湖岫站","trafficFlow":4744,"etcTrafficFlow":2972,"cashTrafficFlow":268,"mobileTrafficFlow":1504,"freeTrafficFlow":20}],"trafficTotalFlow":772560,"etcTrafficTotalFlow":438013,"cashTrafficTotalFlow":41964,"mobileTrafficTotalFlow":292583,"freeTrafficTotalFlow":6225}}
```

---

### 收费站维度交通流 - 计费车型 - 鹤大分公司(203000)
**请求路由：** `/gssfApi2/v1/api/traffic/stationVehTypeTrafficFlow`

**请求参数：**
```json
{"body":{"unitId":"203000","beginTime":"2025-03-01","endTime":"2025-03-31"}}
```

**返回结果（HTTP 502）：**
```json
{"raw":""}
```

---

### 收费站维度交通流 - 支付方式 - 哈尔滨分公司(201000)
**请求路由：** `/gssfApi2/v1/api/traffic/stationPayTypeTrafficFlow`

**请求参数：**
```json
{"body":{"unitId":"201000","beginTime":"2025-03-01","endTime":"2025-03-31"}}
```

**返回结果（HTTP 200）：**
```json
{"code":1,"msg":"按支付方式获取收费站维度交通流请求成功","success":true,"data":{"payTypeTrafficFlowList":[{"unitId":"G0001230010050","unitName":"瓦盆窑站","trafficFlow":173448,"etcTrafficFlow":95085,"cashTrafficFlow":8495,"mobileTrafficFlow":69868,"freeTrafficFlow":5807},{"unitId":"G1001230010020","unitName":"群力站","trafficFlow":160528,"etcTrafficFlow":84051,"cashTrafficFlow":6279,"mobileTrafficFlow":70198,"freeTrafficFlow":720},{"unitId":"G0001230010030","unitName":"双城站","trafficFlow":103579,"etcTrafficFlow":61703,"cashTrafficFlow":1604,"mobileTrafficFlow":40272,"freeTrafficFlow":1187},{"unitId":"G1001230020010","unitName":"哈肇站","trafficFlow":96210,"etcTrafficFlow":48674,"cashTrafficFlow":3293,"mobileTrafficFlow":44243,"freeTrafficFlow":341},{"unitId":"G1001230010010","unitName":"朝阳站","trafficFlow":84033,"etcTrafficFlow":53619,"cashTrafficFlow":2134,"mobileTrafficFlow":28280,"freeTrafficFlow":1092},{"unitId":"G1001230020030","unitName":"长江路站","trafficFlow":54527,"etcTrafficFlow":32473,"cashTrafficFlow":257,"mobileTrafficFlow":21797,"freeTrafficFlow":125},{"unitId":"G0001230010040","unitName":"新兴站","trafficFlow":49305,"etcTrafficFlow":35142,"cashTrafficFlow":3138,"mobileTrafficFlow":11025,"freeTrafficFlow":2777},{"unitId":"G1001230010030","unitName":"松北站","trafficFlow":42256,"etcTrafficFlow":23179,"cashTrafficFlow":2303,"mobileTrafficFlow":16774,"freeTrafficFlow":991},{"unitId":"G1001230020040","unitName":"成高子站","trafficFlow":33478,"etcTrafficFlow":19559,"cashTrafficFlow":361,"mobileTrafficFlow":13558,"freeTrafficFlow":107},{"unitId":"G1001230020020","unitName":"五星站","trafficFlow":24191,"etcTrafficFlow":11107,"cashTrafficFlow":311,"mobileTrafficFlow":12773,"freeTrafficFlow":102}],"trafficTotalFlow":821555,"etcTrafficTotalFlow":464592,"cashTrafficTotalFlow":28175,"mobileTrafficTotalFlow":328788,"freeTrafficTotalFlow":13249}}
```

---

### 收费站维度交通流 - 计费车型 - 哈尔滨分公司(201000)
**请求路由：** `/gssfApi2/v1/api/traffic/stationVehTypeTrafficFlow`

**请求参数：**
```json
{"body":{"unitId":"201000","beginTime":"2025-03-01","endTime":"2025-03-31"}}
```

**返回结果（HTTP 502）：**
```json
{"raw":""}
```

---

### 收费站维度交通流 - 支付方式 - 齐嫩分公司(206000)
**请求路由：** `/gssfApi2/v1/api/traffic/stationPayTypeTrafficFlow`

**请求参数：**
```json
{"body":{"unitId":"206000","beginTime":"2025-03-01","endTime":"2025-03-31"}}
```

**返回结果（HTTP 200）：**
```json
{"code":1,"msg":"按支付方式获取收费站维度交通流请求成功","success":true,"data":{"payTypeTrafficFlowList":[{"unitId":"G0010230020010","unitName":"齐齐哈尔站","trafficFlow":87747,"etcTrafficFlow":39332,"cashTrafficFlow":6482,"mobileTrafficFlow":41933,"freeTrafficFlow":939},{"unitId":"G0010230010070","unitName":"建华站","trafficFlow":74300,"etcTrafficFlow":37151,"cashTrafficFlow":7017,"mobileTrafficFlow":30132,"freeTrafficFlow":826},{"unitId":"G0010230010060","unitName":"卜奎站","trafficFlow":72667,"etcTrafficFlow":29435,"cashTrafficFlow":4473,"mobileTrafficFlow":38759,"freeTrafficFlow":988},{"unitId":"G0010230010040","unitName":"共和站","trafficFlow":51228,"etcTrafficFlow":23293,"cashTrafficFlow":4432,"mobileTrafficFlow":23503,"freeTrafficFlow":390},{"unitId":"G0010230010050","unitName":"奈门沁站","trafficFlow":49813,"etcTrafficFlow":24506,"cashTrafficFlow":4211,"mobileTrafficFlow":21096,"freeTrafficFlow":408},{"unitId":"G4512230030040","unitName":"江桥站","trafficFlow":43528,"etcTrafficFlow":17725,"cashTrafficFlow":2845,"mobileTrafficFlow":22958,"freeTrafficFlow":273},{"unitId":"G4512230030010","unitName":"水师营站","trafficFlow":42072,"etcTrafficFlow":17693,"cashTrafficFlow":3296,"mobileTrafficFlow":21083,"freeTrafficFlow":1731},{"unitId":"G4512230020020","unitName":"冯屯站","trafficFlow":36137,"etcTrafficFlow":16211,"cashTrafficFlow":4380,"mobileTrafficFlow":15546,"freeTrafficFlow":103},{"unitId":"G4512230010010","unitName":"嫩江站","trafficFlow":34593,"etcTrafficFlow":12875,"cashTrafficFlow":4815,"mobileTrafficFlow":16903,"freeTrafficFlow":609},{"unitId":"G0010230010030","unitName":"长山站","trafficFlow":33706,"etcTrafficFlow":19180,"cashTrafficFlow":1979,"mobileTrafficFlow":12547,"freeTrafficFlow":106},{"unitId":"G4512230010040","unitName":"讷河站","trafficFlow":31618,"etcTrafficFlow":12022,"cashTrafficFlow":3396,"mobileTrafficFlow":16200,"freeTrafficFlow":415},{"unitId":"G4512230030030","unitName":"齐齐哈尔大兴站","trafficFlow":30395,"etcTrafficFlow":12954,"cashTrafficFlow":3170,"mobileTrafficFlow":14271,"freeTrafficFlow":140},{"unitId":"G0010230010020","unitName":"甘南站","trafficFlow":29209,"etcTrafficFlow":12107,"cashTrafficFlow":2287,"mobileTrafficFlow":14815,"freeTrafficFlow":528},{"unitId":"G4512230030050","unitName":"塔子城站","trafficFlow":28274,"etcTrafficFlow":19904,"cashTrafficFlow":603,"mobileTrafficFlow":7767,"freeTrafficFlow":184},{"unitId":"G4512230030060","unitName":"泰来站","trafficFlow":27076,"etcTrafficFlow":10941,"cashTrafficFlow":2103,"mobileTrafficFlow":14032,"freeTrafficFlow":472},{"unitId":"G4512230020010","unitName":"富裕站","trafficFlow":24248,"etcTrafficFlow":11179,"cashTrafficFlow":635,"mobileTrafficFlow":12434,"freeTrafficFlow":361},{"unitId":"G4512230010020","unitName":"农垦九三站","trafficFlow":16081,"etcTrafficFlow":7046,"cashTrafficFlow":745,"mobileTrafficFlow":8290,"freeTrafficFlow":85},{"unitId":"S0012230010040","unitName":"依安站","trafficFlow":15795,"etcTrafficFlow":6147,"cashTrafficFlow":515,"mobileTrafficFlow":9133,"freeTrafficFlow":260},{"unitId":"G4512230030020","unitName":"昂昂溪站","trafficFlow":13094,"etcTrafficFlow":8059,"cashTrafficFlow":978,"mobileTrafficFlow":4057,"freeTrafficFlow":209},{"unitId":"G4512230010050","unitName":"拉哈站","trafficFlow":7383,"etcTrafficFlow":2781,"cashTrafficFlow":792,"mobileTrafficFlow":3810,"freeTrafficFlow":83},{"unitId":"G4512230010030","unitName":"老莱站","trafficFlow":3604,"etcTrafficFlow":1737,"cashTrafficFlow":405,"mobileTrafficFlow":1462,"freeTrafficFlow":16},{"unitId":"S0012230010050","unitName":"富海站","trafficFlow":3556,"etcTrafficFlow":1331,"cashTrafficFlow":89,"mobileTrafficFlow":2136,"freeTrafficFlow":74}],"trafficTotalFlow":756124,"etcTrafficTotalFlow":343609,"cashTrafficTotalFlow":59648,"mobileTrafficTotalFlow":352867,"freeTrafficTotalFlow":9200}}
```

---

### 收费站维度交通流 - 计费车型 - 齐嫩分公司(206000)
**请求路由：** `/gssfApi2/v1/api/traffic/stationVehTypeTrafficFlow`

**请求参数：**
```json
{"body":{"unitId":"206000","beginTime":"2025-03-01","endTime":"2025-03-31"}}
```

**返回结果（HTTP -1）：**
```json
{"raw":"REQUEST_ERROR: HTTPConnectionPool(host='127.0.0.1', port=10808): Max retries exceeded with url: http://116.182.4.67:8088/gssfApi2/v1/api/traffic/stationVehTypeTrafficFlow (Caused by ProxyError('Unable to connect to proxy', ConnectionResetError(10054, '远程主机强迫关闭了一个现有的连接。', None, 10054, None)))"}
```

---

### 收费站维度交通流 - 支付方式 - 哈伊分公司(208000)
**请求路由：** `/gssfApi2/v1/api/traffic/stationPayTypeTrafficFlow`

**请求参数：**
```json
{"body":{"unitId":"208000","beginTime":"2025-03-01","endTime":"2025-03-31"}}
```

**返回结果（HTTP 200）：**
```json
{"code":1,"msg":"按支付方式获取收费站维度交通流请求成功","success":true,"data":{"payTypeTrafficFlowList":[{"unitId":"G1111230030010","unitName":"绥化站","trafficFlow":95165,"etcTrafficFlow":50226,"cashTrafficFlow":3538,"mobileTrafficFlow":41401,"freeTrafficFlow":625},{"unitId":"G1111230020010","unitName":"庆安站","trafficFlow":76036,"etcTrafficFlow":41068,"cashTrafficFlow":5166,"mobileTrafficFlow":29802,"freeTrafficFlow":386},{"unitId":"G1111230030050","unitName":"赵家站","trafficFlow":75748,"etcTrafficFlow":40247,"cashTrafficFlow":4237,"mobileTrafficFlow":31264,"freeTrafficFlow":259},{"unitId":"G1111230020020","unitName":"东富站","trafficFlow":55798,"etcTrafficFlow":28815,"cashTrafficFlow":5647,"mobileTrafficFlow":21336,"freeTrafficFlow":2579},{"unitId":"S0015230020020","unitName":"海伦站","trafficFlow":41975,"etcTrafficFlow":19796,"cashTrafficFlow":3864,"mobileTrafficFlow":18315,"freeTrafficFlow":640},{"unitId":"G1111230010040","unitName":"铁力站","trafficFlow":41757,"etcTrafficFlow":20092,"cashTrafficFlow":3661,"mobileTrafficFlow":18004,"freeTrafficFlow":448},{"unitId":"G1111230030040","unitName":"呼兰站","trafficFlow":34791,"etcTrafficFlow":16553,"cashTrafficFlow":2557,"mobileTrafficFlow":15681,"freeTrafficFlow":417},{"unitId":"G1111230030020","unitName":"兴隆站","trafficFlow":34478,"etcTrafficFlow":17670,"cashTrafficFlow":2443,"mobileTrafficFlow":14365,"freeTrafficFlow":369},{"unitId":"G1111230010010","unitName":"伊春站","trafficFlow":33803,"etcTrafficFlow":15300,"cashTrafficFlow":3117,"mobileTrafficFlow":15386,"freeTrafficFlow":577},{"unitId":"S0015230020050","unitName":"绥西站","trafficFlow":32662,"etcTrafficFlow":15731,"cashTrafficFlow":1398,"mobileTrafficFlow":15533,"freeTrafficFlow":106},{"unitId":"G1111230010050","unitName":"双丰站","trafficFlow":28410,"etcTrafficFlow":13863,"cashTrafficFlow":3487,"mobileTrafficFlow":11060,"freeTrafficFlow":180},{"unitId":"S0015230020030","unitName":"绥棱站","trafficFlow":19736,"etcTrafficFlow":8859,"cashTrafficFlow":554,"mobileTrafficFlow":10323,"freeTrafficFlow":70},{"unitId":"G1111230030030","unitName":"康金站","trafficFlow":12890,"etcTrafficFlow":5355,"cashTrafficFlow":1254,"mobileTrafficFlow":6281,"freeTrafficFlow":215},{"unitId":"S0015230020040","unitName":"望奎站","trafficFlow":11461,"etcTrafficFlow":4747,"cashTrafficFlow":207,"mobileTrafficFlow":6507,"freeTrafficFlow":39},{"unitId":"G1111230010020","unitName":"翠峦站","trafficFlow":9719,"etcTrafficFlow":5112,"cashTrafficFlow":744,"mobileTrafficFlow":3863,"freeTrafficFlow":66},{"unitId":"S0015230020010","unitName":"海北站","trafficFlow":6716,"etcTrafficFlow":3427,"cashTrafficFlow":763,"mobileTrafficFlow":2526,"freeTrafficFlow":21},{"unitId":"G1111230010030","unitName":"二股站","trafficFlow":5849,"etcTrafficFlow":2945,"cashTrafficFlow":492,"mobileTrafficFlow":2412,"freeTrafficFlow":32}],"trafficTotalFlow":616994,"etcTrafficTotalFlow":309806,"cashTrafficTotalFlow":43129,"mobileTrafficTotalFlow":264059,"freeTrafficTotalFlow":7029}}
```

---

### 收费站维度交通流 - 计费车型 - 哈伊分公司(208000)
**请求路由：** `/gssfApi2/v1/api/traffic/stationVehTypeTrafficFlow`

**请求参数：**
```json
{"body":{"unitId":"208000","beginTime":"2025-03-01","endTime":"2025-03-31"}}
```

**返回结果（HTTP 200）：**
```json
{"code":1,"msg":"按计费车型获取收费站维度交通流请求成功","success":true,"data":{"vehTypeTrafficFlowList":[{"unitId":"G1111230030010","unitName":"绥化站","trafficFlow":95165,"carTrafficFlow":77072,"truckTrafficFlow":17218,"specialTrafficFlow":250,"freeTrafficFlow":625},{"unitId":"G1111230020010","unitName":"庆安站","trafficFlow":76036,"carTrafficFlow":57399,"truckTrafficFlow":17578,"specialTrafficFlow":673,"freeTrafficFlow":386},{"unitId":"G1111230030050","unitName":"赵家站","trafficFlow":75748,"carTrafficFlow":50230,"truckTrafficFlow":25003,"specialTrafficFlow":256,"freeTrafficFlow":259},{"unitId":"G1111230020020","unitName":"东富站","trafficFlow":55798,"carTrafficFlow":36747,"truckTrafficFlow":16276,"specialTrafficFlow":196,"freeTrafficFlow":2579},{"unitId":"S0015230020020","unitName":"海伦站","trafficFlow":41975,"carTrafficFlow":35027,"truckTrafficFlow":6193,"specialTrafficFlow":115,"freeTrafficFlow":640},{"unitId":"G1111230010040","unitName":"铁力站","trafficFlow":41757,"carTrafficFlow":32102,"truckTrafficFlow":9080,"specialTrafficFlow":127,"freeTrafficFlow":448},{"unitId":"G1111230030040","unitName":"呼兰站","trafficFlow":34791,"carTrafficFlow":21808,"truckTrafficFlow":12477,"specialTrafficFlow":89,"freeTrafficFlow":417},{"unitId":"G1111230030020","unitName":"兴隆站","trafficFlow":34478,"carTrafficFlow":25140,"truckTrafficFlow":8889,"specialTrafficFlow":80,"freeTrafficFlow":369},{"unitId":"G1111230010010","unitName":"伊春站","trafficFlow":33803,"carTrafficFlow":26448,"truckTrafficFlow":6682,"specialTrafficFlow":96,"freeTrafficFlow":577},{"unitId":"S0015230020050","unitName":"绥西站","trafficFlow":32662,"carTrafficFlow":26764,"truckTrafficFlow":5688,"specialTrafficFlow":104,"freeTrafficFlow":106},{"unitId":"G1111230010050","unitName":"双丰站","trafficFlow":28410,"carTrafficFlow":18341,"truckTrafficFlow":9749,"specialTrafficFlow":140,"freeTrafficFlow":180},{"unitId":"S0015230020030","unitName":"绥棱站","trafficFlow":19736,"carTrafficFlow":16572,"truckTrafficFlow":3044,"specialTrafficFlow":50,"freeTrafficFlow":70},{"unitId":"G1111230030030","unitName":"康金站","trafficFlow":12890,"carTrafficFlow":9882,"truckTrafficFlow":2742,"specialTrafficFlow":51,"freeTrafficFlow":215},{"unitId":"S0015230020040","unitName":"望奎站","trafficFlow":11461,"carTrafficFlow":9264,"truckTrafficFlow":2107,"specialTrafficFlow":51,"freeTrafficFlow":39},{"unitId":"G1111230010020","unitName":"翠峦站","trafficFlow":9719,"carTrafficFlow":7070,"truckTrafficFlow":2563,"specialTrafficFlow":20,"freeTrafficFlow":66},{"unitId":"S0015230020010","unitName":"海北站","trafficFlow":6716,"carTrafficFlow":4123,"truckTrafficFlow":2535,"specialTrafficFlow":37,"freeTrafficFlow":21},{"unitId":"G1111230010030","unitName":"二股站","trafficFlow":5849,"carTrafficFlow":3905,"truckTrafficFlow":1901,"specialTrafficFlow":11,"freeTrafficFlow":32}],"trafficTotalFlow":616994,"carTrafficTotalFlow":457894,"truckTrafficTotalFlow":149725,"specialTrafficTotalFlow":2346,"freeTrafficTotalFlow":null}}
```

---

### 收费站维度交通流 - 支付方式 - 哈大分公司(209000)
**请求路由：** `/gssfApi2/v1/api/traffic/stationPayTypeTrafficFlow`

**请求参数：**
```json
{"body":{"unitId":"209000","beginTime":"2025-03-01","endTime":"2025-03-31"}}
```

**返回结果（HTTP 200）：**
```json
{"code":1,"msg":"按支付方式获取收费站维度交通流请求成功","success":true,"data":{"payTypeTrafficFlowList":[{"unitId":"G0010230030050","unitName":"大耿家站","trafficFlow":212303,"etcTrafficFlow":102119,"cashTrafficFlow":1049,"mobileTrafficFlow":109135,"freeTrafficFlow":830},{"unitId":"G0010230030010","unitName":"卧里屯站","trafficFlow":125381,"etcTrafficFlow":58783,"cashTrafficFlow":639,"mobileTrafficFlow":65959,"freeTrafficFlow":344},{"unitId":"G0010230030040","unitName":"肇东站","trafficFlow":109829,"etcTrafficFlow":52660,"cashTrafficFlow":652,"mobileTrafficFlow":56517,"freeTrafficFlow":515},{"unitId":"G0010230030020","unitName":"安达站","trafficFlow":66176,"etcTrafficFlow":31120,"cashTrafficFlow":1096,"mobileTrafficFlow":33960,"freeTrafficFlow":904},{"unitId":"G0010230030030","unitName":"承平站","trafficFlow":26324,"etcTrafficFlow":12185,"cashTrafficFlow":114,"mobileTrafficFlow":14025,"freeTrafficFlow":58}],"trafficTotalFlow":540013,"etcTrafficTotalFlow":256867,"cashTrafficTotalFlow":3550,"mobileTrafficTotalFlow":279596,"freeTrafficTotalFlow":2651}}
```

---

### 收费站维度交通流 - 计费车型 - 哈大分公司(209000)
**请求路由：** `/gssfApi2/v1/api/traffic/stationVehTypeTrafficFlow`

**请求参数：**
```json
{"body":{"unitId":"209000","beginTime":"2025-03-01","endTime":"2025-03-31"}}
```

**返回结果（HTTP 502）：**
```json
{"raw":""}
```

---

### 收费站维度交通流 - 支付方式 - 北黑分公司(207000)
**请求路由：** `/gssfApi2/v1/api/traffic/stationPayTypeTrafficFlow`

**请求参数：**
```json
{"body":{"unitId":"207000","beginTime":"2025-03-01","endTime":"2025-03-31"}}
```

**返回结果（HTTP -1）：**
```json
{"raw":"REQUEST_ERROR: HTTPConnectionPool(host='127.0.0.1', port=10808): Max retries exceeded with url: http://116.182.4.67:8088/gssfApi2/v1/api/traffic/stationPayTypeTrafficFlow (Caused by ProxyError('Unable to connect to proxy', ConnectionResetError(10054, '远程主机强迫关闭了一个现有的连接。', None, 10054, None)))"}
```

---

### 收费站维度交通流 - 计费车型 - 北黑分公司(207000)
**请求路由：** `/gssfApi2/v1/api/traffic/stationVehTypeTrafficFlow`

**请求参数：**
```json
{"body":{"unitId":"207000","beginTime":"2025-03-01","endTime":"2025-03-31"}}
```

**返回结果（HTTP 200）：**
```json
{"code":1,"msg":"按计费车型获取收费站维度交通流请求成功","success":true,"data":{"vehTypeTrafficFlowList":[{"unitId":"S0015230010010","unitName":"北安北站","trafficFlow":47836,"carTrafficFlow":36920,"truckTrafficFlow":10250,"specialTrafficFlow":234,"freeTrafficFlow":432},{"unitId":"S0015230010020","unitName":"北安东站","trafficFlow":43029,"carTrafficFlow":36190,"truckTrafficFlow":6326,"specialTrafficFlow":53,"freeTrafficFlow":460},{"unitId":"G1211230010040","unitName":"孙吴站","trafficFlow":28892,"carTrafficFlow":20135,"truckTrafficFlow":8312,"specialTrafficFlow":127,"freeTrafficFlow":318},{"unitId":"S0015230010040","unitName":"通北站","trafficFlow":27913,"carTrafficFlow":21722,"truckTrafficFlow":5782,"specialTrafficFlow":135,"freeTrafficFlow":274},{"unitId":"G1211230010010","unitName":"黑河站","trafficFlow":27608,"carTrafficFlow":20107,"truckTrafficFlow":6275,"specialTrafficFlow":183,"freeTrafficFlow":1043},{"unitId":"G1213230010020","unitName":"五大连池站","trafficFlow":24793,"carTrafficFlow":21299,"truckTrafficFlow":3181,"specialTrafficFlow":49,"freeTrafficFlow":264},{"unitId":"S0015230010030","unitName":"赵光站","trafficFlow":22261,"carTrafficFlow":17398,"truckTrafficFlow":4659,"specialTrafficFlow":48,"freeTrafficFlow":156},{"unitId":"G1211230010070","unitName":"沾河站","trafficFlow":15284,"carTrafficFlow":11380,"truckTrafficFlow":3639,"specialTrafficFlow":64,"freeTrafficFlow":201},{"unitId":"S0012230010010","unitName":"宝泉站","trafficFlow":11431,"carTrafficFlow":6752,"truckTrafficFlow":4480,"specialTrafficFlow":52,"freeTrafficFlow":147},{"unitId":"G1211230010080","unitName":"龙镇站","trafficFlow":10970,"carTrafficFlow":7274,"truckTrafficFlow":3540,"specialTrafficFlow":35,"freeTrafficFlow":121},{"unitId":"S0012230010020","unitName":"克山站","trafficFlow":9972,"carTrafficFlow":8101,"truckTrafficFlow":1610,"specialTrafficFlow":52,"freeTrafficFlow":209},{"unitId":"G1213230010010","unitName":"五大连池风景区站","trafficFlow":9969,"carTrafficFlow":7348,"truckTrafficFlow":2405,"specialTrafficFlow":61,"freeTrafficFlow":155},{"unitId":"G1211230010050","unitName":"辰清站","trafficFlow":7838,"carTrafficFlow":4583,"truckTrafficFlow":3140,"specialTrafficFlow":40,"freeTrafficFlow":75},{"unitId":"G1211230010060","unitName":"龙门站","trafficFlow":7304,"carTrafficFlow":4926,"truckTrafficFlow":2282,"specialTrafficFlow":47,"freeTrafficFlow":49},{"unitId":"S0011230010010","unitName":"红星站","trafficFlow":6923,"carTrafficFlow":5134,"truckTrafficFlow":1751,"specialTrafficFlow":10,"freeTrafficFlow":28},{"unitId":"G1211230010030","unitName":"西岗子站","trafficFlow":5500,"carTrafficFlow":2730,"truckTrafficFlow":2671,"specialTrafficFlow":32,"freeTrafficFlow":67},{"unitId":"G1211230010020","unitName":"爱辉站","trafficFlow":2227,"carTrafficFlow":1639,"truckTrafficFlow":498,"specialTrafficFlow":18,"freeTrafficFlow":72},{"unitId":"S0011230010020","unitName":"前进站","trafficFlow":1391,"carTrafficFlow":952,"truckTrafficFlow":420,"specialTrafficFlow":16,"freeTrafficFlow":3},{"unitId":"S0012230010030","unitName":"古城站","trafficFlow":1384,"carTrafficFlow":929,"truckTrafficFlow":352,"specialTrafficFlow":6,"freeTrafficFlow":97},{"unitId":"S0011230010030","unitName":"建兴站","trafficFlow":842,"carTrafficFlow":587,"truckTrafficFlow":247,"specialTrafficFlow":2,"freeTrafficFlow":6}],"trafficTotalFlow":313367,"carTrafficTotalFlow":236106,"truckTrafficTotalFlow":71820,"specialTrafficTotalFlow":1264,"freeTrafficTotalFlow":null}}
```

---

### 收费站维度交通流 - 支付方式 - 监控分公司(142000)
**请求路由：** `/gssfApi2/v1/api/traffic/stationPayTypeTrafficFlow`

**请求参数：**
```json
{"body":{"unitId":"142000","beginTime":"2025-03-01","endTime":"2025-03-31"}}
```

**返回结果（HTTP 502）：**
```json
{"raw":""}
```

---

### 收费站维度交通流 - 计费车型 - 监控分公司(142000)
**请求路由：** `/gssfApi2/v1/api/traffic/stationVehTypeTrafficFlow`

**请求参数：**
```json
{"body":{"unitId":"142000","beginTime":"2025-03-01","endTime":"2025-03-31"}}
```

**返回结果（HTTP 200）：**
```json
{"code":1,"msg":"按计费车型获取收费站维度交通流请求成功","success":true,"data":{"vehTypeTrafficFlowList":[{"unitId":"S0022230010010","unitName":"中源大道收费站","trafficFlow":75790,"carTrafficFlow":67253,"truckTrafficFlow":8036,"specialTrafficFlow":145,"freeTrafficFlow":356},{"unitId":"S0022230010050","unitName":"丰乐收费站","trafficFlow":21738,"carTrafficFlow":17870,"truckTrafficFlow":3693,"specialTrafficFlow":31,"freeTrafficFlow":144},{"unitId":"S0022230010060","unitName":"肇州收费站","trafficFlow":20187,"carTrafficFlow":13343,"truckTrafficFlow":6674,"specialTrafficFlow":58,"freeTrafficFlow":112},{"unitId":"S0022230010030","unitName":"五里明收费站","trafficFlow":20097,"carTrafficFlow":17260,"truckTrafficFlow":2667,"specialTrafficFlow":41,"freeTrafficFlow":129},{"unitId":"S0022230010040","unitName":"朝阳沟收费站","trafficFlow":13633,"carTrafficFlow":11693,"truckTrafficFlow":1886,"specialTrafficFlow":26,"freeTrafficFlow":28}],"trafficTotalFlow":151445,"carTrafficTotalFlow":127419,"truckTrafficTotalFlow":22956,"specialTrafficTotalFlow":301,"freeTrafficTotalFlow":null}}
```

---

### 收费站维度交通流 - 支付方式 - 大齐分公司(205000)
**请求路由：** `/gssfApi2/v1/api/traffic/stationPayTypeTrafficFlow`

**请求参数：**
```json
{"body":{"unitId":"205000","beginTime":"2025-03-01","endTime":"2025-03-31"}}
```

**返回结果（HTTP 200）：**
```json
{"code":1,"msg":"按支付方式获取收费站维度交通流请求成功","success":true,"data":{"payTypeTrafficFlowList":[{"unitId":"G0010230020030","unitName":"林甸站","trafficFlow":64074,"etcTrafficFlow":30177,"cashTrafficFlow":895,"mobileTrafficFlow":33002,"freeTrafficFlow":461},{"unitId":"G0010230020060","unitName":"机场路站","trafficFlow":49636,"etcTrafficFlow":21929,"cashTrafficFlow":2981,"mobileTrafficFlow":24726,"freeTrafficFlow":1162},{"unitId":"G0010230020050","unitName":"庆北站","trafficFlow":32048,"etcTrafficFlow":14345,"cashTrafficFlow":2338,"mobileTrafficFlow":15365,"freeTrafficFlow":115},{"unitId":"G0010230020070","unitName":"城北站","trafficFlow":17994,"etcTrafficFlow":8098,"cashTrafficFlow":1094,"mobileTrafficFlow":8802,"freeTrafficFlow":158},{"unitId":"G0010230020040","unitName":"花园站","trafficFlow":15906,"etcTrafficFlow":7320,"cashTrafficFlow":1224,"mobileTrafficFlow":7362,"freeTrafficFlow":85},{"unitId":"G0010230020020","unitName":"鹤鸣湖站","trafficFlow":15555,"etcTrafficFlow":7715,"cashTrafficFlow":1281,"mobileTrafficFlow":6559,"freeTrafficFlow":34},{"unitId":"G0010230020080","unitName":"庆东站","trafficFlow":4,"etcTrafficFlow":4,"cashTrafficFlow":0,"mobileTrafficFlow":0,"freeTrafficFlow":0}],"trafficTotalFlow":195217,"etcTrafficTotalFlow":89588,"cashTrafficTotalFlow":9813,"mobileTrafficTotalFlow":95816,"freeTrafficTotalFlow":2015}}
```

---

### 收费站维度交通流 - 计费车型 - 大齐分公司(205000)
**请求路由：** `/gssfApi2/v1/api/traffic/stationVehTypeTrafficFlow`

**请求参数：**
```json
{"body":{"unitId":"205000","beginTime":"2025-03-01","endTime":"2025-03-31"}}
```

**返回结果（HTTP 200）：**
```json
{"code":1,"msg":"按计费车型获取收费站维度交通流请求成功","success":true,"data":{"vehTypeTrafficFlowList":[{"unitId":"G0010230020030","unitName":"林甸站","trafficFlow":64074,"carTrafficFlow":47750,"truckTrafficFlow":15632,"specialTrafficFlow":231,"freeTrafficFlow":461},{"unitId":"G0010230020060","unitName":"机场路站","trafficFlow":49636,"carTrafficFlow":39308,"truckTrafficFlow":9021,"specialTrafficFlow":145,"freeTrafficFlow":1162},{"unitId":"G0010230020050","unitName":"庆北站","trafficFlow":32048,"carTrafficFlow":24113,"truckTrafficFlow":7740,"specialTrafficFlow":80,"freeTrafficFlow":115},{"unitId":"G0010230020070","unitName":"城北站","trafficFlow":17994,"carTrafficFlow":13986,"truckTrafficFlow":3796,"specialTrafficFlow":54,"freeTrafficFlow":158},{"unitId":"G0010230020040","unitName":"花园站","trafficFlow":15906,"carTrafficFlow":11703,"truckTrafficFlow":4086,"specialTrafficFlow":32,"freeTrafficFlow":85},{"unitId":"G0010230020020","unitName":"鹤鸣湖站","trafficFlow":15555,"carTrafficFlow":9720,"truckTrafficFlow":5754,"specialTrafficFlow":47,"freeTrafficFlow":34},{"unitId":"G0010230020080","unitName":"庆东站","trafficFlow":4,"carTrafficFlow":4,"truckTrafficFlow":0,"specialTrafficFlow":0,"freeTrafficFlow":0}],"trafficTotalFlow":195217,"carTrafficTotalFlow":146584,"truckTrafficTotalFlow":46029,"specialTrafficTotalFlow":589,"freeTrafficTotalFlow":null}}
```

---

### 收费站维度交通流 - 支付方式 - 绥庆分公司(230113)
**请求路由：** `/gssfApi2/v1/api/traffic/stationPayTypeTrafficFlow`

**请求参数：**
```json
{"body":{"unitId":"230113","beginTime":"2025-03-01","endTime":"2025-03-31"}}
```

**返回结果（HTTP 200）：**
```json
{"code":1,"msg":"按支付方式获取收费站维度交通流请求成功","success":true,"data":{"payTypeTrafficFlowList":[{"unitId":"S0018230010010","unitName":"绥化北收费站","trafficFlow":29397,"etcTrafficFlow":13435,"cashTrafficFlow":842,"mobileTrafficFlow":15120,"freeTrafficFlow":652},{"unitId":"S0018230010030","unitName":"望奎南收费站","trafficFlow":26566,"etcTrafficFlow":11590,"cashTrafficFlow":204,"mobileTrafficFlow":14772,"freeTrafficFlow":216},{"unitId":"S0018230010050","unitName":"青冈收费站","trafficFlow":15430,"etcTrafficFlow":6340,"cashTrafficFlow":324,"mobileTrafficFlow":8766,"freeTrafficFlow":282},{"unitId":"S0018230010090","unitName":"红岗东收费站","trafficFlow":13044,"etcTrafficFlow":6111,"cashTrafficFlow":50,"mobileTrafficFlow":6883,"freeTrafficFlow":42},{"unitId":"S0018230010070","unitName":"火石山收费站","trafficFlow":10383,"etcTrafficFlow":3284,"cashTrafficFlow":74,"mobileTrafficFlow":7025,"freeTrafficFlow":60},{"unitId":"S0018230010040","unitName":"民政收费站","trafficFlow":8861,"etcTrafficFlow":3585,"cashTrafficFlow":168,"mobileTrafficFlow":5108,"freeTrafficFlow":156},{"unitId":"S0018230010020","unitName":"卫星收费站","trafficFlow":5715,"etcTrafficFlow":2207,"cashTrafficFlow":11,"mobileTrafficFlow":3497,"freeTrafficFlow":8},{"unitId":"S0018230010080","unitName":"万宝山收费站","trafficFlow":4018,"etcTrafficFlow":1828,"cashTrafficFlow":14,"mobileTrafficFlow":2176,"freeTrafficFlow":14},{"unitId":"S0018230010060","unitName":"燎原收费站","trafficFlow":3810,"etcTrafficFlow":1527,"cashTrafficFlow":20,"mobileTrafficFlow":2263,"freeTrafficFlow":12}],"trafficTotalFlow":117224,"etcTrafficTotalFlow":49907,"cashTrafficTotalFlow":1707,"mobileTrafficTotalFlow":65610,"freeTrafficTotalFlow":1442}}
```

---

### 收费站维度交通流 - 计费车型 - 绥庆分公司(230113)
**请求路由：** `/gssfApi2/v1/api/traffic/stationVehTypeTrafficFlow`

**请求参数：**
```json
{"body":{"unitId":"230113","beginTime":"2025-03-01","endTime":"2025-03-31"}}
```

**返回结果（HTTP 502）：**
```json
{"raw":""}
```

---


> 生成完毕。