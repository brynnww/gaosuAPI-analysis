// 报告生成功能
class ReportManager {
    constructor() {
        this.apiBaseUrl = 'http://127.0.0.1:8000';
        this.currentReportId = null;
        this.charts = {};
        this.init();
    }
    
    init() {
        this.bindEvents();
        this.setDefaultDates();
    }
    
    bindEvents() {
        const generateBtn = document.getElementById('generate-report-btn');
        generateBtn.addEventListener('click', () => this.generateReport());
        
        // 回车键生成报告
        const startDateInput = document.getElementById('start-date');
        const endDateInput = document.getElementById('end-date');
        startDateInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') this.generateReport();
        });
        endDateInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') this.generateReport();
        });
        
        // 导出和打印报告按钮
        const exportBtn = document.getElementById('export-report-btn');
        const printBtn = document.getElementById('print-report-btn');
        const downloadImagesBtn = document.getElementById('btnDownloadImages');
        
        if (exportBtn) {
            exportBtn.addEventListener('click', () => this.exportReport());
        }
        if (printBtn) {
            printBtn.addEventListener('click', () => this.printReport());
        }
        if (downloadImagesBtn) {
            downloadImagesBtn.addEventListener('click', () => this.downloadImages());
        }
    }
    
    setDefaultDates() {
        const today = new Date();
        const lastMonth = new Date(today.getFullYear(), today.getMonth() - 1, 1);
        
        const startDateInput = document.getElementById('start-date');
        const endDateInput = document.getElementById('end-date');
        
        startDateInput.value = this.formatDate(lastMonth);
        endDateInput.value = this.formatDate(today);
    }
    
    formatDate(date) {
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');
        return `${year}-${month}-${day}`;
    }
    
    async generateReport() {
        const startDate = document.getElementById('start-date').value;
        const endDate = document.getElementById('end-date').value;
        
        if (!startDate || !endDate) {
            this.showMessage('请选择开始和结束日期', 'error');
            return;
        }
        
        if (startDate > endDate) {
            this.showMessage('开始日期不能晚于结束日期', 'error');
            return;
        }
        
        try {
            this.showReportStatus();
            this.updateStatus('准备中...', 0);
            
            const response = await fetch(`${this.apiBaseUrl}/api/report/generate`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    start_date: startDate,
                    end_date: endDate
                })
            });
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            
            const result = await response.json();
            this.currentReportId = result.report_id;
            
            this.updateStatus('报告已提交，正在生成...', 10);
            this.pollReportStatus();
            
        } catch (error) {
            console.error('生成报告失败:', error);
            this.showMessage(`生成报告失败: ${error.message}`, 'error');
            this.hideReportStatus();
        }
    }
    
    async pollReportStatus() {
        if (!this.currentReportId) return;
        
        try {
            const response = await fetch(`${this.apiBaseUrl}/api/report/status/${this.currentReportId}`);
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            
            const status = await response.json();
            
            this.updateStatus(status.message, status.progress);
            
            if (status.status === 'completed') {
                this.updateStatus('报告生成完成！', 100);
                setTimeout(() => this.getReportResult(), 1000);
            } else if (status.status === 'failed') {
                this.showMessage(`报告生成失败: ${status.message}`, 'error');
                this.hideReportStatus();
            } else {
                // 继续轮询
                setTimeout(() => this.pollReportStatus(), 2000);
            }
            
        } catch (error) {
            console.error('查询报告状态失败:', error);
            this.showMessage(`查询状态失败: ${error.message}`, 'error');
            this.hideReportStatus();
        }
    }
    
    async getReportResult() {
        if (!this.currentReportId) return;
        
        try {
            const response = await fetch(`${this.apiBaseUrl}/api/report/result/${this.currentReportId}`);
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            
            const result = await response.json();
            this.displayReport(result.data);
            
        } catch (error) {
            console.error('获取报告结果失败:', error);
            this.showMessage(`获取报告结果失败: ${error.message}`, 'error');
        }
    }
    
    displayReport(data) {
        // 显示文字报告
        this.displayTextReport(data);
        
        // 显示图表
        this.displayCharts(data.charts_data);
        
        // 隐藏状态显示
        setTimeout(() => {
            document.getElementById('report-status').style.display = 'none';
        }, 3000);
    }
    
    displayTextReport(data) {
        const textReportContainer = document.getElementById('text-report-container');
        textReportContainer.style.display = 'block';
        
        // 启用导出和打印按钮
        const exportBtn = document.getElementById('export-report-btn');
        const printBtn = document.getElementById('print-report-btn');
        const downloadImagesBtn = document.getElementById('btnDownloadImages');
        if (exportBtn) exportBtn.disabled = false;
        if (printBtn) printBtn.disabled = false;
        if (downloadImagesBtn) downloadImagesBtn.disabled = false;
        
        // 生成HTML格式的报告
        const reportContent = this.generateHTMLReport(data);
        const reportElement = document.getElementById('report');
        if (reportElement) {
            reportElement.innerHTML = reportContent;
        }
    }
    
    generateHTMLReport(data) {
        let html = '';
        
        // 报告标题
        html += '<h1>📊 收费数据分析报告</h1>';
        html += `<p class="report-time">生成时间：${new Date().toLocaleString('zh-CN')}</p>`;
        
        // 添加分析文字（如果存在）
        if (data.analysis_text) {
            html += '<h2>📈 数据分析</h2>';
            
            // 处理分析文字，将【】标题转换为HTML格式
            const analysisLines = data.analysis_text.split('\n');
            
            analysisLines.forEach(line => {
                line = line.trim();
                if (line.startsWith('【') && line.endsWith('】')) {
                    const title = line.substring(1, line.length - 1);
                    html += `<h3>${title}</h3>`;
                } else if (line.startsWith('• ')) {
                    html += `<p class="bullet-point">${line.substring(2)}</p>`;
                } else if (line) {
                    html += `<p>${line}</p>`;
                }
            });
        }
        

        
        return html;
    }
    

    
    displayCharts(chartsData) {
        const imagesContainer = document.getElementById('images');
        if (!imagesContainer) return;

        // 清除现有内容
        imagesContainer.innerHTML = '';

        if (!chartsData || chartsData.length === 0) {
            imagesContainer.innerHTML = '<div class="empty-state"><div class="empty-icon">📊</div><p>暂无图表数据</p></div>';
            return;
        }

        // 显示所有图表
        chartsData.forEach(chartImage => {
            const chartItem = document.createElement('div');
            chartItem.className = 'chart-item';

            chartItem.innerHTML = `
                <div class="chart-header">
                    <h4>${chartImage.title}</h4>
                    <button class="btn btn-secondary btn-sm download-chart-btn"
                            data-chart-id="${chartImage.chart_id}"
                            data-filename="${chartImage.filename}"
                            data-image="${chartImage.image_base64}">
                        <span class="btn-icon">📥</span>
                        下载图片
                    </button>
                </div>
                <div class="chart-image-container">
                    <img src="data:image/png;base64,${chartImage.image_base64}"
                         alt="${chartImage.title}"
                         class="chart-image"
                         data-chart-id="${chartImage.chart_id}"
                         onclick="openFullscreen(this)"
                         title="点击放大查看">
                </div>
            `;

            imagesContainer.appendChild(chartItem);
        });

        // 绑定下载事件
        this.bindDownloadEvents();
    }

    bindDownloadEvents() {
        const downloadButtons = document.querySelectorAll('.download-chart-btn');
        downloadButtons.forEach(button => {
            button.addEventListener('click', (e) => {
                const chartId = e.target.closest('button').dataset.chartId;
                const filename = e.target.closest('button').dataset.filename;
                const imageBase64 = e.target.closest('button').dataset.image;
                this.downloadSingleChart(chartId, filename, imageBase64);
            });
        });
    }

    downloadSingleChart(chartId, filename, imageBase64) {
        try {
            const link = document.createElement('a');
            link.href = `data:image/png;base64,${imageBase64}`;
            link.download = filename;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);

            this.showMessage('图表下载成功！', 'success');
        } catch (error) {
            console.error('下载失败:', error);
            this.showMessage('下载失败，请重试', 'error');
        }
    }
    
    showReportStatus() {
        document.getElementById('report-status').style.display = 'block';
        // 不隐藏图表和报告容器，让它们保持显示占位内容
    }
    
    hideReportStatus() {
        document.getElementById('report-status').style.display = 'none';
    }
    
    updateStatus(message, progress) {
        document.getElementById('status-message').textContent = message;
        document.getElementById('progress-text').textContent = `${progress}%`;
        document.getElementById('progress-fill').style.width = `${progress}%`;
    }
    
    showMessage(message, type) {
        // 移除现有消息
        const existingMessage = document.querySelector('.success-message, .error-message');
        if (existingMessage) {
            existingMessage.remove();
        }
        
        // 创建新消息
        const messageDiv = document.createElement('div');
        messageDiv.className = type === 'error' ? 'error-message' : 'success-message';
        messageDiv.textContent = message;
        
        // 插入到报告表单下方
        const reportForm = document.querySelector('.report-form');
        reportForm.parentNode.insertBefore(messageDiv, reportForm.nextSibling);
        
        // 3秒后自动移除
        setTimeout(() => {
            if (messageDiv.parentNode) {
                messageDiv.remove();
            }
        }, 3000);
    }
    
    // 批量下载所有图表
    downloadImages() {
        const chartImages = document.querySelectorAll('.chart-image');
        if (chartImages.length === 0) {
            this.showMessage('没有可下载的图表', 'error');
            return;
        }

        let downloadedCount = 0;
        const totalCount = chartImages.length;

        chartImages.forEach((img, index) => {
            setTimeout(() => {
                try {
                    const chartId = img.dataset.chartId;
                    const base64Data = img.src.replace('data:image/png;base64,', '');
                    const filename = `chart_${chartId}_${new Date().toISOString().split('T')[0]}.png`;

                    const link = document.createElement('a');
                    link.href = img.src;
                    link.download = filename;
                    document.body.appendChild(link);
                    link.click();
                    document.body.removeChild(link);

                    downloadedCount++;
                    if (downloadedCount === totalCount) {
                        this.showMessage(`成功下载 ${totalCount} 个图表！`, 'success');
                    }
                } catch (error) {
                    console.error('下载失败:', error);
                    this.showMessage('部分图表下载失败', 'error');
                }
            }, index * 500); // 每个下载间隔500ms
        });
    }
    
    // 导出报告为Word文档
    exportReport() {
        const reportElement = document.getElementById('report');
        if (!reportElement) return;
        
        try {
            // 创建完整的Word文档HTML
            const wordContent = this.generateWordDocument(reportElement.innerHTML);
            
            // 创建Blob并下载
            const blob = new Blob([wordContent], { 
                type: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' 
            });
            const url = URL.createObjectURL(blob);
            
            const a = document.createElement('a');
            a.href = url;
            a.download = `收费数据分析报告_${new Date().toISOString().split('T')[0]}.doc`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
            
            this.showMessage('Word报告导出成功！', 'success');
        } catch (error) {
            console.error('导出失败:', error);
            this.showMessage('导出失败，请重试', 'error');
        }
    }
    
    generateWordDocument(htmlContent) {
        // 生成Word兼容的HTML文档
        return `
<!DOCTYPE html>
<html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'>
<head>
    <meta charset='utf-8'>
    <title>收费数据分析报告</title>
    <!--[if gte mso 9]>
    <xml>
        <w:WordDocument>
            <w:View>Print</w:View>
            <w:Zoom>90</w:Zoom>
            <w:DoNotPromptForConvert/>
            <w:DoNotShowInsertionsAndDeletions/>
        </w:WordDocument>
    </xml>
    <![endif]-->
    <style>
        body {
            font-family: '微软雅黑', 'Microsoft YaHei', Arial, sans-serif;
            font-size: 12pt;
            line-height: 1.6;
            margin: 2cm;
            color: #333;
        }
        h1 {
            color: #4472C4;
            font-size: 24pt;
            font-weight: bold;
            text-align: center;
            margin-bottom: 10px;
        }
        h2 {
            color: #4472C4;
            font-size: 16pt;
            font-weight: bold;
            border-bottom: 1px solid #4472C4;
            padding-bottom: 5px;
            margin-bottom: 15px;
            margin-top: 20px;
        }
        h3 {
            color: #2F5597;
            font-size: 14pt;
            font-weight: bold;
            margin-bottom: 10px;
            margin-top: 15px;
        }
        h4 {
            color: #2F5597;
            font-size: 13pt;
            font-weight: bold;
            margin-bottom: 8px;
            margin-top: 12px;
        }
        .report-time {
            color: #666;
            font-size: 11pt;
            text-align: center;
            margin-bottom: 20px;
        }
        .bullet-point {
            margin-left: 20px;
            margin-bottom: 8px;
            position: relative;
        }
        .bullet-point:before {
            content: "•";
            font-weight: bold;
            position: absolute;
            left: -15px;
        }
        p {
            margin-bottom: 8px;
        }
        strong {
            color: #2F5597;
            font-weight: bold;
        }
        @page {
            size: A4;
            margin: 2cm;
        }
        @media print {
            body { margin: 0; }
        }
    </style>
</head>
<body>
    ${htmlContent}
    
    <div style="margin-top: 40px; padding-top: 20px; border-top: 1px solid #ddd; text-align: center; color: #666; font-size: 10pt;">
        <p>本报告由收费数据分析系统自动生成</p>
        <p>生成时间：${new Date().toLocaleString('zh-CN')}</p>
    </div>
</body>
</html>`;
    }
    
    // 图表全屏功能
    openFullscreen(img) {
        const modal = document.createElement('div');
        modal.className = 'fullscreen-modal';
        modal.innerHTML = `
            <div class="fullscreen-content">
                <span class="close-fullscreen" onclick="closeFullscreen()">&times;</span>
                <img src="${img.src}" alt="${img.alt}" class="fullscreen-image">
                <div class="fullscreen-title">${img.alt}</div>
            </div>
        `;
        
        document.body.appendChild(modal);
        modal.style.display = 'flex';
        
        // 点击背景关闭
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                this.closeFullscreen();
            }
        });
        
        // ESC键关闭
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                this.closeFullscreen();
            }
        });
    }
    
    closeFullscreen() {
        const modal = document.querySelector('.fullscreen-modal');
        if (modal) {
            modal.remove();
        }
    }
    
    // 打印报告
    printReport() {
        const reportElement = document.getElementById('report');
        if (!reportElement) return;
        
        const printWindow = window.open('', '_blank');
        printWindow.document.write(`
            <!DOCTYPE html>
            <html>
            <head>
                <title>收费管理系统数据分析报告</title>
                <style>
                    body { font-family: Arial, sans-serif; margin: 20px; }
                    h1 { color: #333; text-align: center; }
                    h3 { color: #666; border-bottom: 2px solid #eee; padding-bottom: 10px; }
                    h4 { color: #888; margin-top: 20px; }
                    h5 { color: #999; margin-top: 15px; }
                    ul { margin: 10px 0; }
                    li { margin: 5px 0; }
                    .report-section { margin: 20px 0; padding: 15px; border: 1px solid #ddd; border-radius: 5px; }
                    @media print {
                        body { margin: 0; }
                        .no-print { display: none; }
                    }
                </style>
            </head>
            <body>
                <h1>收费管理系统数据分析报告</h1>
                <p style="text-align: center; color: #666;">生成时间：${new Date().toLocaleString('zh-CN')}</p>
                <div class="report-content">
                    ${reportElement.innerHTML}
                </div>
                <div class="no-print" style="margin-top: 30px; text-align: center;">
                    <button onclick="window.print()">打印报告</button>
                    <button onclick="window.close()">关闭窗口</button>
                </div>
            </body>
            </html>
        `);
        printWindow.document.close();
    }
}

// 确保Chart.js加载完成后再初始化
function waitForChart() {
    if (typeof Chart !== 'undefined') {
        console.log('Chart.js 已加载，版本:', Chart.version);
        window.reportManager = new ReportManager();
    } else {
        console.log('等待Chart.js加载...');
        setTimeout(waitForChart, 100);
    }
}

// 全局函数
function openFullscreen(img) {
    if (window.reportManager) {
        window.reportManager.openFullscreen(img);
    }
}

function closeFullscreen() {
    if (window.reportManager) {
        window.reportManager.closeFullscreen();
    }
}

// 页面加载完成后等待Chart.js
document.addEventListener('DOMContentLoaded', () => {
    console.log('页面加载完成，检查Chart.js...');
    waitForChart();
});
