// 对话功能
class ChatManager {
    constructor() {
        this.apiBaseUrl = 'http://127.0.0.1:8000';
        this.messages = [];
        this.isProcessing = false;
        this.init();
    }
    
    init() {
        this.bindEvents();
        this.loadExampleQuestions();
    }
    
    bindEvents() {
        const sendBtn = document.getElementById('send-btn');
        const chatInput = document.getElementById('chat-input');
        
        sendBtn.addEventListener('click', () => this.sendMessage());
        
        chatInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                this.sendMessage();
            }
        });
        
        // 示例问题点击事件
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('example-btn')) {
                const question = e.target.dataset.question;
                this.setQuestion(question);
            }
        });
    }
    
    loadExampleQuestions() {
        // 示例问题已经在HTML中定义，这里可以动态加载更多
        console.log('示例问题已加载');
    }
    
    setQuestion(question) {
        const chatInput = document.getElementById('chat-input');
        chatInput.value = question;
        chatInput.focus();
    }
    
    async sendMessage() {
        const chatInput = document.getElementById('chat-input');
        const message = chatInput.value.trim();
        
        if (!message || this.isProcessing) {
            return;
        }
        
        // 清空输入框
        chatInput.value = '';
        
        // 添加用户消息
        this.addMessage(message, 'user');
        
        // 设置处理状态
        this.isProcessing = true;
        this.updateSendButton();
        
        try {
            // 发送到MCP服务器
            const response = await this.sendToMCP(message);
            this.addMessage(response, 'assistant');
        } catch (error) {
            console.error('发送消息失败:', error);
            this.addMessage(`抱歉，处理您的请求时出现了错误: ${error.message}`, 'assistant');
        } finally {
            this.isProcessing = false;
            this.updateSendButton();
        }
    }
    
    async sendToMCP(message) {
        const response = await fetch(`${this.apiBaseUrl}/v1/chat/completions`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                model: 'toll-management',
                messages: [
                    {
                        role: 'user',
                        content: message
                    }
                ],
                stream: false
            })
        });
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const result = await response.json();
        return result.choices[0].message.content;
    }
    
    addMessage(content, role) {
        const chatMessages = document.getElementById('chat-messages');
        
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${role}`;
        
        const messageContent = document.createElement('div');
        messageContent.className = 'message-content';
        
        // 处理内容格式
        if (role === 'assistant') {
            // 尝试解析JSON响应
            try {
                const parsed = JSON.parse(content);
                if (parsed.error) {
                    messageContent.innerHTML = `<span style="color: #e74c3c;">❌ ${parsed.error}</span>`;
                } else {
                    // 格式化显示数据
                    messageContent.innerHTML = this.formatDataResponse(parsed);
                }
            } catch (e) {
                // 不是JSON，直接显示文本
                messageContent.textContent = content;
            }
        } else {
            messageContent.textContent = content;
        }
        
        messageDiv.appendChild(messageContent);
        chatMessages.appendChild(messageDiv);
        
        // 滚动到底部
        chatMessages.scrollTop = chatMessages.scrollHeight;
        
        // 保存消息历史
        this.messages.push({ role, content, timestamp: new Date() });
    }
    
    formatDataResponse(data) {
        let html = '';
        
        // 根据数据类型格式化显示
        if (data.companyIds) {
            html += '<h4>🏢 分公司信息</h4>';
            html += '<div style="margin: 10px 0;">';
            data.companyIdNamePairs.forEach(company => {
                html += `<div style="padding: 5px; border-bottom: 1px solid #eee;">
                    <strong>${company.unitName}</strong> (ID: ${company.unitId})
                </div>`;
            });
            html += '</div>';
        } else if (data.data && data.data.payTypeTurnoverList) {
            html += '<h4>💰 交易数据</h4>';
            html += '<div style="margin: 10px 0;">';
            data.data.payTypeTurnoverList.forEach(company => {
                html += `<div style="padding: 8px; margin: 5px 0; background: #f8f9fa; border-radius: 5px;">
                    <strong>${company.unitName}</strong><br>
                    总交易额: ${(company.turnover / 10000).toFixed(2)}万元<br>
                    ETC: ${(company.etcTurnover / 10000).toFixed(2)}万元 | 
                    现金: ${(company.cashTurnover / 10000).toFixed(2)}万元 | 
                    移动支付: ${(company.mobileTurnover / 10000).toFixed(2)}万元
                </div>`;
            });
            if (data.data.totalTurnover) {
                html += `<div style="margin-top: 10px; padding: 10px; background: #e8f5e8; border-radius: 5px;">
                    <strong>总计: ${(data.data.totalTurnover / 10000).toFixed(2)}万元</strong>
                </div>`;
            }
            html += '</div>';
        } else if (data.data && data.data.payTypeTrafficFlowList) {
            html += '<h4>🚗 交通流量数据</h4>';
            html += '<div style="margin: 10px 0;">';
            data.data.payTypeTrafficFlowList.forEach(company => {
                html += `<div style="padding: 8px; margin: 5px 0; background: #f8f9fa; border-radius: 5px;">
                    <strong>${company.unitName}</strong><br>
                    总流量: ${company.trafficFlow.toLocaleString()}辆<br>
                    ETC: ${company.etcTrafficFlow.toLocaleString()}辆 | 
                    现金: ${company.cashTrafficFlow.toLocaleString()}辆 | 
                    移动支付: ${company.mobileTrafficFlow.toLocaleString()}辆
                </div>`;
            });
            if (data.data.trafficTotalFlow) {
                html += `<div style="margin-top: 10px; padding: 10px; background: #e8f5e8; border-radius: 5px;">
                    <strong>总计: ${data.data.trafficTotalFlow.toLocaleString()}辆</strong>
                </div>`;
            }
            html += '</div>';
        } else if (data.status === 'completed' && data.data) {
            // 报告生成结果
            html += '<h4>📊 报告生成完成</h4>';
            if (data.data.analysis_text) {
                html += `<div style="margin: 10px 0; white-space: pre-line;">${data.data.analysis_text}</div>`;
            }
            if (data.data.summary) {
                html += `<div style="margin-top: 10px; padding: 10px; background: #e8f5e8; border-radius: 5px;">
                    ${data.data.summary}
                </div>`;
            }
        } else {
            // 其他类型的数据，尝试美化显示
            html += '<h4>📋 数据信息</h4>';
            html += `<pre style="background: #f8f9fa; padding: 10px; border-radius: 5px; overflow-x: auto;">${JSON.stringify(data, null, 2)}</pre>`;
        }
        
        return html;
    }
    
    updateSendButton() {
        const sendBtn = document.getElementById('send-btn');
        const chatInput = document.getElementById('chat-input');
        
        if (this.isProcessing) {
            sendBtn.disabled = true;
            sendBtn.innerHTML = '<span class="loading"></span> 处理中...';
            chatInput.disabled = true;
        } else {
            sendBtn.disabled = false;
            sendBtn.innerHTML = '<span class="btn-icon">📤</span>';
            chatInput.disabled = false;
        }
    }
    
    // 清空对话历史
    clearChat() {
        const chatMessages = document.getElementById('chat-messages');
        // 保留系统消息
        const systemMessage = chatMessages.querySelector('.message.system');
        chatMessages.innerHTML = '';
        if (systemMessage) {
            chatMessages.appendChild(systemMessage);
        }
        this.messages = [];
    }
    
    // 导出对话历史
    exportChat() {
        const chatData = {
            timestamp: new Date().toISOString(),
            messages: this.messages
        };
        
        const blob = new Blob([JSON.stringify(chatData, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        
        const a = document.createElement('a');
        a.href = url;
        a.download = `chat_history_${new Date().toISOString().split('T')[0]}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    }
}

// 聊天面板控制
class ChatPanel {
    constructor() {
        this.chatPanel = document.getElementById('chat-panel');
        this.toggleBtn = document.getElementById('chat-toggle-btn');
        this.closeBtn = document.getElementById('chat-close-btn');
        this.mainContent = document.querySelector('.main-content');
        this.init();
    }
    
    init() {
        this.toggleBtn.addEventListener('click', () => this.open());
        this.closeBtn.addEventListener('click', () => this.close());
        
        // 点击面板外部关闭
        document.addEventListener('click', (e) => {
            if (this.chatPanel.classList.contains('active') && 
                !this.chatPanel.contains(e.target) && 
                !this.toggleBtn.contains(e.target)) {
                this.close();
            }
        });
        
        // ESC键关闭面板
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && this.chatPanel.classList.contains('active')) {
                this.close();
            }
        });
    }
    
    open() {
        this.chatPanel.classList.add('active');
        this.mainContent.classList.add('chat-open');
        this.toggleBtn.style.display = 'none';
        
        // 聚焦到聊天输入框
        setTimeout(() => {
            const chatInput = document.getElementById('chat-input');
            if (chatInput) {
                chatInput.focus();
            }
        }, 400);
    }
    
    close() {
        this.chatPanel.classList.remove('active');
        this.mainContent.classList.remove('chat-open');
        this.toggleBtn.style.display = 'flex';
    }
    
    // 切换面板状态
    toggle() {
        if (this.chatPanel.classList.contains('active')) {
            this.close();
        } else {
            this.open();
        }
    }
}

// 页面加载完成后初始化
document.addEventListener('DOMContentLoaded', () => {
    const chatManager = new ChatManager();
    const chatPanel = new ChatPanel();
    
    // 将实例暴露到全局，方便调试
    window.chatManager = chatManager;
    window.chatPanel = chatPanel;
    
    console.log('聊天系统初始化完成');
});
