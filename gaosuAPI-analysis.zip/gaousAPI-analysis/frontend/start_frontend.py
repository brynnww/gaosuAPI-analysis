#!/usr/bin/env python3
"""
简单的前端测试服务器
用于在开发环境中测试前端界面
"""

import http.server
import socketserver
import os
import sys
from pathlib import Path

def start_frontend_server(port=3000):
    """启动前端测试服务器"""
    
    # 检查当前目录
    current_dir = Path.cwd()
    if current_dir.name == "frontend":
        # 已经在frontend目录中
        print(f"📁 当前目录: {current_dir}")
    else:
        # 切换到前端目录
        frontend_dir = current_dir / "frontend"
        if not frontend_dir.exists():
            print("前端目录不存在，请先创建 frontend/ 目录")
            return
        
        os.chdir(frontend_dir)
        print(f"切换到目录: {os.getcwd()}")
    
    # 创建HTTP服务器
    Handler = http.server.SimpleHTTPRequestHandler
    
    with socketserver.TCPServer(("", port), Handler) as httpd:
        print(f"前端测试服务器已启动")
        print(f"访问地址: http://localhost:{port}")
        print(f"服务目录: {os.getcwd()}")
        print(f"按 Ctrl+C 停止服务器")
        print("-" * 50)
        
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\n服务器已停止")

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="启动前端测试服务器")
    parser.add_argument("--port", type=int, default=3000, help="服务器端口 (默认: 3000)")
    
    args = parser.parse_args()
    
    try:
        start_frontend_server(args.port)
    except Exception as e:
        print(f"启动失败: {e}")
        sys.exit(1)
